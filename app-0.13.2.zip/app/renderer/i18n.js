// 책상 친구 — screen text in English and Japanese.
// The Korean text itself is the key: anything not listed here simply stays Korean.
// Page text is swapped in place by translateDom(); code uses I18N.t(lang, '한국어 문장', { vars }).
(function (root) {
  const EN = {
    '업데이트': 'Update', '업데이트 확인': 'Check for updates', '자동으로 업데이트 확인': 'Check for updates automatically',
    '지금 버전 v{v}': 'Version v{v}', '새 버전 v{v}이 나왔어. 지금 업데이트할까?': 'Version v{v} is out. Update now?',
    '지금이 최신 버전이야. (v{v})': "You're on the latest version. (v{v})", '새 버전 내려받는 중… 잠깐만.': 'Downloading the new version… one sec.',
    '다 받았어. 다시 켜질게!': 'Got it. Restarting!', '아직 업데이트 주소가 정해지지 않았어.': "The update address isn't set up yet.",
    '업데이트를 확인하지 못했어. 인터넷 연결을 봐 줘.': "Couldn't check for updates. Check your internet connection.",
    '책상 친구': 'Desk Buddy', '복사': 'Copy', '설정': 'Settings', '캐릭터': 'Character', '기본': 'Basics',
    '캐릭터 이름': 'Character name', '말 수': 'How chatty', '조용히': 'Quiet', '보통': 'Normal', '수다스럽게': 'Chatty',
    '항상 말하기': 'Always talking', '점심': 'Lunch', '간식': 'Snack', '저녁': 'Dinner', '마무리': 'Wrap-up', '날씨 지역': 'Weather city',
    '말풍선 위치': 'Speech bubble', '머리 위 (모서리에선 아래)': 'Above her head (below near the top edge)', '캐릭터 옆': 'Beside her',
    '나를 부르는 말': 'What she calls you', '안 부르기': "Don't call me anything", '야': 'Hey', '저기': 'Psst', '이봐': 'Yo',
    '이름 직접 입력…': 'My name…', '내 이름': 'My name', '크기 · 투명도': 'Size · transparency', '캐릭터 크기': 'Character size',
    '글씨 크기': 'Text size', '할 일 창 배율 (글씨·버튼)': 'Panel scale (text · buttons)', '할 일 창 폭': 'Panel width',
    '할 일 창 높이 (최대)': 'Panel height (max)', '투명도': 'Opacity', '작업 시작': 'Work starts', '작업 끝': 'Work ends',
    '캐릭터 옆에 항상 표시': 'Always show next to her', '카드 위치': 'Card position', '캐릭터 옆 · 아래쪽': 'Beside her · low',
    '캐릭터 옆 · 위쪽': 'Beside her · high', '캐릭터 머리 위': 'Above her head', '날짜': 'Date', '시간': 'Time',
    '오늘 할 일 (남은 개수 + 다음 거)': "Today's tasks (left + next)", 'u 할 일만': 'u tasks only', '날씨': 'Weather',
    '배터리 (노트북 · 블루투스)': 'Battery (laptop · Bluetooth)', '지금 듣는 노래 (곡명 · 가수)': 'Now playing (song · artist)',
    '책상 친구 자체 부하': "Desk Buddy's own load", '카드에 보여줄 블루투스 기기': 'Bluetooth devices on the card', '창': 'Window',
    '항상 위에 표시': 'Always on top', '움직임 멈추기': 'Hold still', '마우스 올리면 선명하게': 'Solid on mouse-over',
    '클릭 통과 (Ctrl 누를 때만 잡기)': 'Click-through (grab with Ctrl)', '컴퓨터 켤 때 자동 실행': 'Start with Windows',
    '날씨 알려주기': 'Weather', '블루투스 기기 배터리': 'Bluetooth battery', '음악 자동 감지': 'Detect music',
    'CPU·RAM·GPU 반응': 'React to CPU·RAM·GPU', '매일 루틴': 'Daily routines', '추가': 'Add', '확인용': 'Checks',
    '상황 테스트 열기': 'Open situation test', '테스트 끝': 'End test', '▶ 자동으로 넘기기': '▶ Auto-play', '대사만 보기': 'Lines only',
    '한 줄': 'One line', '그림 전부': 'All drawings', '· 누르면 X ·': '· tap for X ·', '내일로 ·': 'tomorrow ·', '날짜로': 'pick a date',
    '오늘 할 일': "Today's tasks", '수첩 기호로 복사': 'Copy with notebook symbols', '닫기': 'Close', '날씨와 배터리': 'Weather and battery',
    '캐릭터 고르기': 'Choose a character', '시오리': 'Shiori', '예: 수환': 'e.g. Alex', '루틴 추가 (예: 스트레칭)': 'Add a routine (e.g. stretching)',
    '루틴 추가': 'Add a routine', '대사 종류': 'Line type', '할 일 추가 · 앞에 u 나 * 붙이면 표시': 'Add a task · start with u or * to mark it',
    '할 일 추가': 'Add a task', '시오리 · 누르면 할 일 · 끌어서 이동': 'Shiori · click for tasks · drag to move',
    '할 일 열기': 'Open tasks', '5분만 해볼게': "I'll do 5 minutes", '다른 거': 'Something else', '내일로': 'Tomorrow', '나중에': 'Later',
    '끝냈어!': 'Done!', '계속할래': 'Keep going', '여기까지': "That's it", '못 한 {n}개 내일로': 'Move {n} left to tomorrow',
    '수첩용 복사': 'Copy for notebook', '좋아': 'OK', '[매일 루틴]': '[Daily routines]', '[오늘]': '[Today]',
    '복사했어. 수첩에 옮겨 적어줘.': 'Copied. Write it into your notebook.', '할 일 {a}/{b}': 'Tasks {a}/{b}', '남은 거 {n}개': '{n} left',
    '오늘 적은 할 일 없음': 'No tasks today', 'u 할 일 없음': 'No u tasks', '그 외 {n}개': '{n} more', '우산': 'umbrella',
    '노트북': 'Laptop', '렌더 중': 'rendering', '재생 중인 노래 없음': 'Nothing playing', '이전 곡': 'Previous', '일시정지': 'Pause',
    '재생': 'Play', '다음 곡': 'Next', '연결 안 됨': 'not connected', '{a} / {b} 끝 · 남은 거 {n}개': '{a} / {b} done · {n} left',
    '아직 적은 게 없어요': 'Nothing written yet', '수첩에 적은 것 중에 컴퓨터로 할 것만 여기 적어줘. 5분짜리는 앞에 u.':
      'Put only the computer tasks from your notebook here. Start 5-minute ones with u.',
    '완료 취소': 'Undo', '완료': 'Done', '내일': 'tomorrow', '({d}에서)': '(from {d})', '내일로 미루기': 'Move to tomorrow',
    '날짜 정해서 옮기기': 'Move to a date', '지우기': 'Delete', '오늘': 'Today', '{name} 전신': '{name}, full body',
    '{name} · 누르면 할 일 · 끌어서 이동': '{name} · click for tasks · drag to move', '자동으로 넘기기': 'Auto-play', '멈추기': 'Stop',
    '루틴 이름': 'Routine name', '오늘 {city} {sky}, {min}~{max}도.': '{city} today: {sky}, {min}–{max}°C.',
    '우산 챙겨.': 'Take an umbrella.', '덥겠다. 물 많이 마셔.': "It'll be hot. Drink lots of water.", '춥대. 따뜻하게 입어.': 'Cold out. Dress warm.',
    '{city} 날씨': '{city} weather', '블루투스': 'Bluetooth', '렌더링 중': 'rendering', '이 컴퓨터': 'This computer',
    '이 프로그램이 쓰는 양 (도우미 PowerShell 포함)': 'What this app uses (including its PowerShell helper)',
    '맑음': 'Clear', '구름 조금': 'Partly cloudy', '흐림': 'Cloudy', '안개': 'Fog', '이슬비': 'Drizzle', '비': 'Rain', '눈': 'Snow',
    '소나기': 'Showers', '뇌우': 'Thunderstorm',
    '서울': 'Seoul', '부산': 'Busan', '인천': 'Incheon', '대구': 'Daegu', '대전': 'Daejeon', '광주': 'Gwangju', '울산': 'Ulsan',
    '세종': 'Sejong', '수원': 'Suwon', '성남': 'Seongnam', '고양': 'Goyang', '용인': 'Yongin', '청주': 'Cheongju', '전주': 'Jeonju',
    '춘천': 'Chuncheon', '강릉': 'Gangneung', '제주': 'Jeju',
    'Ctrl을 누른 채로 누르기': 'Hold Ctrl and click', '위로': 'Move up', '아래로': 'Move down', '카드에 보여줄 할 일 개수': 'Tasks shown on the card', '0 (개수만)': '0 (count only)', '오늘 할 일 (남은 개수 + 목록)': "Today's tasks (count + list)", '이벤트로 바꾸기': 'Make it an event', '할 일로 바꾸기': 'Make it a task', '포즈 바뀌는 정도': 'Pose changes', '안 바뀌게 (실제 상황·시간만)': 'Rarely (only real activity / set times)', '적당히': 'Sometimes', '많이 바뀌게': 'Often', '타이머': 'Timer', '타이머 시간 (돌려서 정하기)': 'Timer length (turn the dial)', '분': 'Minutes', '할 일': 'Task', '(없음)': '(none)', '최근에 쓴 시간': 'Recent lengths', '시작': 'Start', '멈추기': 'Stop', '원을 돌려서 정해 (한 바퀴 60분). 60분이 넘으면 숫자로 입력해.': 'Turn the dial to set it (one turn = 60 min). For more than 60, type the number.', '{n}분 타이머 시작!': '{n}-minute timer started!', '{n}분 끝났어!': '{n} minutes are up!', '{n}분 한 번 더': '{n} more minutes', '{n}분': '{n} min', '{n}바퀴+': '{n}+ turns', '외장': 'Discrete', '내장': 'Integrated', '업데이트 사이트에 아직 버전 파일이 없어. (Netlify 배포를 확인해 줘)': "The update site doesn't have the version file yet. (Check the Netlify deploy.)", '미리보기': 'Preview', '끌어서 폭 조절': 'Drag to change the width', '끌어서 높이 조절': 'Drag to change the height',
    "지난 날 남은 거 {n}개": "{n} left from earlier days", "모두 오늘로": "All to today", "오늘 할 일로": "Move to today", "루틴": "Routine", "하루 시작": "Day starts at", "이 시각 전까지는 전날로 쳐요. 자정이 지나도 목록이 그대로예요.": "Before this time it still counts as the previous day, so the list stays after midnight.", "메모": "Notes", "타이머 · 알람": "Timer · alarm", "보기": "View", "+ 새 메모": "+ New note", "전체 TXT로 내보내기": "Export all as TXT", "첫 줄이 제목이에요. 카드에 첫 줄을 띄우려면 설정 → 캐릭터 옆에 보여줄 것 → 메모.": "The first line is the title. To show it on the card: Settings → what to show → Notes.", "아직 메모가 없어요. + 새 메모로 시작해요.": "No notes yet. Start with + New note.", "첫 줄은 제목": "First line is the title", "이 메모를 TXT로 내보내기": "Export this note as TXT", "정말 지울까?": "Really delete?", "저장했어. {f}": "Saved. {f}", "책상 친구 메모": "Desk Buddy notes", "메모 없음": "No notes", "메모 (첫 줄)": "Notes (first line)", "알람": "Alarm", "+ 알람": "+ Alarm", "끄기": "Stop", "5분 뒤": "In 5 min", "알람이 없어요.": "No alarms.", "시각": "Time", "이름 (선택)": "Name (optional)", "매일": "Daily", "켜짐": "On", "꺼짐": "Off",
    "블럭 고르기": "Choose block", "지금 블럭": "Current block", "{n}블럭으로": "To block {n}", "{n}블럭 다 끝냈어. 다음 블럭으로 넘어갈까?": "Block {n} is all done. Move on to the next block?", "조금 더": "A bit more", "{n}블럭": "Block {n}", "블럭": "Blocks",
    "현재 블럭 {n}": "Block {n} now", "이전 블럭": "Previous block", "다음 블럭": "Next block", "{n}블럭 할 일을 위로": "Show block {n} first", "블럭 밖을 누르면 블럭 순서대로": "Click outside the boxes: order by block", "블럭 없음": "No block", "현재 블럭 할 일": "Current block tasks", "이 블럭에 할 일 없음": "Nothing in this block", "끌어서 순서 바꾸기": "Drag to reorder", "위에 고정": "Pin", "고정됨": "Pinned", "달력": "Calendar", "이전 달": "Previous month", "다음 달": "Next month", "적은 게 없어요": "Nothing written", "이 날 할 일 추가": "Add a task for this day",
    "일정": "Event", "종류": "Type", "이 날에 추가": "Add to this day",
    "하나 줄이기": "One fewer", "하나 늘리기": "One more", "전부": "All", "0이면 개수만 보여줘요.": "0 shows just the count.",
    "현재 블럭 할 일 개수": "Current block tasks shown", "안 끝낸 것만": "Open only", "이 블럭 다 끝냄": "This block is done",
    "{n}블럭에 남은 거 {c}개, 다음 블럭으로 옮길까?": "{c} left in block {n}. Take them to the next block?", "옮기고 넘어가기": "Take them along", "그냥 넘어가기": "Just move on", "취소": "Cancel", "접기": "Fold", "펼치기": "Show", "목록 개수": "How many", "u 할 일 개수": "u tasks shown",
    "지난 날 남은 할 일 예시 넣기": "Add sample leftovers from yesterday", "(예시) 어제 못 한 자료 정리": "(sample) sort the files from yesterday", "(예시) 메일 하나 답장": "(sample) reply to one email"
  };
  const JA = {
    '업데이트': 'アップデート', '업데이트 확인': 'アップデートを確認', '자동으로 업데이트 확인': '自動でアップデートを確認',
    '지금 버전 v{v}': 'バージョン v{v}', '새 버전 v{v}이 나왔어. 지금 업데이트할까?': '新しいバージョン v{v} が出たよ。今アップデートする？',
    '지금이 최신 버전이야. (v{v})': '今が最新バージョンだよ。(v{v})', '새 버전 내려받는 중… 잠깐만.': '新しいバージョンをダウンロード中… ちょっと待ってね。',
    '다 받았어. 다시 켜질게!': 'できた。再起動するね！', '아직 업데이트 주소가 정해지지 않았어.': 'アップデートの場所がまだ設定されてないよ。',
    '업데이트를 확인하지 못했어. 인터넷 연결을 봐 줘.': 'アップデートを確認できなかった。ネット接続を見てみて。',
    '책상 친구': 'デスクの友だち', '복사': 'コピー', '설정': '設定', '캐릭터': 'キャラクター', '기본': '基本',
    '캐릭터 이름': 'キャラの名前', '말 수': 'おしゃべり度', '조용히': '静かに', '보통': 'ふつう', '수다스럽게': 'おしゃべり',
    '항상 말하기': 'ずっと話す', '점심': '昼ごはん', '간식': 'おやつ', '저녁': '晩ごはん', '마무리': '一日のしめ', '날씨 지역': '天気の地域',
    '말풍선 위치': '吹き出しの位置', '머리 위 (모서리에선 아래)': '頭の上（画面の上端では下）', '캐릭터 옆': 'キャラの横',
    '나를 부르는 말': 'わたしの呼び方', '안 부르기': '呼ばない', '야': 'ねえ', '저기': 'ちょっと', '이봐': 'おい',
    '이름 직접 입력…': '名前を入力…', '내 이름': 'わたしの名前', '크기 · 투명도': 'サイズ · 透明度', '캐릭터 크기': 'キャラの大きさ',
    '글씨 크기': '文字の大きさ', '할 일 창 배율 (글씨·버튼)': 'パネルの倍率（文字・ボタン）', '할 일 창 폭': 'パネルの幅',
    '할 일 창 높이 (최대)': 'パネルの高さ（最大）', '투명도': '不透明度', '작업 시작': '作業開始', '작업 끝': '作業終了',
    '캐릭터 옆에 항상 표시': 'キャラの横にいつも表示', '카드 위치': 'カードの位置', '캐릭터 옆 · 아래쪽': 'キャラの横 · 下',
    '캐릭터 옆 · 위쪽': 'キャラの横 · 上', '캐릭터 머리 위': 'キャラの頭の上', '날짜': '日付', '시간': '時刻',
    '오늘 할 일 (남은 개수 + 다음 거)': '今日のタスク（残り + 次）', 'u 할 일만': 'u タスクだけ', '날씨': '天気',
    '배터리 (노트북 · 블루투스)': 'バッテリー（ノートPC · Bluetooth）', '지금 듣는 노래 (곡명 · 가수)': '再生中の曲（曲名 · アーティスト）',
    '책상 친구 자체 부하': 'このアプリの負荷', '카드에 보여줄 블루투스 기기': 'カードに出す Bluetooth 機器', '창': 'ウィンドウ',
    '항상 위에 표시': '常に手前に表示', '움직임 멈추기': '動きを止める', '마우스 올리면 선명하게': 'マウスを乗せたらくっきり',
    '클릭 통과 (Ctrl 누를 때만 잡기)': 'クリックを通す（Ctrl でつかむ）', '컴퓨터 켤 때 자동 실행': 'Windows 起動時に開く',
    '날씨 알려주기': '天気を教える', '블루투스 기기 배터리': 'Bluetooth のバッテリー', '음악 자동 감지': '音楽を自動で検出',
    'CPU·RAM·GPU 반응': 'CPU·RAM·GPU に反応', '매일 루틴': '毎日のルーティン', '추가': '追加', '확인용': '確認用',
    '상황 테스트 열기': '状況テストを開く', '테스트 끝': 'テスト終了', '▶ 자동으로 넘기기': '▶ 自動で進める', '대사만 보기': 'セリフだけ見る',
    '한 줄': '一言', '그림 전부': '全部の絵', '· 누르면 X ·': '· 押すと X ·', '내일로 ·': '明日へ ·', '날짜로': '日付へ',
    '오늘 할 일': '今日のタスク', '수첩 기호로 복사': '手帳の記号でコピー', '닫기': '閉じる', '날씨와 배터리': '天気とバッテリー',
    '캐릭터 고르기': 'キャラを選ぶ', '시오리': 'しおり', '예: 수환': '例: たろう', '루틴 추가 (예: 스트레칭)': 'ルーティンを追加（例: ストレッチ）',
    '루틴 추가': 'ルーティンを追加', '대사 종류': 'セリフの種類', '할 일 추가 · 앞에 u 나 * 붙이면 표시': 'タスクを追加 · 先頭に u や * で印',
    '할 일 추가': 'タスクを追加', '시오리 · 누르면 할 일 · 끌어서 이동': 'しおり · クリックでタスク · ドラッグで移動',
    '할 일 열기': 'タスクを開く', '5분만 해볼게': '5分だけやる', '다른 거': 'ほかのにする', '내일로': '明日へ', '나중에': 'あとで',
    '끝냈어!': '終わった！', '계속할래': '続ける', '여기까지': 'ここまで', '못 한 {n}개 내일로': '残り{n}個を明日へ',
    '수첩용 복사': '手帳用にコピー', '좋아': 'OK', '[매일 루틴]': '[毎日のルーティン]', '[오늘]': '[今日]',
    '복사했어. 수첩에 옮겨 적어줘.': 'コピーしたよ。手帳に書き写してね。', '할 일 {a}/{b}': 'タスク {a}/{b}', '남은 거 {n}개': '残り{n}個',
    '오늘 적은 할 일 없음': '今日のタスクなし', 'u 할 일 없음': 'u タスクなし', '그 외 {n}개': 'ほか{n}個', '우산': '傘',
    '노트북': 'ノートPC', '렌더 중': 'レンダリング中', '재생 중인 노래 없음': '再生中の曲なし', '이전 곡': '前の曲', '일시정지': '一時停止',
    '재생': '再生', '다음 곡': '次の曲', '연결 안 됨': '未接続', '{a} / {b} 끝 · 남은 거 {n}개': '{a} / {b} 完了 · 残り{n}個',
    '아직 적은 게 없어요': 'まだ何も書いてないよ', '수첩에 적은 것 중에 컴퓨터로 할 것만 여기 적어줘. 5분짜리는 앞에 u.':
      '手帳に書いたうち、パソコンでやることだけここに。5分で終わるのは先頭に u。',
    '완료 취소': '完了を取り消す', '완료': '完了', '내일': '明日', '({d}에서)': '（{d}から）', '내일로 미루기': '明日へ回す',
    '날짜 정해서 옮기기': '日付を決めて移す', '지우기': '削除', '오늘': '今日', '{name} 전신': '{name}の全身',
    '{name} · 누르면 할 일 · 끌어서 이동': '{name} · クリックでタスク · ドラッグで移動', '자동으로 넘기기': '自動で進める', '멈추기': '止める',
    '루틴 이름': 'ルーティン名', '오늘 {city} {sky}, {min}~{max}도.': '今日の{city}は{sky}、{min}〜{max}度。',
    '우산 챙겨.': '傘を持っていってね。', '덥겠다. 물 많이 마셔.': '暑そう。水たくさん飲んで。', '춥대. 따뜻하게 입어.': '寒いって。あったかくして。',
    '{city} 날씨': '{city}の天気', '블루투스': 'Bluetooth', '렌더링 중': 'レンダリング中', '이 컴퓨터': 'このパソコン',
    '이 프로그램이 쓰는 양 (도우미 PowerShell 포함)': 'このアプリの使用量（補助の PowerShell を含む）',
    '맑음': '晴れ', '구름 조금': '晴れ時々くもり', '흐림': 'くもり', '안개': '霧', '이슬비': '霧雨', '비': '雨', '눈': '雪',
    '소나기': 'にわか雨', '뇌우': '雷雨',
    '서울': 'ソウル', '부산': '釜山', '인천': '仁川', '대구': '大邱', '대전': '大田', '광주': '光州', '울산': '蔚山',
    '세종': '世宗', '수원': '水原', '성남': '城南', '고양': '高陽', '용인': '龍仁', '청주': '清州', '전주': '全州',
    '춘천': '春川', '강릉': '江陵', '제주': '済州',
    'Ctrl을 누른 채로 누르기': 'Ctrlを押しながらクリック', '위로': '上へ', '아래로': '下へ', '카드에 보여줄 할 일 개수': 'カードに出すタスクの数', '0 (개수만)': '0（数だけ）', '오늘 할 일 (남은 개수 + 목록)': '今日のタスク（残り数＋リスト）', '이벤트로 바꾸기': 'イベントにする', '할 일로 바꾸기': 'タスクに戻す', '포즈 바뀌는 정도': 'ポーズの変わり方', '안 바뀌게 (실제 상황·시간만)': '変えない（実際の状況・時間だけ）', '적당히': 'ほどほど', '많이 바뀌게': 'よく変わる', '타이머': 'タイマー', '타이머 시간 (돌려서 정하기)': 'タイマーの長さ（回して決める）', '분': '分', '할 일': 'タスク', '(없음)': '（なし）', '최근에 쓴 시간': '最近使った長さ', '시작': 'スタート', '멈추기': '止める', '원을 돌려서 정해 (한 바퀴 60분). 60분이 넘으면 숫자로 입력해.': '円を回して決めてね（1周60分）。60分を超えるなら数字で入力。', '{n}분 타이머 시작!': '{n}分タイマー、スタート！', '{n}분 끝났어!': '{n}分たったよ！', '{n}분 한 번 더': 'もう{n}分', '{n}분': '{n}分', '{n}바퀴+': '{n}周以上', '외장': '外部', '내장': '内蔵', '업데이트 사이트에 아직 버전 파일이 없어. (Netlify 배포를 확인해 줘)': '更新サイトにまだバージョンファイルがないよ。（Netlifyのデプロイを確認してね）', '미리보기': 'プレビュー', '끌어서 폭 조절': 'ドラッグで幅を変える', '끌어서 높이 조절': 'ドラッグで高さを変える',
    "지난 날 남은 거 {n}개": "前の日の残り {n}件", "모두 오늘로": "全部今日へ", "오늘 할 일로": "今日のタスクへ", "루틴": "ルーティン", "하루 시작": "一日の始まり", "이 시각 전까지는 전날로 쳐요. 자정이 지나도 목록이 그대로예요.": "この時刻までは前日扱い。0時を過ぎてもリストはそのまま。", "메모": "メモ", "타이머 · 알람": "タイマー · アラーム", "보기": "表示", "+ 새 메모": "+ 新しいメモ", "전체 TXT로 내보내기": "全部TXTで書き出す", "첫 줄이 제목이에요. 카드에 첫 줄을 띄우려면 설정 → 캐릭터 옆에 보여줄 것 → 메모.": "1行目がタイトル。カードに出すには 設定 → 表示するもの → メモ。", "아직 메모가 없어요. + 새 메모로 시작해요.": "まだメモがないよ。+ 新しいメモから。", "첫 줄은 제목": "1行目はタイトル", "이 메모를 TXT로 내보내기": "このメモをTXTで書き出す", "정말 지울까?": "本当に消す？", "저장했어. {f}": "保存したよ。{f}", "책상 친구 메모": "デスクのともだち メモ", "메모 없음": "メモなし", "메모 (첫 줄)": "メモ（1行目）", "알람": "アラーム", "+ 알람": "+ アラーム", "끄기": "止める", "5분 뒤": "5分後", "알람이 없어요.": "アラームなし。", "시각": "時刻", "이름 (선택)": "名前（任意）", "매일": "毎日", "켜짐": "オン", "꺼짐": "オフ",
    "블럭 고르기": "ブロックを選ぶ", "지금 블럭": "今のブロック", "{n}블럭으로": "ブロック{n}へ", "{n}블럭 다 끝냈어. 다음 블럭으로 넘어갈까?": "ブロック{n}、全部終わったよ。次のブロックに行く？", "조금 더": "もう少し", "{n}블럭": "ブロック{n}", "블럭": "ブロック",
    "현재 블럭 {n}": "今はブロック{n}", "이전 블럭": "前のブロック", "다음 블럭": "次のブロック", "{n}블럭 할 일을 위로": "ブロック{n}を上に", "블럭 밖을 누르면 블럭 순서대로": "外側を押すとブロック順", "블럭 없음": "ブロックなし", "현재 블럭 할 일": "今のブロックのタスク", "이 블럭에 할 일 없음": "このブロックは空", "끌어서 순서 바꾸기": "ドラッグで並べ替え", "위에 고정": "上に固定", "고정됨": "固定中", "달력": "カレンダー", "이전 달": "前の月", "다음 달": "次の月", "적은 게 없어요": "何もないよ", "이 날 할 일 추가": "この日にタスクを追加",
    "일정": "予定", "종류": "種類", "이 날에 추가": "この日に追加",
    "하나 줄이기": "1つ減らす", "하나 늘리기": "1つ増やす", "전부": "全部", "0이면 개수만 보여줘요.": "0なら数だけ表示。",
    "현재 블럭 할 일 개수": "今のブロックで表示する数", "안 끝낸 것만": "未完了だけ", "이 블럭 다 끝냄": "このブロックは完了",
    "{n}블럭에 남은 거 {c}개, 다음 블럭으로 옮길까?": "ブロック{n}に残り{c}件。次のブロックへ移す？", "옮기고 넘어가기": "移して次へ", "그냥 넘어가기": "そのまま次へ", "취소": "キャンセル", "접기": "たたむ", "펼치기": "ひらく", "목록 개수": "表示数", "u 할 일 개수": "uタスクの表示数",
    "지난 날 남은 할 일 예시 넣기": "前日の残りの例を入れる", "(예시) 어제 못 한 자료 정리": "（例）昨日の資料整理", "(예시) 메일 하나 답장": "（例）メール1通に返信"
  };
  const DICT = { en: EN, ja: JA };
  const WEEK = { ko: ['일', '월', '화', '수', '목', '금', '토'], en: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], ja: ['日', '月', '火', '水', '木', '金', '土'] };

  function t(lang, s, vars) {
    let out = (lang !== 'ko' && DICT[lang] && DICT[lang][s]) || s;
    Object.entries(vars || {}).forEach(([k, v]) => { out = out.split('{' + k + '}').join(String(v)); });
    return out;
  }
  // swap every Korean text node / placeholder / title / aria-label on the page (remembering the Korean original)
  const ATTRS = ['placeholder', 'title', 'aria-label'];
  function translateDom(rootEl, lang) {
    const walker = document.createTreeWalker(rootEl, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(n => {
      if (n.parentElement && n.parentElement.closest('datalist, #taskList, #routines, #routineEditor, #profile, #bubble, #widget, #status, #testScenes, #testGallery, #charPick, #btPick, #timerTask, #timerRecent, #dialLabel, #noteList, #alarmList, #blocks, #blockNow, #calGrid, #calDay, #calTitle')) return;
      if (n.__ko === undefined) { if (!/[가-힣]/.test(n.nodeValue)) return; n.__ko = n.nodeValue; }
      const raw = n.__ko, lead = raw.match(/^\s*/)[0], trail = raw.match(/\s*$/)[0];
      n.nodeValue = lead + t(lang, raw.trim()) + trail;
    });
    rootEl.querySelectorAll('*').forEach(el => {
      ATTRS.forEach(a => {
        const key = 'ko' + a.replace(/[^a-z]/g, '');
        if (el.dataset[key] === undefined) { const v = el.getAttribute(a); if (!v || !/[가-힣]/.test(v)) return; el.dataset[key] = v; }
        el.setAttribute(a, t(lang, el.dataset[key]));
      });
    });
  }
  const api = { t, translateDom, week: (lang) => (WEEK[lang] || WEEK.ko).slice(), DICT };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.I18N = api;
})(typeof window !== 'undefined' ? window : globalThis);
