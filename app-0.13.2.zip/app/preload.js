// Bridge between the page and the main process — only these calls are exposed.
const { contextBridge, ipcRenderer, webFrame } = require('electron');

contextBridge.exposeInMainWorld('deskBuddy', {
  load: () => ipcRenderer.invoke('load'),
  save: (partial) => ipcRenderer.send('save', partial),
  setIgnoreMouse: (ignore) => ipcRenderer.send('set-ignore-mouse', ignore),
  dragStart: () => ipcRenderer.send('drag-start'),
  dragMove: () => ipcRenderer.send('drag-move'),
  dragEnd: () => ipcRenderer.send('drag-end'),
  onLayout: (fn) => ipcRenderer.on('layout', (e, l) => fn(l)),
  focusPanel: () => ipcRenderer.send('focus-panel'),
  media: (cmd) => ipcRenderer.send('media', cmd),
  showMenu: () => ipcRenderer.send('show-menu'),
  getVersion: () => ipcRenderer.invoke('get-version'),
  checkUpdate: () => ipcRenderer.send('update-check'),
  applyUpdate: () => ipcRenderer.send('update-apply'),
  onUpdate: (fn) => ipcRenderer.on('update', (e, u) => fn(u)),
  clearCache: () => webFrame.clearCache(),
  copyText: (text) => ipcRenderer.send('copy-text', text),
  saveText: (name, text) => ipcRenderer.invoke('save-text', name, text),
  setExtraWidth: (n) => ipcRenderer.send('set-extra-width', n),
  settingsChanged: (what) => ipcRenderer.send('settings-changed', what),
  getLogin: () => ipcRenderer.invoke('get-login'),
  setLogin: (on) => ipcRenderer.send('set-login', on),
  refreshWeather: () => ipcRenderer.send('refresh-weather'),
  onWeather: (fn) => ipcRenderer.on('weather', (e, w) => fn(w)),
  onBluetooth: (fn) => ipcRenderer.on('bluetooth', (e, list) => fn(list)),
  onSys: (fn) => ipcRenderer.on('sys', (e, s) => fn(s)),
  onIdle: (fn) => ipcRenderer.on('idle', (e, sec) => fn(sec)),
  onAway: (fn) => ipcRenderer.on('away', (e, v) => fn(v)),
  onMusic: (fn) => ipcRenderer.on('music', (e, info) => fn(info)),
  onCommand: (fn) => ipcRenderer.on('command', (e, cmd) => fn(cmd))
});
