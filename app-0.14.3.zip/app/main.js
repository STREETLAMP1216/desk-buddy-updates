// 책상 친구 — main process
// One transparent, always-on-top window in the bottom-right corner. Transparent
// parts let clicks through to whatever is underneath; only the character, the
// speech bubble and the task panel catch the mouse.
// ---------- self-update boot ----------
// Updates are unpacked into %APPDATA%\desk-buddy\versions\<version>\ (never over the running program).
// On start, the installed copy hands over to the newest unpacked version, if it's newer than itself.
if (!global.__deskbuddyBooted) {
  global.__deskbuddyBooted = true;
  try {
    const bfs = require('fs'), bpath = require('path'), { app: bapp } = require('electron');
    const vnum = (v) => String(v).split('.').map(Number);
    const gt = (a, b) => { const x = vnum(a), y = vnum(b); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
    const dir = bpath.join(bapp.getPath('appData'), 'desk-buddy', 'versions');
    const mine = require('./package.json').version;
    const best = (bfs.existsSync(dir) ? bfs.readdirSync(dir) : [])
      .filter(v => /^\d+\.\d+\.\d+$/.test(v) && gt(v, mine) && bfs.existsSync(bpath.join(dir, v, 'main.js')))
      .sort((a, b) => (gt(a, b) ? 1 : -1)).pop();
    if (best) { require(bpath.join(dir, best, 'main.js')); return; }
  } catch (e) { /* fall through: run this copy */ }
}

const { app, BrowserWindow, Tray, Menu, ipcMain, screen, powerMonitor, nativeImage, clipboard, dialog, globalShortcut } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

// the window can be gone while a last message from it is still on the way (closing, restarting after an update)
function live() { return !!(win && !win.isDestroyed()); }
// never show a crash dialog for that kind of late message; note it instead
process.on('uncaughtException', (e) => { try { fs.appendFileSync(path.join(app.getPath('userData'), 'error-log.txt'), `${new Date().toISOString()} ${e && e.stack || e}\n`); } catch (_) {} });
const APP_VERSION = require('./package.json').version;   // this copy's version (APP_VERSION is the installed one)
const WIN_W = 420;
const WIN_H = 720;
// while the settings are open the window grows sideways so the info-card preview can sit next to the panel
let extraW = 0;
const winW = () => WIN_W + extraW;

let win = null;
let tray = null;
let lastWeather = null;
let lastBt = null;
let lastGpu = -1, lastDgpu = -1, lastIgpu = -1;    // dgpu: the discrete GPU alone (-1 = only one GPU / unknown)
let lastPs = null;      // the PowerShell helper's own share, measured by helper.ps1
// how much this app itself uses: Electron's processes (main, page, GPU) + the PowerShell helpers.
// CPU is % of the whole machine (like Task Manager), memory in MB.
function selfLoad() {
  const cores = os.cpus().length || 1;
  let cpu = 0, mem = 0;
  for (const m of app.getAppMetrics()) {
    cpu += (m.cpu && m.cpu.percentCPUUsage) || 0;
    const mm = m.memory || {};
    mem += (mm.privateBytes || mm.workingSetSize || 0) / 1024;        // private memory (what Task Manager shows) when Windows reports it
  }
  cpu = cpu / cores;
  if (lastPs) { cpu += lastPs.cpu || 0; mem += lastPs.mem || 0; }
  return { cpu: Math.round(cpu * 10) / 10, mem: Math.round(mem) };
}
let sysTimer = null;
let state = null;            // persisted data (tasks, settings, window position)
let dataFile = null;

// ---------- persistence ----------
function defaultState() {
  return {
    version: 1,
    settings: {
      name: '시오리',          // 栞 — a bookmark: keeps your place and sends you back to the notebook
      chatter: 'normal',      // quiet | normal | chatty
      autoMusic: true,        // try to detect music playing on Windows
      lunch: '12:30',
      snack: '15:30',
      dinner: '18:30',
      wrapUp: '22:30',
      workStart: '09:00',
      workEnd: '22:00',
      routines: null,         // null = default (가계부·일기 매일, 운동 월~토)
      city: '서울',
      weather: true,
      btBattery: true,
      sysInfo: true,          // CPU · RAM · GPU in the panel, and reactions
      alwaysOnTop: true
    },
    days: {},                 // 'YYYY-MM-DD' -> { tasks: [...], routines: {...} }
    pos: null                 // last window position
  };
}

function loadState() {
  dataFile = path.join(app.getPath('userData'), 'desk-buddy.json');
  try {
    const raw = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
    const base = defaultState();
    state = { ...base, ...raw, settings: { ...base.settings, ...(raw.settings || {}) } };
    if (!state.settings.name) state.settings.name = base.settings.name;
  } catch (e) {
    state = defaultState();
  }
}

let saveTimer = null;
function saveState() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      fs.mkdirSync(path.dirname(dataFile), { recursive: true });
      const tmp = dataFile + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(state, null, 2), 'utf8');
      fs.renameSync(tmp, dataFile);
    } catch (e) {
      console.error('save failed', e);
    }
  }, 200);
}

// ---------- window ----------
// ---------- where the character sits ----------
// The window is a fixed 420x720 transparent box. The character lives in a 240px-wide slot in one of its
// corners; speech bubble, task panel and info card take the rest. Which corner depends on where the
// character is on screen (layout), so near the top/left edges everything flips to stay visible.
// Positions are remembered as the character's own centre, so a flip never makes her jump.
const SLOT = 240, EDGE = 6;
const CHAR_H = { s: 170, m: 220, l: 260 };
let layout = { h: 'right', v: 'bottom' };
const charH = () => state.settings.charPx || CHAR_H[state.settings.charSize] || 220;
function anchor(l) {                       // character centre inside the window
  const h = charH();
  return { x: l.h === 'right' ? winW() - EDGE - SLOT / 2 : EDGE + SLOT / 2, y: l.v === 'bottom' ? WIN_H - EDGE - h / 2 : EDGE + h / 2 };
}
function workAreaAt(c) { return screen.getDisplayNearestPoint({ x: Math.round(c.x), y: Math.round(c.y) }).workArea; }
function defaultChar() {
  const wa = screen.getPrimaryDisplay().workArea;
  return { x: wa.x + wa.width - EDGE - SLOT / 2 - 2, y: wa.y + wa.height - EDGE - charH() / 2 };
}
function charCenter() {
  const [x, y] = win.getPosition(); const a = anchor(layout);
  return { x: x + a.x, y: y + a.y };
}
function chooseLayout(c) {
  const wa = workAreaAt(c), h = charH();
  let lh = layout.h, lv = layout.v;
  const mid = wa.x + wa.width / 2;
  if (c.x < mid - 40) lh = 'left'; else if (c.x > mid + 40) lh = 'right';         // a little slack so it doesn't flicker at the middle
  const above = c.y - h / 2 - wa.y, below = wa.y + wa.height - (c.y + h / 2);
  if (lv === 'bottom' && above < 320 && below > above) lv = 'top';
  else if (lv === 'top' && below < 320 && above > below) lv = 'bottom';
  return { h: lh, v: lv };
}
function placeChar(c) {
  const wa = workAreaAt(c), h = charH();
  // keep the character itself on screen
  c = { x: Math.min(Math.max(c.x, wa.x + 70), wa.x + wa.width - 70), y: Math.min(Math.max(c.y, wa.y + h / 2), wa.y + wa.height - h / 2) };
  const l = chooseLayout(c);
  const changed = l.h !== layout.h || l.v !== layout.v;
  layout = l;
  const a = anchor(l);
  // setBounds with the fixed size: setPosition alone lets the window creep on scaled (125%/150%) displays
  const wx = Math.round(c.x - a.x), wy = Math.round(c.y - a.y);
  win.setBounds({ x: wx, y: wy, width: winW(), height: WIN_H });
  // the part of the window that is actually on screen, so the page can fit the panel and bubble inside it
  const vis = { top: Math.max(0, wa.y - wy), bottom: Math.min(WIN_H, wa.y + wa.height - wy), left: Math.max(0, wa.x - wx), right: Math.min(winW(), wa.x + wa.width - wx) };
  const key = JSON.stringify([layout, vis]);
  if (changed || key !== lastLayoutKey) { lastLayoutKey = key; send('layout', Object.assign({ vis }, layout)); }
  return c;
}
let lastLayoutKey = '';
let trayMenu = null;
// right-clicking the character opens the same menu as the tray icon
ipcMain.on('show-menu', () => { if (live()) { refreshTrayMenu(); if (trayMenu) trayMenu.popup({ window: win }); } });
function saveCharPos() { state.charPos = charCenter(); state.layout = layout; saveState(); }

function createWindow() {
  if (state.layout) layout = state.layout;
  let start = state.charPos;
  if (!start && state.pos) { const a = anchor(layout); start = { x: state.pos.x + a.x, y: state.pos.y + a.y }; }   // older versions saved the window corner
  if (!start || !screen.getAllDisplays().some(d => { const w = d.workArea; return start.x > w.x && start.x < w.x + w.width && start.y > w.y && start.y < w.y + w.height; })) start = defaultChar();
  const a0 = anchor(layout);
  win = new BrowserWindow({
    x: Math.round(start.x - a0.x), y: Math.round(start.y - a0.y), width: WIN_W, height: WIN_H,
    icon: characterIcon('window'),
    transparent: true,
    frame: false,
    resizable: false,
    hasShadow: false,
    alwaysOnTop: state.settings.alwaysOnTop !== false,
    skipTaskbar: true,
    focusable: true,
    backgroundColor: '#00000000',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      spellcheck: false,              // no dictionaries in memory (a few typed words don't need them)
      nodeIntegration: false,
      sandbox: true
    }
  });
  applyAlwaysOnTop();
  win.setIgnoreMouseEvents(true, { forward: true });
  win.webContents.on('did-finish-load', () => {
    lastLayoutKey = '';
    placeChar(start);
    if (lastWeather) wsend('weather', lastWeather);
    if (lastBt) wsend('bluetooth', lastBt);
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  // development check of the self-update: DESKBUDDY_TEST_UPDATE=1 checks, installs and restarts at once
  if (process.env.DESKBUDDY_TEST_UPDATE) {
    console.log('[boot] running', APP_VERSION, 'from', __dirname);
    try { fs.appendFileSync(path.join(app.getPath('userData'), 'boot-test.txt'), APP_VERSION + ' ' + __dirname + '\n'); } catch (e) {}
    setTimeout(() => checkUpdate(true).then(() => { if (pendingUpdate) applyUpdate(); else setTimeout(() => app.exit(0), 1500); }), 3000);
  }

  // self-check used during development: DESKBUDDY_SMOKE=<png path> saves a capture and quits
  if (process.env.DESKBUDDY_SMOKE) {
    win.webContents.on('console-message', (e, level, msg) => console.log('[page]', msg));
    setTimeout(async () => {
      await win.webContents.executeJavaScript("window.__buddy && (window.__buddy.switchCharacter('fubuki'), window.__buddy.startTest(), window.__buddy.playScene(10), 'ok:' + window.__buddy.ui.shownName)").then(r => console.log('[smoke] renderer', r));
      // layout check: drag her to the top-left corner and back
      placeChar({ x: 150, y: 150 }); console.log('[smoke] top-left', JSON.stringify(layout), JSON.stringify(charCenter()), JSON.stringify(win.getBounds()));
      placeChar(defaultChar()); console.log('[smoke] default', JSON.stringify(layout), JSON.stringify(charCenter()), JSON.stringify(win.getBounds()));
      if (process.env.DESKBUDDY_UPDATE_BASE) checkUpdate(true).then(() => console.log('[smoke] update check', JSON.stringify(pendingUpdate && pendingUpdate.version)));
      placeChar({ x: 900, y: 380 }); console.log('[smoke] mid-high', JSON.stringify(layout), JSON.stringify(win.getBounds()));
      console.log('[smoke] hotkey', hotkeyNow, hotkeyNow && globalShortcut.isRegistered(hotkeyNow));
      await win.webContents.executeJavaScript("window.__buddy.closePanel(); 1"); summon(); await new Promise(r => setTimeout(r, 400));
      console.log('[smoke] after hotkey panel open:', await win.webContents.executeJavaScript("window.__buddy.ui.panelOpen + ' focus:' + (document.activeElement && document.activeElement.id)"));
      await win.webContents.executeJavaScript("window.__buddy.openPanel(); window.__buddy.nudge(); 1");
      setTimeout(async () => {
        console.log('[smoke] self load', JSON.stringify(selfLoad()));
        const img = await win.webContents.capturePage();
        fs.writeFileSync(process.env.DESKBUDDY_SMOKE, img.toPNG());
        console.log('[smoke] saved; data file', dataFile);
        app.quit();
      }, 1200);
    }, 2500);
  }
  win.on('moved', () => { if (!dragFrom) saveCharPos(); });
  // development: DESKBUDDY_PROFILE=1 prints this app's own load, moving and holding still
  if (process.env.DESKBUDDY_PROFILE) {
    const sample = (label) => { selfLoad(); setTimeout(() => console.log('[profile]', label, JSON.stringify(selfLoad())), 5000); };
    setTimeout(() => sample('moving'), 8000);
    setTimeout(() => console.log('[profile] per process', JSON.stringify(app.getAppMetrics().map(m => [m.type, Math.round(m.memory.workingSetSize / 1024), m.memory.privateBytes ? Math.round(m.memory.privateBytes / 1024) : null]))), 12000);
    setTimeout(() => win.webContents.executeJavaScript("window.__buddy && window.__buddy.setStill && window.__buddy.setStill(true)"), 14000);
    setTimeout(() => sample('still'), 16000);
    setTimeout(() => app.quit(), 23000);
  }
}

// ---------- system signals ----------
function startIdleWatch() {
  setInterval(() => {
    if (!live() || win.isDestroyed()) return;
    wsend('idle', powerMonitor.getSystemIdleTime());
  }, 1000);
  powerMonitor.on('lock-screen', () => wsend('away', true));
  powerMonitor.on('unlock-screen', () => wsend('away', false));
  powerMonitor.on('suspend', () => wsend('away', true));
  powerMonitor.on('resume', () => wsend('away', false));
}

// ---------- Windows helper ----------
// ONE PowerShell process (helper.ps1) does music, GPU and Bluetooth; it used to be three, which cost ~200MB.
// It only runs while something needs it, and it's told which parts to do with a "config" line.
let helperProc = null;
let lastMusicNote = '';
function helperNeeds() {
  const st = state.settings;
  return { music: !!(st.autoMusic || (st.show || []).includes('music')), gpu: !!st.sysInfo, bt: !!st.btBattery };
}
function helperWrite(line) { if (helperProc) { try { helperProc.stdin.write(line + '\n'); } catch (e) {} } }
function helperConfig() {
  if (process.platform !== 'win32') return;
  const n = helperNeeds();
  if (!n.music && !n.gpu && !n.bt) { stopHelper(); return; }
  if (!helperProc) startHelper();
  helperWrite(`config music=${n.music ? 1 : 0} gpu=${n.gpu ? 1 : 0} bt=${n.bt ? 1 : 0}`);
  if (!n.music) send('music', { playing: false });
  if (!n.gpu) lastGpu = -1;
}
function startHelper() {
  try {
    helperProc = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(__dirname, 'helper.ps1')],
      { windowsHide: true, stdio: ['pipe', 'pipe', 'ignore'] });
  } catch (e) { helperProc = null; return; }
  let buf = '';
  helperProc.stdout.setEncoding('utf8');
  helperProc.stdout.on('data', chunk => {
    buf += chunk;
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
      if (!line) continue;
      let j; try { j = JSON.parse(line); } catch (e) { continue; }
      if (j.type === 'music') {
        send('music', j);
        // what the music reader last saw, for troubleshooting when the song name doesn't show
        const note = JSON.stringify({ app: j.app, playing: j.playing, paused: j.paused, title: j.title, artist: j.artist, err: j.err, sessions: j.sessions });
        if (note !== lastMusicNote) { lastMusicNote = note; fs.writeFile(path.join(app.getPath('userData'), 'music-debug.txt'), new Date().toISOString() + '\n' + note, () => {}); }
      }
      else if (j.type === 'gpu') { lastGpu = typeof j.gpu === 'number' ? j.gpu : -1; lastDgpu = typeof j.dgpu === 'number' ? j.dgpu : -1; lastIgpu = typeof j.igpu === 'number' ? j.igpu : -1; if (j.ps) lastPs = j.ps; }
      else if (j.type === 'bt') onBluetoothReport(j);
    }
  });
  helperProc.on('exit', () => { helperProc = null; lastPs = null; });
}
function stopHelper() {
  if (helperProc) { try { helperProc.stdin.end(); helperProc.kill(); } catch (e) {} helperProc = null; }
  lastPs = null;
}
// kept names, so the rest of the app reads the same
function startMusicWatch() { helperConfig(); }
function stopMusicWatch() { stopHelper(); }
function pollBluetooth() { helperConfig(); if (state.settings.btBattery) helperWrite('bt'); }
const btSeen = new Map();   // name -> { dev, t: last time it looked connected }
function onBluetoothReport(raw) {
  const list = raw.devices || [];
  if (raw.debug) fs.writeFile(path.join(app.getPath('userData'), 'bt-debug.txt'), new Date().toISOString() + '\n' + raw.debug, () => {});
  // only devices connected right now; if Windows can't tell for any of them, show them all rather than nothing
  const known = list.filter(x => x && x.name);
  const unsure = known.every(x => x.connected === null || x.connected === undefined);
  // Windows often reports a sleeping mouse or earbuds as "disconnected" for one check; so a device that was
  // connected stays on the list until it has looked disconnected for 12 minutes (about two checks) in a row
  const now = Date.now();
  known.forEach(x => {
    if (unsure || x.connected === true) btSeen.set(x.name, { dev: x, t: now });
    else if (btSeen.has(x.name)) btSeen.get(x.name).dev = x;        // keep the newest battery level
  });
  for (const [name, v] of btSeen) if (now - v.t > 12 * 60 * 1000) btSeen.delete(name);
  lastBt = [...btSeen.values()].map(v => ({ name: v.dev.name, level: v.dev.level, connected: true }));
  send('bluetooth', lastBt);
}

function applyAlwaysOnTop() {
  if (!live()) return;
  const on = state.settings.alwaysOnTop !== false;
  win.setAlwaysOnTop(on, 'floating');
}

// Weather: Open-Meteo (free, no account). Only the city's coordinates are sent.
const CITIES = {
  '서울': [37.5665, 126.9780], '부산': [35.1796, 129.0756], '인천': [37.4563, 126.7052], '대구': [35.8714, 128.6014],
  '대전': [36.3504, 127.3845], '광주': [35.1595, 126.8526], '울산': [35.5384, 129.3114], '세종': [36.4800, 127.2890],
  '수원': [37.2636, 127.0286], '성남': [37.4200, 127.1267], '고양': [37.6584, 126.8320], '용인': [37.2411, 127.1776],
  '청주': [36.6424, 127.4890], '전주': [35.8242, 127.1480], '춘천': [37.8813, 127.7298], '강릉': [37.7519, 128.8761],
  '제주': [33.4996, 126.5312]
};
async function coordsFor(city) {
  const c = String(city || '').trim();
  if (CITIES[c]) return { name: c, lat: CITIES[c][0], lon: CITIES[c][1] };
  const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(c)}&count=1&language=ko&format=json`);
  const j = await r.json();
  const g = j.results && j.results[0];
  return g ? { name: g.name, lat: g.latitude, lon: g.longitude } : null;
}
async function fetchWeather() {
  if (!state.settings.weather) return;
  try {
    const at = await coordsFor(state.settings.city);
    if (!at) { send('weather', { error: '지역을 찾지 못했어요' }); return; }
    const u = `https://api.open-meteo.com/v1/forecast?latitude=${at.lat}&longitude=${at.lon}` +
      '&current=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=1';
    const j = await (await fetch(u)).json();
    lastWeather = {
      city: at.name,
      temp: Math.round(j.current.temperature_2m),
      code: j.current.weather_code,
      todayCode: j.daily.weather_code[0],
      max: Math.round(j.daily.temperature_2m_max[0]),
      min: Math.round(j.daily.temperature_2m_min[0]),
      rainChance: j.daily.precipitation_probability_max ? j.daily.precipitation_probability_max[0] : null,
      at: Date.now()
    };
    send('weather', lastWeather);
  } catch (e) {
    send('weather', { error: '날씨를 못 불러왔어요' });
  }
}
let weatherTimer = null;
function startWeather() {
  clearInterval(weatherTimer);
  lastWeather = null;
  fetchWeather();
  weatherTimer = setInterval(fetchWeather, 30 * 60 * 1000);
}

// System load: CPU and memory from Node, GPU from Windows counters (helper.ps1).
const os = require('os');
let prevCpu = null;
function cpuPercent() {
  const now = os.cpus().reduce((a, c) => {
    const t = c.times; a.idle += t.idle; a.total += t.user + t.nice + t.sys + t.irq + t.idle; return a;
  }, { idle: 0, total: 0 });
  let pct = null;
  if (prevCpu) {
    const dt = now.total - prevCpu.total, di = now.idle - prevCpu.idle;
    pct = dt > 0 ? Math.round(100 * (1 - di / dt)) : null;
  }
  prevCpu = now;
  return pct;
}
function startSysmon() {
  stopSysmon();
  if (!state.settings.sysInfo) { send('sys', null); helperConfig(); return; }
  cpuPercent();
  sysTimer = setInterval(() => {
    const cpu = cpuPercent();
    const ram = Math.round(100 * (1 - os.freemem() / os.totalmem()));
    send('sys', { cpu, ram, gpu: lastGpu >= 0 ? lastGpu : null, dgpu: lastDgpu >= 0 ? lastDgpu : null, igpu: lastIgpu >= 0 ? lastIgpu : null, self: selfLoad(), t: Date.now() });
  }, 3000);
  helperConfig();
}
function stopSysmon() {
  clearInterval(sysTimer); sysTimer = null;
  lastGpu = -1; lastDgpu = -1; lastIgpu = -1;
}

function wsend(...a) { if (live()) win.webContents.send(...a); }
function send(channel, payload) {
  wsend(channel, payload);
}

// ---------- tray ----------
// tray / window icon = the chosen character's face (falls back to the generic icon)
function characterIcon(kind) {
  const ch = state.settings.character || 'shiori';
  const f = path.join(__dirname, 'renderer', 'assets', kind === 'tray' ? `tray_${ch}.png` : `icon_${ch}.png`);
  const img = nativeImage.createFromPath(f);
  return img.isEmpty() ? nativeImage.createFromPath(path.join(__dirname, 'renderer', 'assets', kind === 'tray' ? 'tray.png' : 'icon.png')) : img;
}
function applyCharacterIcon() {
  if (tray) tray.setImage(characterIcon('tray'));
  if (live() && !win.isDestroyed()) win.setIcon(characterIcon('window'));
}

function buildTray() {
  const icon = characterIcon('tray');
  tray = new Tray(icon.isEmpty() ? nativeImage.createEmpty() : icon);
  tray.setToolTip(state.settings.name || '책상 친구');
  refreshTrayMenu();
  tray.on('click', () => wsend('command', 'toggle-panel'));
}

// tray menu and dialogs follow the language chosen in settings (Korean text is the key)
const MENU_TEXT = {
  en: {
    '폰과 지금 동기화': 'Sync with phone now', '할 일 열기': 'Open tasks', '지금 말 걸어줘': 'Talk to me now', '캐릭터 소개 · 바꾸기': 'Character · switch', '상황 테스트': 'Situation test',
    '공부 모드': 'Study mode', '음악 모드 (수동)': 'Music mode (manual)', '움직임 멈추기': 'Hold still', '클릭 통과 (Ctrl 누를 때만 잡기)': 'Click-through (grab with Ctrl)',
    '음악 자동 감지': 'Detect music', '항상 위에 표시': 'Always on top', '1시간 숨기기': 'Hide for 1 hour', '보이기': 'Show',
    '오른쪽 아래로 되돌리기': 'Back to bottom-right', '컴퓨터 켤 때 자동 실행': 'Start with Windows', '데이터 폴더 열기': 'Open data folder',
    '책상 친구 지우기…': 'Uninstall Desk Buddy…', '업데이트 확인': 'Check for updates', '종료': 'Quit', '책상 친구': 'Desk Buddy', '책상 친구 지우기': 'Uninstall Desk Buddy',
    'DeskBuddy 폴더의 uninstall.bat 를 실행해 주세요.': 'Run uninstall.bat in the DeskBuddy folder.',
    '{name}를 이 컴퓨터에서 지울까요?': 'Remove {name} from this computer?',
    '프로그램, 바로가기, 자동 실행을 지워요.\n할 일 기록(%APPDATA%\\desk-buddy)은 어떻게 할까요?': 'This removes the app, its shortcuts and auto-start.\nWhat about your task records (%APPDATA%\\desk-buddy)?',
    '기록은 남기고 지우기': 'Keep my records', '기록까지 전부 지우기': 'Delete everything', '취소': 'Cancel'
  },
  ja: {
    '폰과 지금 동기화': 'スマホと今すぐ同期', '할 일 열기': 'タスクを開く', '지금 말 걸어줘': '今すぐ話しかけて', '캐릭터 소개 · 바꾸기': 'キャラ紹介 · 切り替え', '상황 테스트': '状況テスト',
    '공부 모드': '勉強モード', '음악 모드 (수동)': '音楽モード（手動）', '움직임 멈추기': '動きを止める', '클릭 통과 (Ctrl 누를 때만 잡기)': 'クリックを通す（Ctrl でつかむ）',
    '음악 자동 감지': '音楽を自動で検出', '항상 위에 표시': '常に手前に表示', '1시간 숨기기': '1時間かくす', '보이기': '表示する',
    '오른쪽 아래로 되돌리기': '右下に戻す', '컴퓨터 켤 때 자동 실행': 'Windows 起動時に開く', '데이터 폴더 열기': 'データフォルダを開く',
    '책상 친구 지우기…': 'アンインストール…', '업데이트 확인': 'アップデートを確認', '종료': '終了', '책상 친구': 'デスクの友だち', '책상 친구 지우기': 'アンインストール',
    'DeskBuddy 폴더의 uninstall.bat 를 실행해 주세요.': 'DeskBuddy フォルダの uninstall.bat を実行してください。',
    '{name}를 이 컴퓨터에서 지울까요?': '{name}をこのパソコンから削除しますか？',
    '프로그램, 바로가기, 자동 실행을 지워요.\n할 일 기록(%APPDATA%\\desk-buddy)은 어떻게 할까요?': 'アプリ、ショートカット、自動起動を削除します。\nタスクの記録（%APPDATA%\\desk-buddy）はどうしますか？',
    '기록은 남기고 지우기': '記録は残す', '기록까지 전부 지우기': '全部削除する', '취소': 'キャンセル'
  }
};
const M = (s) => ((MENU_TEXT[state.settings.lang] || {})[s]) || s;

function refreshTrayMenu() {
  const login = app.getLoginItemSettings();
  const menu = Menu.buildFromTemplate([
    { label: M('할 일 열기'), click: () => { show(); wsend('command', 'open-panel'); } },
    { label: M('폰과 지금 동기화'), click: () => wsend('command', 'sync-now') },
    { label: M('지금 말 걸어줘'), click: () => { show(); wsend('command', 'nudge'); } },
    { label: M('캐릭터 소개 · 바꾸기'), click: () => { show(); wsend('command', 'profile'); } },
    { label: M('상황 테스트'), click: () => { show(); wsend('command', 'test'); } },
    { type: 'separator' },
    { label: M('공부 모드'), type: 'checkbox', checked: !!state.study, click: (item) => { state.study = item.checked; saveState(); wsend('command', item.checked ? 'study-on' : 'study-off'); } },
    { label: M('음악 모드 (수동)'), type: 'checkbox', checked: !!state.musicManual, click: (item) => { state.musicManual = item.checked; saveState(); wsend('command', item.checked ? 'music-on' : 'music-off'); } },
    { label: M('움직임 멈추기'), type: 'checkbox', checked: !!state.settings.still, click: (item) => wsend('command', 'set:still:' + item.checked) },
    { label: M('클릭 통과 (Ctrl 누를 때만 잡기)'), type: 'checkbox', checked: !!state.settings.clickThrough, click: (item) => wsend('command', 'set:clickThrough:' + item.checked) },
    { label: M('음악 자동 감지'), type: 'checkbox', checked: !!state.settings.autoMusic, click: (item) => { wsend('command', 'set:autoMusic:' + item.checked); if (!item.checked) wsend('music', { playing: false }); } },
    { label: M('항상 위에 표시'), type: 'checkbox', checked: state.settings.alwaysOnTop !== false, click: (item) => wsend('command', 'set:alwaysOnTop:' + item.checked) },
    { type: 'separator' },
    { label: M('1시간 숨기기'), click: () => { win.hide(); setTimeout(show, 60 * 60 * 1000); } },
    { label: M('보이기'), click: show },
    { label: M('오른쪽 아래로 되돌리기'), click: () => { layout = { h: 'right', v: 'bottom' }; lastLayoutKey = ''; placeChar(defaultChar()); saveCharPos(); } },
    { label: M('컴퓨터 켤 때 자동 실행'), type: 'checkbox', checked: login.openAtLogin, click: (item) => { app.setLoginItemSettings({ openAtLogin: item.checked }); } },
    { type: 'separator' },
    { label: M('데이터 폴더 열기'), click: () => require('electron').shell.showItemInFolder(dataFile) },
    { label: M('업데이트 확인') + `  (v${APP_VERSION})`, click: () => { show(); checkUpdate(true); } },
    { label: M('책상 친구 지우기…'), click: uninstall },
    { label: M('종료'), click: () => app.quit() }
  ]);
  tray.setContextMenu(menu);
  trayMenu = menu;
}

// uninstall: confirm, switch off auto-start, then hand over to uninstall.ps1 (next to install.bat) and quit
async function uninstall() {
  const { dialog } = require('electron');
  const root = path.join(__dirname, '..', '..', '..');          // DeskBuddy\runtime\resources\app → DeskBuddy
  const script = path.join(root, 'uninstall.ps1');
  if (!fs.existsSync(script)) {
    dialog.showMessageBox({ type: 'info', message: M('DeskBuddy 폴더의 uninstall.bat 를 실행해 주세요.') });
    return;
  }
  const r = await dialog.showMessageBox({
    type: 'question',
    title: M('책상 친구 지우기'),
    message: M('{name}를 이 컴퓨터에서 지울까요?').replace('{name}', state.settings.name || M('책상 친구')),
    detail: M('프로그램, 바로가기, 자동 실행을 지워요.\n할 일 기록(%APPDATA%\\desk-buddy)은 어떻게 할까요?'),
    buttons: [M('기록은 남기고 지우기'), M('기록까지 전부 지우기'), M('취소')],
    defaultId: 0, cancelId: 2, noLink: true
  });
  if (r.response === 2) return;
  app.setLoginItemSettings({ openAtLogin: false });
  const args = ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', script, '-FromApp'];
  if (r.response === 1) args.push('-RemoveData');
  require('child_process').spawn('powershell.exe', args, { detached: true, stdio: 'ignore', cwd: root }).unref();
  app.quit();
}

function show() {
  if (!live()) return;
  win.showInactive();
  applyAlwaysOnTop();
}

// a global shortcut (default Ctrl+Alt+D) brings her to the front with the task list open, ready to type
const DEFAULT_HOTKEY = 'Control+Alt+D';
let hotkeyNow = null;
function setHotkey(acc) {
  if (hotkeyNow) { try { globalShortcut.unregister(hotkeyNow); } catch (e) {} hotkeyNow = null; }
  if (!acc) return true;
  let ok = false;
  try { ok = globalShortcut.register(acc, summon); } catch (e) { ok = false; }
  if (ok) hotkeyNow = acc;
  return ok;
}
function summon() {
  if (!live()) return;
  const wasFront = win.isVisible() && win.isFocused();   // already in front: the shortcut closes it again
  win.show(); win.moveTop(); win.focus();
  applyAlwaysOnTop();
  wsend('command', wasFront ? 'hotkey-close' : 'hotkey');
}
ipcMain.handle('set-hotkey', (e, acc) => {
  const ok = setHotkey(acc || '');
  if (!ok) setHotkey(state.settings.hotkey === undefined ? DEFAULT_HOTKEY : state.settings.hotkey);   // taken: keep the old one
  return ok;
});

// ---------- IPC ----------
ipcMain.handle('load', () => state);
// memo export: a normal "save as" window, the file is written as UTF-8 with a BOM so Notepad reads Korean right
ipcMain.handle('save-text', async (e, name, text) => {
  const safe = String(name || '메모').replace(/[\\/:*?"<>|]/g, '_').slice(0, 60) || '메모';
  const r = await dialog.showSaveDialog(live() ? win : undefined, {
    defaultPath: path.join(app.getPath('documents'), safe + '.txt'),
    filters: [{ name: 'Text', extensions: ['txt'] }]
  });
  if (r.canceled || !r.filePath) return { ok: false };
  fs.writeFileSync(r.filePath, '\ufeff' + String(text).replace(/\r?\n/g, '\r\n'), 'utf8');
  return { ok: true, path: r.filePath };
});
ipcMain.on('save', (e, partial) => {
  state = { ...state, ...partial };
  saveState();
});
ipcMain.on('set-ignore-mouse', (e, ignore) => {
  if (!live()) return;
  win.setIgnoreMouseEvents(!!ignore, { forward: true });
});
// dragging: follow the real cursor from where the drag started (no accumulated deltas → no drifting sideways)
let dragFrom = null;
ipcMain.on('drag-start', () => {
  if (!live()) return;
  const p = screen.getCursorScreenPoint();
  dragFrom = { px: p.x, py: p.y, c: charCenter() };
});
ipcMain.on('drag-move', () => {
  if (!live() || !dragFrom) return;
  const p = screen.getCursorScreenPoint();
  placeChar({ x: dragFrom.c.x + p.x - dragFrom.px, y: dragFrom.c.y + p.y - dragFrom.py });
});
ipcMain.on('set-extra-width', (e, n) => {
  n = Math.max(0, Math.min(400, Math.round(n) || 0));
  if (!live() || n === extraW) return;
  const c = charCenter(); extraW = n; placeChar(c);
});
ipcMain.on('drag-end', () => { if (dragFrom) { dragFrom = null; saveCharPos(); } });
ipcMain.on('drag-by', () => {});   // old API, unused
// play/pause/skip from the info card
ipcMain.on('media', (e, cmd) => {
  if (['toggle', 'next', 'prev'].includes(cmd)) helperWrite(cmd);
});
ipcMain.on('focus-panel', () => { if (live()) win.focus(); });
ipcMain.on('copy-text', (e, text) => clipboard.writeText(String(text)));
ipcMain.on('settings-changed', (e, what) => {
  refreshTrayMenu();
  if (tray) tray.setToolTip(state.settings.name || '책상 친구');
  applyCharacterIcon();
  if (live() && what === 'size') { placeChar(charCenter()); saveCharPos(); }
  applyAlwaysOnTop();
  if (!what || what === 'music') startMusicWatch();
  if (!what || what === 'weather') startWeather();
  if (!what || what === 'bt') pollBluetooth();
  if (!what || what === 'sys') startSysmon();
});
ipcMain.handle('get-login', () => app.getLoginItemSettings().openAtLogin);
ipcMain.handle('get-version', () => APP_VERSION);
ipcMain.on('update-check', () => checkUpdate(true));
ipcMain.on('update-apply', () => applyUpdate());

// ---------- updates ----------
// The app asks <updateBase>/latest.json (a hidden Netlify address, set in package.json) whether there's a newer
// version: { "version": "0.7.0", "url": "desk-buddy-app-0.7.0.zip", "sha256": "…", "notes": { "ko": "…" } }.
// Only the app part (a few MB) is replaced; the Electron runtime and your data stay as they are.
const UPDATE_BASE = (process.env.DESKBUDDY_UPDATE_BASE || require('./package.json').updateBase || '').replace(/\/$/, '');
let pendingUpdate = null;
function newer(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0); }
  return false;
}
async function checkUpdate(manual) {
  if (!UPDATE_BASE) { if (manual) send('update', { state: 'unset' }); return; }
  try {
    const r = await fetch(`${UPDATE_BASE}/latest.json?t=${Date.now()}`, { cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json();
    state.lastUpdateCheck = Date.now(); saveState();
    if (j.version && newer(j.version, APP_VERSION)) {
      pendingUpdate = j;
      send('update', { state: 'available', version: j.version, current: APP_VERSION, notes: j.notes || {} });
    } else if (manual) send('update', { state: 'latest', version: APP_VERSION });
  } catch (e) {
    const message = String(e.message || e);
    fs.writeFile(path.join(app.getPath('userData'), 'update-debug.txt'), `${new Date().toISOString()}\n${UPDATE_BASE}/latest.json\n${message}\n${e.cause ? String(e.cause.code || e.cause) : ''}`, () => {});
    if (manual) send('update', { state: 'error', message, missing: /HTTP 404/.test(message) });
  }
}
async function applyUpdate() {
  const j = pendingUpdate;
  if (!j) return checkUpdate(true);
  const vdir = path.join(app.getPath('userData'), 'versions');
  const log = (m) => { try { fs.appendFileSync(path.join(app.getPath('userData'), 'update-debug.txt'), `${new Date().toISOString()} ${m}\n`); } catch (e) {} };
  try {
    send('update', { state: 'downloading', version: j.version });
    const url = /^https?:/.test(j.url) ? j.url : `${UPDATE_BASE}/${j.url}`;
    const r = await fetch(url, { cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const buf = Buffer.from(await r.arrayBuffer());
    const sha = require('crypto').createHash('sha256').update(buf).digest('hex');
    if (j.sha256 && sha.toLowerCase() !== String(j.sha256).toLowerCase()) throw new Error('checksum mismatch');
    fs.mkdirSync(vdir, { recursive: true });
    const tmp = path.join(vdir, `_${j.version}`), zip = tmp + '.zip', dest = path.join(vdir, j.version);
    fs.rmSync(tmp, { recursive: true, force: true }); fs.writeFileSync(zip, buf);
    // unpack next to the data (nothing there is in use), check it, then move it into place
    const { spawnSync } = require('child_process');
    const res = process.platform === 'win32'
      ? spawnSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', `Expand-Archive -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${tmp.replace(/'/g, "''")}' -Force`], { windowsHide: true, timeout: 120000 })
      : spawnSync('unzip', ['-q', '-o', zip, '-d', tmp], { timeout: 120000 });
    if (res.status !== 0) throw new Error('unpack failed: ' + String(res.stderr || res.error || '').slice(0, 200));
    if (!fs.existsSync(path.join(tmp, 'app', 'main.js'))) throw new Error('bad package');
    fs.rmSync(dest, { recursive: true, force: true });
    fs.renameSync(path.join(tmp, 'app'), dest);
    fs.rmSync(tmp, { recursive: true, force: true }); fs.rmSync(zip, { force: true });
    // keep only this new one and the one running now
    for (const v of fs.readdirSync(vdir)) if (v !== j.version && v !== APP_VERSION) fs.rmSync(path.join(vdir, v), { recursive: true, force: true });
    log(`installed ${j.version} into ${dest}`);
    send('update', { state: 'restarting', version: j.version });
    // give up the single-instance lock first, or the new copy would see this one still running and quit
    setTimeout(() => {
      try { app.releaseSingleInstanceLock(); } catch (e) {}
      app.relaunch({ args: process.argv.slice(1).filter(x => x !== '--after-update').concat(['--after-update']) });
      app.exit(0);
    }, 1500);
  } catch (e) {
    log('update failed: ' + (e.message || e));
    send('update', { state: 'error', message: String(e.message || e) });
  }
}
function scheduleUpdateChecks() {
  const auto = () => state.settings.autoUpdate !== false;
  setTimeout(() => { if (auto()) checkUpdate(false); }, 60 * 1000);                 // a minute after starting
  setInterval(() => { if (auto()) checkUpdate(false); }, 6 * 60 * 60 * 1000);      // and every 6 hours (it only says something when there's news)
}
ipcMain.on('set-login', (e, on) => { app.setLoginItemSettings({ openAtLogin: !!on }); refreshTrayMenu(); });
ipcMain.on('refresh-weather', () => fetchWeather());

// ---------- app ----------
// keep memory small: a lean JS heap and a single page process
app.commandLine.appendSwitch('js-flags', '--max-old-space-size=96');
app.commandLine.appendSwitch('renderer-process-limit', '1');
// keep data in %APPDATA%\desk-buddy no matter how the app folder is named
app.setPath('userData', path.join(app.getPath('appData'), 'desk-buddy'));

// right after an update the old copy may still be closing: wait for it (up to 8 s) instead of giving up
function singleLock() {
  if (app.requestSingleInstanceLock()) return true;
  if (!process.argv.includes('--after-update')) return false;
  const pause = new Int32Array(new SharedArrayBuffer(4));
  for (let i = 0; i < 32; i++) { Atomics.wait(pause, 0, 0, 250); if (app.requestSingleInstanceLock()) return true; }
  return false;
}
if (!singleLock()) {
  app.quit();
} else {
  app.on('second-instance', () => { show(); wsend('command', 'open-panel'); });
  app.whenReady().then(() => {
    if (process.platform === 'win32') app.setAppUserModelId('desk-buddy');
    loadState();
    createWindow();
    buildTray();
    startIdleWatch();
    startMusicWatch();
    startWeather();
    pollBluetooth();
    startSysmon();
    powerMonitor.on('resume', () => { fetchWeather(); pollBluetooth(); });
    scheduleUpdateChecks();
    setHotkey(state.settings.hotkey === undefined ? DEFAULT_HOTKEY : state.settings.hotkey);
    screen.on('display-removed', () => { placeChar(charCenter()); saveCharPos(); });
    screen.on('display-metrics-changed', () => { placeChar(charCenter()); });
  });
  app.on('will-quit', () => globalShortcut.unregisterAll());
  app.on('before-quit', () => { stopMusicWatch(); stopSysmon(); clearInterval(weatherTimer); });
  app.on('window-all-closed', () => app.quit());
}
