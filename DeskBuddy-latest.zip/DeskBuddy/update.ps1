﻿# 책상 친구 업데이트 — 이미 설치했다면 이것만 실행하면 돼요 (다시 내려받지 않아요).
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $root 'runtime'
$exe  = Join-Path $dest 'DeskBuddy.exe'
try {
  if (-not (Test-Path $exe)) {
    Write-Host '아직 설치 전이라 설치부터 할게요.'
    & (Join-Path $root 'setup.ps1')
    return
  }
  Get-Process DeskBuddy -ErrorAction SilentlyContinue | Stop-Process -Force
  Start-Sleep -Milliseconds 800
  $app = Join-Path $dest 'resources\app'
  if (Test-Path $app) { Remove-Item $app -Recurse -Force }
  Copy-Item (Join-Path $root 'app') $app -Recurse -Force
  Write-Host '업데이트 완료! 책상 친구를 다시 불러올게요. (할 일 데이터는 그대로예요)'
  Start-Process $exe
}
catch {
  Write-Host ('업데이트하다 문제가 생겼어요: ' + $_.Exception.Message) -ForegroundColor Red
  Read-Host '엔터를 누르면 닫혀요'
}
