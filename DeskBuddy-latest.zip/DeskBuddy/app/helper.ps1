﻿# 책상 친구의 Windows 도우미 — 하나의 PowerShell 로 음악 · GPU · 블루투스를 다 봐요 (예전엔 셋이 따로 떠서 메모리를 많이 썼어요).
# Read-only, except play/pause/skip when asked from the info card.
# stdin (one per line):  config music=1 gpu=1 bt=1  |  toggle | next | prev  |  bt   (check Bluetooth now)
# stdout: one JSON line per report, with "type": music | gpu | bt
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, [Type]$t) { $k = $asTask.MakeGenericMethod($t).Invoke($null, @($op)); $null = $k.Wait(4000); $k.Result }
function Emit($o) { [Console]::Out.WriteLine((ConvertTo-Json -InputObject $o -Compress -Depth 5)); [Console]::Out.Flush() }

$cfg = @{ music = $false; gpu = $false; bt = $false }
$cores = [Environment]::ProcessorCount
$me = [Diagnostics.Process]::GetCurrentProcess()

# ---------- music (Windows media controls: Spotify, YouTube in a browser, …)
$mgr = $null
function MusicInit {
  if ($script:mgr) { return }
  [void][Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
  $t = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]
  $script:mgr = Await ($t::RequestAsync()) $t
}
function Props($s) {
  try {
    $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
    if ($p) { $a = "$($p.Artist)"; if (-not $a) { $a = "$($p.AlbumArtist)" }; return @{ title = "$($p.Title)"; artist = $a } }
  } catch { return @{ title = ''; artist = ''; err = $_.Exception.Message } }
  return @{ title = ''; artist = ''; err = 'no properties' }
}
$propCache = @{}      # app id -> @{ title; artist; t; st }  (song names are slow to read; the play state is quick)
$shownId = ''
function MusicReport([switch]$Fresh) {
  MusicInit
  $out = @{ type = 'music'; playing = $false; paused = $false }
  if (-not $script:mgr) { $out.err = 'no media manager'; Emit $out; return }
  $all = @($script:mgr.GetSessions()); $cur = $script:mgr.GetCurrentSession()
  $seen = @(); $best = $null; $bestScore = -1; $now = [DateTime]::Now
  foreach ($s in $all) {
    $id = "$($s.SourceAppUserModelId)"
    $st = "$($s.GetPlaybackInfo().PlaybackStatus)"
    $c = $script:propCache[$id]
    # read the song again when something changed, when we have none yet, or every 3 s
    if ($Fresh -or -not $c -or -not $c.title -or $c.st -ne $st -or ($now - $c.t).TotalSeconds -ge 3) {
      $pr = Props $s
      $c = @{ title = $pr.title; artist = $pr.artist; err = $pr.err; st = $st; t = $now }
      $script:propCache[$id] = $c
    }
    $score = 0
    if ($st -eq 'Playing') { $score += 4 } elseif ($st -eq 'Paused') { $score += 1 }
    if ($c.title) { $score += 2 }
    if ($cur -and $id -eq "$($cur.SourceAppUserModelId)") { $score += 1 }
    $seen += "$id=$st/$($c.title)"
    if ($score -gt $bestScore) { $bestScore = $score; $best = @{ id = $id; st = $st; c = $c } }
  }
  if ($best) {
    $script:shownId = $best.id
    $out = @{ type = 'music'; playing = ($best.st -eq 'Playing'); paused = ($best.st -eq 'Paused'); title = $best.c.title; artist = $best.c.artist; app = $best.id; err = "$($best.c.err)"; sessions = ($seen -join ' | ') }
  } else { $script:shownId = ''; $out.err = 'no session'; $out.sessions = '' }
  Emit $out
}
function Current {
  if (-not $script:mgr) { return $null }
  foreach ($s in $script:mgr.GetSessions()) { if ($s.GetPlaybackInfo().PlaybackStatus -eq 'Playing') { return $s } }
  return $script:mgr.GetCurrentSession()
}
function MusicCommand($cmd) {
  MusicInit
  # the buttons act on the player the card is showing (not whatever Windows thinks is "current")
  $s = $null
  if ($script:shownId) { foreach ($x in $script:mgr.GetSessions()) { if ("$($x.SourceAppUserModelId)" -eq $script:shownId) { $s = $x } } }
  if (-not $s) { $s = Current }
  if (-not $s) { return }
  switch ($cmd) {
    'toggle' { $null = Await ($s.TryTogglePlayPauseAsync()) ([bool]) }
    'next'   { $null = Await ($s.TrySkipNextAsync()) ([bool]) }
    'prev'   { $null = Await ($s.TrySkipPreviousAsync()) ([bool]) }
  }
  Start-Sleep -Milliseconds 150; MusicReport -Fresh
  Start-Sleep -Milliseconds 600; MusicReport -Fresh     # the new song's name often arrives a moment later
}

# ---------- GPU 3D usage (same numbers as Task Manager; WMI so it works on Korean Windows, never wakes a sleeping GPU)
$prevCpu = $me.TotalProcessorTime.TotalSeconds; $prevT = [DateTime]::Now
function GpuReport {
  $v = -1
  try {
    $rows = Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine -ErrorAction Stop | Where-Object { $_.Name -like '*engtype_3D' }
    $per = @{}
    foreach ($r in $rows) {
      $a = ($r.Name -replace '^.*?(luid_0x[0-9a-fA-F]+_0x[0-9a-fA-F]+).*$', '$1')
      if (-not $per.ContainsKey($a)) { $per[$a] = 0 }
      $per[$a] += [double]$r.UtilizationPercentage
    }
    $v = 0
    foreach ($k in $per.Keys) { if ($per[$k] -gt $v) { $v = $per[$k] } }
    $v = [math]::Min(100, [math]::Round($v))
    # two GPUs (laptop with integrated + discrete): the discrete one is the adapter with real dedicated memory in use
    $d = -1; $i = -1
    if ($per.Count -ge 2) {
      try {
        # which adapter is the discrete one: asked once a minute (that query is the slow part), not every report
        if (-not $script:dgpuAt -or ([DateTime]::Now - $script:dgpuAt).TotalSeconds -ge 60) {
          $mem = Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUAdapterMemory -ErrorAction Stop
          $script:dgpuBest = $null; $script:dgpuMem = 0
          foreach ($m in $mem) {
            $a = ($m.Name -replace '^.*?(luid_0x[0-9a-fA-F]+_0x[0-9a-fA-F]+).*$', '$1')
            if ([double]$m.DedicatedUsage -gt $script:dgpuMem) { $script:dgpuMem = [double]$m.DedicatedUsage; $script:dgpuBest = $a }
          }
          $script:dgpuAt = [DateTime]::Now
        }
        $best = $script:dgpuBest; $bestMem = $script:dgpuMem
        if ($best -and $bestMem -gt 256MB -and $per.ContainsKey($best)) {
          $d = [math]::Min(100, [math]::Round($per[$best]))
          $ig = 0; foreach ($k in $per.Keys) { if ($k -ne $best -and $per[$k] -gt $ig) { $ig = $per[$k] } }   # the other one: integrated
          $i = [math]::Min(100, [math]::Round($ig))
        }
        elseif ($best) { $d = 0; $i = $v }                             # the discrete GPU is asleep: all the work is on the integrated one
      } catch { $d = -1 }
    }
  } catch { $v = -1; $d = -1; $i = -1 }
  # this helper's own share, for the "how much does 책상 친구 use" line
  $me.Refresh()
  $now = [DateTime]::Now; $t = $me.TotalProcessorTime.TotalSeconds
  $dt = ($now - $script:prevT).TotalSeconds
  $cpu = if ($dt -gt 0) { ($t - $script:prevCpu) / $dt / $cores * 100 } else { 0 }
  $script:prevCpu = $t; $script:prevT = $now
  Emit @{ type = 'gpu'; gpu = $v; dgpu = $d; igpu = $i; ps = @{ cpu = [math]::Round($cpu, 2); mem = [math]::Round($me.PrivateMemorySize64 / 1MB) } }
}

# ---------- Bluetooth battery of connected devices (see the app README for how "connected" is decided)
function BtReport {
  $battKey = '{104EA319-6EE2-4701-BD47-8DDBF425BBE5} 2'
  $connKey = '{83DA6326-97A6-4088-9453-A1923F573B29} 15'
  $contKey = '{8C7ED206-3F8A-4827-B3AB-AE9E1FAEFC6C} 2'
  $dbg = New-Object System.Collections.Generic.List[string]
  $devs = @(Get-PnpDevice -Class Bluetooth)
  $flag = @{}
  foreach ($d in $devs) {
    $c = (Get-PnpDeviceProperty -InstanceId $d.InstanceId -KeyName $connKey).Data
    $cid = "$((Get-PnpDeviceProperty -InstanceId $d.InstanceId -KeyName $contKey).Data)"
    if ($cid -and $c -ne $null) { if ($c -eq $true) { $flag[$cid] = $true } elseif (-not $flag.ContainsKey($cid)) { $flag[$cid] = $false } }
  }
  $live = @(); $winrtOk = $false
  try {
    [void][Windows.Devices.Bluetooth.BluetoothDevice, Windows.Devices.Bluetooth, ContentType = WindowsRuntime]
    [void][Windows.Devices.Bluetooth.BluetoothLEDevice, Windows.Devices.Bluetooth, ContentType = WindowsRuntime]
    [void][Windows.Devices.Enumeration.DeviceInformation, Windows.Devices.Enumeration, ContentType = WindowsRuntime]
    $coll = [Windows.Devices.Enumeration.DeviceInformationCollection]
    foreach ($kind in @([Windows.Devices.Bluetooth.BluetoothDevice], [Windows.Devices.Bluetooth.BluetoothLEDevice])) {
      $infos = Await ([Windows.Devices.Enumeration.DeviceInformation]::FindAllAsync($kind::GetDeviceSelectorFromPairingState($true))) $coll
      foreach ($di in $infos) {
        $bd = Await ($kind::FromIdAsync($di.Id)) $kind
        if ($bd) { $winrtOk = $true; if ("$($bd.ConnectionStatus)" -eq 'Connected') { $live += "$($bd.Name)" }; $bd.Dispose() }
      }
    }
  } catch { $dbg.Add('winrt error: ' + $_.Exception.Message) }
  $dbg.Add('winrt ok=' + $winrtOk + ' connected=[' + ($live -join ', ') + ']')
  $seen = @{}; $list = @()
  foreach ($d in $devs) {
    $p = Get-PnpDeviceProperty -InstanceId $d.InstanceId -KeyName $battKey
    if (-not ($p -and $p.Data -ne $null -and $d.FriendlyName)) { continue }
    $name = "$($d.FriendlyName)" -replace ' (Hands-Free|Avrcp Transport|Stereo|Audio).*$', ''
    $cid = "$((Get-PnpDeviceProperty -InstanceId $d.InstanceId -KeyName $contKey).Data)"
    $byFlag = if ($cid -and $flag.ContainsKey($cid)) { $flag[$cid] } else { $null }
    $n = ("$name" -replace '\s+', ' ').Trim().ToLower()
    $byName = $null
    if ($winrtOk) { $byName = [bool]($live | Where-Object { $m = ("$_" -replace '\s+', ' ').Trim().ToLower(); $m -and ($m.Contains($n) -or $n.Contains($m)) }) }
    $conn = if ($byFlag -eq $true -or $byName -eq $true) { $true } elseif ($byFlag -eq $null -and $byName -eq $null) { $null } else { $false }
    $dbg.Add("$name level=$($p.Data) status=$($d.Status) flag=$byFlag winrt=$byName -> $conn")
    if (-not $seen.ContainsKey($name)) { $seen[$name] = $true; $list += [pscustomobject]@{ name = $name; level = [int]$p.Data; connected = $conn } }
    elseif ($conn -eq $true) { ($list | Where-Object { $_.name -eq $name })[0].connected = $true }
  }
  Emit ([pscustomobject]@{ type = 'bt'; devices = @($list); debug = ($dbg -join "`n") })
  [GC]::Collect()
}

# ---------- main loop: one process, three timers
$in = [Console]::In
$pending = $in.ReadLineAsync()
$nextMusic = [DateTime]::MaxValue; $nextGpu = [DateTime]::MaxValue; $nextBt = [DateTime]::MaxValue
while ($true) {
  if ($pending.IsCompleted) {
    if ($pending.Result -eq $null) { break }                       # the app closed
    $line = "$($pending.Result)".Trim()
    if ($line -like 'config*') {
      foreach ($kv in ($line -split '\s+' | Select-Object -Skip 1)) { $k, $v = $kv -split '='; $cfg[$k] = ($v -eq '1') }
      $now = [DateTime]::Now
      $nextMusic = if ($cfg.music) { $now } else { [DateTime]::MaxValue }
      $nextGpu = if ($cfg.gpu) { $now } else { [DateTime]::MaxValue }
      $nextBt = if ($cfg.bt) { $now } else { [DateTime]::MaxValue }
    }
    elseif ($line -in @('toggle', 'next', 'prev')) { MusicCommand $line }
    elseif ($line -eq 'bt') { $nextBt = [DateTime]::Now }
    $pending = $in.ReadLineAsync()
  }
  $now = [DateTime]::Now
  if ($now -ge $nextMusic) { try { MusicReport } catch { Emit @{ type = 'music'; playing = $false; paused = $false; err = 'report: ' + $_.Exception.Message } }; $nextMusic = $now.AddSeconds(2) }   # every second: a new song shows up right away
  if ($now -ge $nextGpu) { GpuReport; $nextGpu = $now.AddSeconds(5) }
  if ($now -ge $nextBt -and $cfg.bt) { BtReport; $nextBt = $now.AddMinutes(5) }
  Start-Sleep -Milliseconds 250
}
