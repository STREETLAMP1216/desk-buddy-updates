// 책상 친구 — what the character does and says.
(function () {
  const L = window.Logic;
  const CHARS = window.Character.CHARACTERS;
  let CH = CHARS.shiori;                                   // current character; set from settings on load
  // ----- language: ko / en / ja. UI text goes through T(); lines come from LineBanks['<character>:<lang>'] -----
  let LANG = 'ko';
  const T = (s, vars) => window.I18N.t(LANG, s, vars);
  const bankOf = (ch, lang) => (window.LineBanks || {})[`${ch.id}:${lang || LANG}`] || (window.LineBanks || {})[`${ch.id}:ko`] || {};
  const lineBags = {};
  function pickLine(kind, vars) {
    const bank = bankOf(CH);
    const pool = (bank[kind] && bank[kind].length ? bank[kind] : bankOf(CH, 'ko')[kind]) || [];
    if (!pool.length) return '';
    const bagKey = `${CH.id}:${LANG}:${kind}`;
    if (!lineBags[bagKey] || !lineBags[bagKey].length) lineBags[bagKey] = pool.map((_, i) => i).sort(() => Math.random() - 0.5);
    let out = pool[lineBags[bagKey].pop() % pool.length];
    Object.entries(vars || {}).forEach(([k, v]) => { out = out.split('{' + k + '}').join(String(v)); });
    return out;
  }
  const charName = (c) => (LANG !== 'ko' && c.names && c.names[LANG]) || c.name;
  function profileOf(c) { return (window.ProfileBanks || {})[`${c.id}:${LANG}`] || c; }
  // drawings: assets/<character>/<name>.png — the manifest says which exist
  const has = (name) => (window.ASSETS[CH.id] || []).includes(name);
  const A = (name) => `assets/${CH.id}/${name}.png`;
  // which face goes with which kind of line (faces are drawings: face_<mood>.png)
  const MOOD = {
    typing: 'focus', study: 'focus', focusStart: 'focus', focusKeep: 'focus', renderStart: 'focus', renderWait: 'focus',
    nudgeEmpty: 'puzzled', poke: 'surprised', music: 'calm', musicTitle: 'calm', tie: 'smug', switchIn: 'neutral', batteryLow: 'puzzled', batteryVeryLow: 'puzzled', btLow: 'puzzled', strainCpu: 'puzzled', strainRam: 'puzzled',
    praise: 'smug', praiseAll: 'smug', focusDone: 'smug', renderDone: 'smug', wrapUp: 'smug', schedule: 'smug',
    lunch: 'eat', snack: 'eat', dinner: 'eat',
    morning: 'sleepy', night: 'sleepy', wrapUpZero: 'sleepy'
  };
  // a line can come with its own drawing (shown while the bubble is up), once that drawing exists
  const REACT = {
    lunch: 'meal', dinner: 'meal', nudge: 'nudge', nudgeEmpty: 'nudge', focusStart: 'focus', migrate: 'migrate',
    back: 'back', poke: 'poke', batteryLow: 'battery_low', batteryVeryLow: 'battery_low', batteryFull: 'battery_full',
    btLow: 'bt_low', wrapUp: 'wrapup', wrapUpZero: 'wrapup_zero', schedule: 'migrate', evening: 'chat'
  };
  // who gets to talk when two things happen at once (see say()):
  //   3 = your own action or an emergency — shows right away, even over a waiting question
  //   2 = events (meals, render done, battery low…) — waits until an open question is answered or closes
  //   1 = small talk — only when nothing else is on screen (checked by the caller)
  const PRIORITY3 = new Set(['batteryVeryLow', 'praise', 'praiseAll', 'tie', 'migrate', 'schedule', 'poke', 'memo',
    'switchIn', 'focusStart', 'focusKeep', 'focusStop', 'snooze']);
  let lastKind = null;
  // today's count: tasks + the routines due today
  const CNT = (day, key) => L.counts(day, L.routinesFor(key || ui.key, data.settings.routines));
  const say_ = (kind, vars) => { lastKind = kind; return withCall(kind, pickLine(kind, vars)); };
  const api = window.deskBuddy || fakeApi();  // not window.buddy: the #buddy element owns that name. fakeApi = plain-browser preview
  const $ = (id) => document.getElementById(id);

  const MIN = 60 * 1000;
  const CHATTER_MIN = { quiet: 30, normal: 15, chatty: 7, always: 1.5 };

  let data = null;
  const ui = {
    key: null, idle: 0, prevIdle: 0, away: false, panelOpen: false,
    blink: false, music: false, musicManual: false, musicAuto: false, musicTitle: '',
    study: false, focusing: null, quietUntil: 0, snoozeUntil: 0, lastNudge: 0, nudgedThisEpisode: false,
    skip: [], lastChatter: Date.now(), bubbleTimer: null, pose: null, anim: null, img: null, hopUntil: 0,
    lastMusicLine: 0,
    weather: null, battery: null, bt: [], warned: {},
    sys: null, samples: [], rendering: false, doneUntil: 0, strain: null,
    cheerUntil: 0, tieUntil: 0, react: null, tapFrame: false, holdUntil: 0, pending: null,
    sim: null            // situation test: overrides for time, idle, music… (null = real life)
  };

  // ---------- startup ----------
  api.load().then((d) => {
    data = d;
    ui.study = !!data.study;
    ui.musicManual = !!data.musicManual;
    ui.key = DK(new Date());
    L.ensureDay(data, ui.key);
    initCharacter();
    LANG = ['ko', 'en', 'ja'].includes(data.settings.lang) ? data.settings.lang : 'ko';
    window.I18N.translateDom(document.body, LANG);
    document.documentElement.lang = LANG;
    L.setWeek(window.I18N.week(LANG));
    applySizes();
    fillSettings();
    fillShowPick();
    fillSliders();
    fillCallMe();
    applyStill();
    fillBtPick();
    fillUpdate();
    fillSync();
    fillHotkey();
    [['setStill', 'still', false], ['setHover', 'hoverSolid', true], ['setThrough', 'clickThrough', false], ['setAutoUpdate', 'autoUpdate', true]].forEach(([id, key, def]) => {
      const box = $(id);
      box.checked = data.settings[key] === undefined ? def : !!data.settings[key];
      box.addEventListener('change', () => setSetting(key, box.checked));
    });
    fillToggles();
    renderPanel();
    render();
    api.onIdle(onIdle);
    api.onAway((v) => { ui.away = v; });
    api.onMusic((info) => {
      ui.nowPlaying = info && (info.title || info.playing || info.paused) ? info : null;
      ui.musicAuto = !!(info && info.playing) && data.settings.autoMusic !== false;   // headphones only when that switch is on
      const prevTitle = ui.musicTitle;
      ui.musicTitle = (info && info.title) || '';
      updateMusic(); renderWidget();
      // a new song while she's in a talkative mood: say something about it
      const talk = data.settings.chatter === 'chatty' || data.settings.chatter === 'always';
      if (talk && ui.music && prevTitle && ui.musicTitle && ui.musicTitle !== prevTitle && $('bubble').hidden && !ui.panelOpen) {
        ui.lastMusicLine = Date.now();
        say(say_('musicTitle', { title: ui.musicTitle }), null, { kind: 'musicTitle' });
      }
    });
    api.onCommand(onCommand);
    if (api.onLayout) api.onLayout(onLayout);
    $('buddyImg').addEventListener('load', () => {
      const im = $('buddyImg'), key = im.naturalWidth + 'x' + im.naturalHeight;
      if (key === ui.imgSize) return;          // same size (typing / blink frames): nothing moves
      ui.imgSize = key; positionWidget(); positionBubble();
    });
    if (api.onWeather) api.onWeather(onWeather);
    if (api.onBluetooth) api.onBluetooth(onBluetooth);
    if (api.onSys) api.onSys(onSys);
    renderProfile();
    renderCharPick();
    buildTestView();
    watchBattery();
    scheduleBlink();
    // typing: swap between the two hand frames while you type
    setInterval(() => {
      const typing = (ui.sim ? ui.sim.idle : ui.idle) < 4 && ['laptop', 'laptopb', 'focus', 'focusb'].includes(ui.pose);
      if (typing && (has('laptopb_open') || has('laptopb_hpopen') || has('focusb_open'))) { ui.tapFrame = !ui.tapFrame; render(); }
      else if (ui.tapFrame) { ui.tapFrame = false; render(); }
    }, 260);
    // writing in the notebook: the pen moves (when the character has the second memo drawing)
    setInterval(() => {
      const writing = ['memo', 'memob'].includes(ui.pose) && (has('memob_open') || has('memob_hpopen'));
      if (writing) { ui.penFrame = !ui.penFrame; render(); } else if (ui.penFrame) { ui.penFrame = false; render(); }
    }, 520);
  });

  function persistLocal() { api.save({ days: data.days, settings: data.settings, notes: data.notes || [], study: ui.study, musicManual: ui.musicManual, sync: data.sync || null }); }
  function persist() { persistLocal(); if (syncer) syncer.soon(3000); }
  function today() { return L.ensureDay(data, ui.key); }
  // which day "now" belongs to: the day starts at settings.dayStart (default 4:00), not at midnight
  function DK(d) { return L.dayKey(d, (data && data.settings.dayStart) || '04:00'); }

  // ---------- every second ----------
  function onIdle(sec) {
    ui.prevIdle = ui.idle;
    ui.idle = sec;
    const now = new Date();
    const key = DK(now);
    if (key !== ui.key) { ui.key = key; L.ensureDay(data, key); renderPanel(); }
    checkAlarms(now);
    if (!ui.sim) events(now);
    render();
  }

  function events(now) {
    const day = today();
    const s = data.settings;
    const active = ui.idle < 4;
    const t = now.getTime();

    if (active) ui.nudgedThisEpisode = false;

    // focus timer
    if (ui.focusing) {
      const left = Math.max(0, ui.focusing.until - t);
      if (ui.focusing.timer) { renderWidget(); drawTimer(); }
      $('focusTimer').hidden = !!ui.focusing.timer;
      $('focusTimer').textContent = `⏱ ${Math.floor(left / 60000)}:${String(Math.floor(left / 1000) % 60).padStart(2, '0')}`;
      if (left === 0) focusDone();
      return;
    }

    // first activity of the day → back to the notebook
    if (active && !day.fired.first && now.getHours() >= 5) {
      day.fired.first = true; persist();
      const w = weatherSentence();
      if (w) day.fired.weather = true;
      say(say_('firstOfDay') + (w ? ' ' + w : ''), [{ label: T('할 일 열기'), primary: true, run: openPanel }]);
      return;
    }

    // coming back after a while
    if (active && ui.prevIdle >= 10 * 60) {
      say(say_('back'));
      if (L.workHours(now, s) && L.counts(day).open > 0) setTimeout(() => nudge(), 4000);
      return;
    }

    if (active) {
      if (once(day, 'lunch', now, s.lunch, 60)) return say(say_('lunch'));
      if (once(day, 'snack', now, s.snack, 45)) return say(say_('snack'));
      if (once(day, 'dinner', now, s.dinner || '18:30', 60)) return say(say_('dinner'));
      if (!day.fired.wrap && L.minutes(`${now.getHours()}:${now.getMinutes()}`) >= L.minutes(s.wrapUp)) {
        day.fired.wrap = true; persist();
        return wrapUp();
      }
    }

    // stopped for a while during work hours → one gentle nudge per pause
    if (ui.idle >= 120 && !ui.nudgedThisEpisode && !ui.panelOpen && !ui.rendering && L.workHours(now, s) &&
        t > ui.quietUntil && t > ui.snoozeUntil && t - ui.lastNudge > 15 * MIN) {
      ui.nudgedThisEpisode = true;
      nudge();
      return;
    }

    // small talk now and then
    const every = (CHATTER_MIN[s.chatter] || 15) * MIN;
    const always = s.chatter === 'always';
    // "always talking": a bubble stays up and a new line replaces it every minute and a half (never over a question)
    const free = $('bubble').hidden || (always && !$('bubbleButtons').children.length && !ui.pending);
    if ((always ? ui.idle < 10 * 60 : ui.idle < 60) && free && t - ui.lastChatter > every && t > ui.quietUntil) {
      ui.lastChatter = t;
      say(say_(chatterKind(now)), [], always ? { keep: every + 15000 } : undefined);
    }
  }

  function once(day, id, now, hhmm, lengthMin) {
    if (day.fired[id] || !L.inWindow(now, hhmm, lengthMin)) return false;
    day.fired[id] = true; persist();
    return true;
  }

  function chatterKind(now) {
    if (ui.rendering) return 'renderWait';
    if (ui.music) return Math.random() < .5 ? 'music' : 'typing';
    if (ui.study) return 'study';
    const sl = L.slot(now);
    if (sl === 'morning') return ui.idle < 4 ? 'typing' : 'morning';
    if (sl === 'evening') return ui.idle < 4 ? 'typing' : 'evening';
    if (sl === 'night') return ui.idle < 4 ? 'typing' : ui.idle < 15 * 60 ? 'evening' : 'night';  // working late: keep you company, don't send you to bed
    return 'typing';
  }

  // ---------- nudges & focus ----------
  function nudge() {
    ui.lastNudge = Date.now();
    const day = today();
    const task = L.suggest(day, ui.skip);
    if (!task) {
      ui.skip = [];
      return say(say_('nudgeEmpty'), [{ label: T('할 일 열기'), primary: true, run: openPanel }]);
    }
    say(say_('nudge', { task: task.text }), [
      { label: T('5분만 해볼게'), primary: true, run: () => startFocus(task) },
      { label: T('다른 거'), run: () => { ui.skip.push(task.id); nudge(); } },
      { label: T('내일로'), run: () => { L.migrate(data, ui.key, task.id); persist(); renderPanel(); say(say_('migrate')); } },
      { label: T('나중에'), run: () => { ui.snoozeUntil = Date.now() + 20 * MIN; say(say_('snooze')); } }
    ], { sticky: true });
  }

  function startFocus(task) {
    ui.focusing = { taskId: task.id, until: Date.now() + 5 * MIN, min: 5 };
    say(say_('focusStart'), [], { keep: 5 * MIN });
  }

  // ---------- timer (any length; the 5-minute nudge timer is the same thing) ----------
  function startTimer(min, taskId) {
    min = Math.max(1, Math.min(600, Math.round(min)));
    const rec = (data.settings.timerRecent || []).filter(x => x !== min);
    data.settings.timerRecent = [min].concat(rec).slice(0, 3);
    ui.focusing = { taskId: taskId || null, until: Date.now() + min * MIN, min, timer: true };
    persist(); renderWidget(); drawTimer();
    lastKind = 'focusStart';
    say(T('{n}분 타이머 시작!', { n: min }));
  }
  function stopTimer() {
    ui.focusing = null; $('focusTimer').hidden = true;
    renderWidget(); drawTimer(); render();
  }

  function focusDone() {
    const id = ui.focusing && ui.focusing.taskId;
    const f = ui.focusing;
    ui.focusing = null;
    $('focusTimer').hidden = true;
    renderWidget(); drawTimer();
    if (f && f.timer) {
      const b = [];
      const t = id && today().tasks.find(x => x.id === id);
      if (t && t.status === 'open') b.push({ label: T('끝냈어!'), primary: true, run: () => { t.status = 'done'; persist(); renderPanel(); praise(); } });
      b.push({ label: T('{n}분 한 번 더', { n: f.min }), primary: !b.length, run: () => startTimer(f.min, id) });
      b.push({ label: T('좋아'), run: () => {} });
      lastKind = 'focusDone';
      ui.hopUntil = Date.now() + 800;
      ring(5);
      b.forEach(x => { const run = x.run; x.run = () => { stopRing(); run(); }; });
      return say(T('{n}분 끝났어!', { n: f.min }), b, { sticky: true });
    }
    say(say_('focusDone'), [
      { label: T('끝냈어!'), primary: true, run: () => { const d = today(); const t = d.tasks.find(x => x.id === id); if (t && t.status === 'open') { t.status = 'done'; persist(); renderPanel(); praise(); } } },
      { label: T('계속할래'), run: () => { ui.quietUntil = Date.now() + 25 * MIN; say(say_('focusKeep')); } },
      { label: T('여기까지'), run: () => say(say_('focusStop')) }
    ], { sticky: true });
  }

  function praise() {
    const day = today();
    const c = CNT(day);
    ui.hopUntil = Date.now() + 800;
    // first thing done this morning: if she has a "getting ready" drawing (Fubuki ties her hair), that's the moment
    if (!day.fired.tied && has('tie') && new Date().getHours() < 12) {
      day.fired.tied = true; persist();
      ui.tieUntil = Date.now() + 5000;
      render();
      return say(say_('tie'));
    }
    day.fired.tied = true;
    ui.cheerUntil = Date.now() + 4000;
    render();
    if (c.open === 0 && c.done > 0) say(say_('praiseAll'));
    else say(say_('praise', { count: c.done, left: c.open }));
  }

  function wrapUp() {
    const c = CNT(today()), ct = L.counts(today());
    const buttons = [];
    if (ct.open > 0) buttons.push({ label: T('못 한 {n}개 내일로', { n: ct.open }), primary: true, run: migrateAllOpen });
    buttons.push({ label: T('수첩용 복사'), run: copyForNotebook });
    buttons.push({ label: T('좋아'), run: () => {} });
    say(c.done ? say_('wrapUp', { count: c.done }) : say_('wrapUpZero'), buttons, { sticky: true });
  }

  function migrateAllOpen() {
    today().tasks.filter(L.isOpen).forEach(t => L.migrate(data, ui.key, t.id));
    persist(); renderPanel();
    say(say_('migrate'));
  }

  function copyForNotebook() {
    api.copyText(L.toPlainText(data, ui.key, { routines: T('[매일 루틴]'), today: T('[오늘]') }));
    say(T('복사했어. 수첩에 옮겨 적어줘.'));
  }

  // ---------- music ----------
  function updateMusic() {
    const was = ui.music;
    ui.music = ui.musicManual || ui.musicAuto;
    if (ui.music && !was && Date.now() - ui.lastMusicLine > 3 * MIN && $('bubble').hidden) {
      ui.lastMusicLine = Date.now();
      say(ui.musicTitle ? say_('musicTitle', { title: ui.musicTitle }) : say_('music'));
    }
    render();
  }

  // ---------- drawing ----------
  function scheduleBlink() {
    setTimeout(() => {
      ui.blink = true; render();
      setTimeout(() => { ui.blink = false; render(); scheduleBlink(); }, 160);
    }, 2600 + Math.random() * 3200);
  }

  // the situation being drawn: real state, or the test panel's overrides
  function scene() {
    const S = ui.sim || {};
    const pick = (k, real) => (S[k] !== undefined ? S[k] : real);
    let now = new Date();
    if (S.time) { const [h, m] = S.time.split(':').map(Number); now = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h, m); }
    return {
      now, idle: pick('idle', ui.idle), music: pick('music', ui.music), panelOpen: pick('panel', ui.panelOpen),
      study: pick('study', ui.study), rendering: pick('rendering', ui.rendering), done: pick('done', Date.now() < ui.doneUntil),
      strain: pick('strain', ui.strain), cheer: pick('cheer', Date.now() < ui.cheerUntil), tie: pick('tie', Date.now() < ui.tieUntil),
      tied: pick('tied', !!today().fired.tied), asset: S.asset || null
    };
  }

  // first existing drawing among the candidates
  const first = (...names) => names.find(has);

  // decoded pictures, kept so swapping between frames is instant
  const PRE = new Map();
  function preload(src) {
    let c = PRE.get(src);
    if (!c) {
      const im = new Image(); im.src = src;
      c = { im, ok: false, p: (im.decode ? im.decode() : Promise.resolve()).catch(() => {}).then(() => { c.ok = true; }) };
      PRE.set(src, c);
      if (PRE.size > 12) PRE.delete(PRE.keys().next().value);      // decoded pictures are ~1 MB each: keep only the few frames in use
    }
    return c.p;
  }
  function render() {
    if (!data) return;
    // being carried around: hold still on the current drawing (no switching to "typing" from the mouse moving)
    if ((drag && drag.moved >= 5) || Date.now() < ui.holdUntil) {
      if (ui.anim !== 'a-still') { $('anim').className = 'a-still'; ui.anim = 'a-still'; }
      return;
    }
    const sc = scene();
    const { now, music } = sc;
    let pose = L.pose({ now, idleSec: sc.idle, panelOpen: sc.panelOpen, study: sc.study, settings: data.settings, focusing: !!ui.focusing });
    // a character who starts the day "not ready yet" (Fubuki: hair down) stays that way until the first thing is done
    const h = now.getHours();
    if (has('wake') && !sc.tied && h >= 5 && h < 12 && ['morning', 'laptop', 'hm', 'rest'].includes(pose)) pose = 'wake';

    // while you work she mostly types, but now and then spends a few minutes scribbling notes
    if (pose === 'laptop' && sc.idle < 4 && !ui.focusing) {
      const block = Math.floor(now.getTime() / (3 * MIN)) + now.getDate() * 977;
      const odds = { never: 0, normal: 0.12, often: 0.25 }[data.settings.variety || 'normal'];
      if (((block * 9301 + 49297) % 233280) / 233280 < odds) pose = 'memo';
    }
    let sys = null;
    if (!sc.panelOpen) {
      if (sc.rendering) sys = 'render';
      else if (sc.done) sys = 'done';
      else if (sc.strain) sys = 'strain';
    }
    const still = !!data.settings.still;
    const closed = !still && (ui.blink || (music && Math.floor(now.getTime() / 1000) % 9 < 2));   // eyes shut now and then, lost in the song
    const eyes = closed ? 'closed' : 'open';
    let name, shown;
    if (sc.asset) { name = sc.asset; shown = 'asset'; }
    else if (sc.tie && has('tie')) { name = 'tie'; shown = 'tie'; }
    else if (sc.cheer && has('cheer')) { name = first(music ? 'cheer_hp' : '', 'cheer'); shown = 'cheer'; }
    else if (ui.react && Date.now() < ui.react.until) { name = first(music ? ui.react.name + '_hp' : '', ui.react.name); shown = 'react'; }
    else if (sys && has(sys)) { name = first(music ? sys + '_hp' : '', ui.blink ? sys + '_closed' : '', sys); shown = sys; }
    else {
      let p = sys ? (sys === 'strain' ? 'hm' : 'laptop') : pose;         // a reaction without its own drawing borrows a pose
      // focus timer running: the focus drawings (round glasses on) when this character has them
      if (p === 'laptop' && ui.focusing && has('focus_open')) p = 'focus';
      if (p === 'laptop' && sc.idle < 4 && ui.tapFrame && !closed && !still && has(music ? 'laptopb_hpopen' : 'laptopb_open')) p = 'laptopb';   // hands moving
      else if (p === 'memo' && ui.penFrame && !closed && !still && has(music ? 'memob_hpopen' : 'memob_open')) p = 'memob';
      else if (p === 'focus' && sc.idle < 4 && ui.tapFrame && !closed && !still && has(music ? 'focusb_hpopen' : 'focusb_open')) p = 'focusb';
      name = first(music ? `${p}_hp${eyes}` : '', music ? `${p}_hpopen` : '', `${p}_${eyes}`, `${p}_open`, p, 'laptop_open');
      shown = p;
    }
    const img = A(name);

    let anim;
    if (Date.now() < ui.hopUntil) anim = 'a-hop';
    else if (shown === 'cheer') anim = 'a-cheer';
    else if (shown === 'tie') anim = 'a-pop';
    else if (shown === 'render') anim = 'a-wait';
    else if (shown === 'done') anim = 'a-cheer';
    else if (shown === 'strain') anim = 'a-busy';
    // the typing/writing frames swap pictures several times a second: they must share one animation, or it restarts on every swap
    else if (music && ['laptop', 'laptopb', 'focus', 'focusb', 'memo', 'memob', 'morning'].includes(shown)) anim = 'a-groove';
    else if (shown === 'react') anim = 'a-pop';
    // hands that have a second drawing move for real; the rest just sway a little while typing / writing
    else anim = { laptop: sc.idle < 4 ? (has(music ? 'laptopb_hpopen' : 'laptopb_open') ? 'a-still' : 'a-tap') : 'a-still', laptopb: 'a-still',
                  focus: sc.idle < 4 ? (has(music ? 'focusb_hpopen' : 'focusb_open') ? 'a-still' : 'a-tap') : 'a-still', focusb: 'a-still',
                  memo: has(music ? 'memob_hpopen' : 'memob_open') ? 'a-still' : 'a-scribble', memob: 'a-still', hm: 'a-pop', rest: 'a-still', snack: 'a-munch', asset: 'a-still' }[shown] || 'a-sway';

    if (still) anim = 'a-still';
    if (img !== ui.img) {
      // swap only to an already decoded picture, so frame changes (typing hands, blinks) never stutter
      const c = PRE.get(img);
      if (c && c.ok) { $('buddyImg').src = img; ui.img = img; }
      else preload(img).then(() => { if (ui.want === img) { $('buddyImg').src = img; ui.img = img; } });
      ui.want = img;
      // and get the next likely frames ready
      [name.replace('laptop_', 'laptopb_'), name.replace('laptopb_', 'laptop_'), name.replace('_open', '_closed'), name.replace('memo_', 'memob_'), name.replace('memob_', 'memo_'), name.replace('focus_', 'focusb_'), name.replace('focusb_', 'focus_')]
        .forEach(n => { if (n !== name && has(n)) preload(A(n)); });
    }
    if (anim !== ui.anim) { $('anim').className = anim; ui.anim = anim; }
    $('buddyImg').alt = `${T('책상 친구')} ${displayName()}`;
    $('note1').hidden = $('note2').hidden = !music;
    ui.pose = shown;
    ui.shownName = name;
    renderWidget();
    if (ui.sim) $('testNow').textContent = `${ui.testLabel ? ui.testLabel + ' · ' : ''}그림: ${name}`;
  }

  // ---------- always-on info card ----------
  // every kind of row the card can show, in the default order; the order is yours to change in settings
  const CARD_KEYS = ['date', 'time', 'block', 'tasks', 'u', 'notes', 'weather', 'battery', 'hw', 'music', 'self'];
  function cardOrder() {
    const o = (data.settings.cardOrder || []).filter(k => CARD_KEYS.includes(k));
    return o.concat(CARD_KEYS.filter(k => !o.includes(k)));
  }
  function renderWidget() {
    if (!data) return;
    const show = data.settings.show || [];
    const box = $('widget');
    box.innerHTML = '';
    if (!show.length && !(ui.focusing && ui.focusing.timer)) { box.hidden = true; return; }
    const now = scene().now;
    // a row is one line of info; given a list, its parts wrap between items instead of being cut off
    // rows go into the current group; each kind of info (date, tasks, weather, …) is its own group
    let into = box;
    const row = (text, cls) => {
      const d = document.createElement('div'); d.className = 'row' + (cls ? ' ' + cls : '');
      (Array.isArray(text) ? text : [text]).forEach(t => {
        const sp = document.createElement('span'); sp.className = 'part'; sp.textContent = t; d.appendChild(sp);
      });
      into.appendChild(d); return d;
    };
    const hhmm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const day = today();
    const maxTasks = data.settings.cardTasks == null ? 3 : +data.settings.cardTasks;
    const SECTION = {
      // date + time share one line, at whichever of the two comes first
      date: () => row(show.includes('time') ? `${L.label(ui.key)}  ${hhmm}` : L.label(ui.key), 'big'),
      time: () => { if (!show.includes('date')) row(hhmm, 'big'); },
      tasks: () => {
        const c = CNT(day);
        row(c.total ? [T('할 일 {a}/{b}', { a: c.done, b: c.total }), T('남은 거 {n}개', { n: c.open })] : T('오늘 적은 할 일 없음'));
        const cb = curBlock(), bt = day.tasks.filter(t => t.block === cb && (t.kind === 'task' || t.kind === 'event'));
        const blockShown = show.includes('block');
        // the block row already lists this block: here only the summary line, not the same items twice
        if (!blockShown && day.tasks.some(t => t.block)) row([T('{n}블럭', { n: cb }), bt.map(blockGlyph).join(' ') || '–'], 'block-line');
        const lo = L.leftovers(data, ui.key, 14).length;
        if (lo) row(T('지난 날 남은 거 {n}개', { n: lo }), 'low');
        const openOnly = data.settings.cardTasksOpen !== false;
        let open = L.ordered(day.tasks, day.customOrder).filter(t => (t.kind === 'task' || t.kind === 'event') && (!openOnly || t.status === 'open'))
          .map((t, i) => ({ t, i, k: t.block === curBlock() ? 0 : 1 })).sort((a, b) => a.k - b.k || a.i - b.i).map(x => x.t);   // this block's first
        if (blockShown) open = open.filter(t => t.block !== cb);
        open.slice(0, maxTasks).forEach((t, k) => row(`${openOnly ? (k ? '' : '→ ') : blockGlyph(t) + '  '}${t.kind === 'event' ? (openOnly ? '○ ' : '') + (t.time ? t.time + ' ' : '') : ''}${t.u ? 'u ' : ''}${t.star ? '* ' : ''}${t.text}`, k ? 'dim task-line' : 'task-line next'));
        if (maxTasks && open.length > maxTasks) row(T('그 외 {n}개', { n: open.length - maxTasks }), 'dim');
      },
      u: () => {
        const us = L.ordered(day.tasks, day.customOrder).filter(t => L.isOpen(t) && t.u);
        if (!us.length) row(T('u 할 일 없음'), 'dim');
        const um = data.settings.cardU == null ? 4 : data.settings.cardU;
        us.slice(0, um).forEach(t => row(`u · ${t.text}`));
        if (us.length > um) row(T('그 외 {n}개', { n: us.length - um }), 'dim');
      },
      weather: () => {
        if (!ui.weather) return;
        const w = ui.weather;
        row([`${T(L.weatherText(w.code))} ${w.temp}°`, `${w.min}~${w.max}°`].concat(L.umbrella(w) ? [T('우산')] : []));
      },
      battery: () => {
        const parts = [];
        if (ui.battery) parts.push(`${T('노트북')} ${ui.battery.level}%${ui.battery.charging ? '⚡' : ''}`);
        shownBt().forEach(d => parts.push(`${d.name} ${d.level}%`));
        if (parts.length) row(parts, (ui.battery && !ui.battery.charging && ui.battery.level <= 20) || shownBt().some(d => d.level <= 20) ? 'low' : '');
      },
      hw: () => {
        if (!ui.sys) return;
        const x = ui.sys, p = [];
        if (x.cpu != null) p.push(`CPU ${x.cpu}%`);
        if (x.ram != null) p.push(`RAM ${x.ram}%`);
        // two graphics chips: show each one; otherwise just the one
        if (x.dgpu != null && x.igpu != null) { p.push(`${T('내장')} GPU ${x.igpu}%`); p.push(`${T('외장')} GPU ${x.dgpu}%`); }
        else if (x.dgpu != null) p.push(`${T('외장')} GPU ${x.dgpu}%`);
        else if (x.gpu != null) p.push(`GPU ${x.gpu}%`);
        if (p.length) row(p.concat(ui.rendering ? [T('렌더 중')] : []), ui.strain ? 'low' : '');
      },
      self: () => { if (ui.sys && ui.sys.self) row([`${T('책상 친구')} CPU ${ui.sys.self.cpu}%`, `${ui.sys.self.mem}MB`], 'dim'); },
      block: () => {
        const cb = curBlock(), bt = L.ordered(day.tasks, day.customOrder).filter(t => t.block === cb && (t.kind === 'task' || t.kind === 'event'));
        row(T('{n}블럭', { n: cb }), 'block-line');
        const br = L.routinesFor(ui.key, data.settings.routines).filter(r => r.block === cb);
        // routines then tasks; optionally only what's still open; at most N (setting)
        let lines = br.map(r => ({ open: !day.routines[r.id], text: `${day.routines[r.id] ? 'X' : '·'}  ${r.label}`, cls: day.routines[r.id] ? 'dim' : 'routine-line' }))
          .concat(bt.map(t => ({ open: t.status === 'open', text: `${blockGlyph(t)}  ${t.time ? t.time + ' ' : ''}${t.u ? 'u ' : ''}${t.star ? '* ' : ''}${t.text}`, cls: t.status === 'open' ? '' : 'dim' })));
        if (data.settings.cardBlockOpen) lines = lines.filter(x => x.open);
        const max = data.settings.cardBlock == null ? 99 : data.settings.cardBlock;
        if (!lines.length) row(data.settings.cardBlockOpen && (bt.length || br.length) ? T('이 블럭 다 끝냄') : T('이 블럭에 할 일 없음'), 'dim');
        lines.slice(0, max).forEach(x => row(x.text, x.cls));
        if (lines.length > max) row(T('그 외 {n}개', { n: lines.length - max }), 'dim');
      },
      notes: () => {
        const all = data.notes || [], ns = all.filter(n => n.pinned).concat(all.filter(n => !n.pinned)).filter(n => noteTitle(n));
        if (!ns.length) { row(T('메모 없음'), 'dim'); return; }
        ns.slice(0, 5).forEach(n => row('✎ ' + noteTitle(n), 'note-line'));
        if (ns.length > 5) row(T('그 외 {n}개', { n: ns.length - 5 }), 'dim');
      },
      music: () => {
        // song and artist only (Windows reports changes a beat late, so no play/pause buttons)
        const np = ui.nowPlaying;
        if (np && np.title) row(['♪ ' + np.title].concat(np.artist ? [np.artist] : []), 'song');
        else row('♪ ' + T('재생 중인 노래 없음'), 'dim');
      }
    };
    if (ui.focusing && ui.focusing.timer) {
      const left = Math.max(0, ui.focusing.until - Date.now());
      row(`⏱ ${Math.floor(left / 60000)}:${String(Math.floor(left / 1000) % 60).padStart(2, '0')}`, 'big timer');
    }
    cardOrder().forEach(k => {
      if (!show.includes(k) || !SECTION[k] || (k === 'time' && show.includes('date'))) return;
      const g = document.createElement('div'); g.className = 'grp grp-' + k;
      into = g; SECTION[k](); into = box;
      if (g.children.length) box.appendChild(g);
    });
    box.hidden = !box.children.length;
    positionWidget();
  }
  // where the info card sits: beside her feet (default), beside her head, or right over her head
  function positionWidget() {
    const box = $('widget');
    if (box.hidden || !data) return;
    let where = data.settings.widgetPos || 'feet';
    if (where === 'over' && ui.panelOpen) where = 'head';            // preview while the panel is open: beside her, not under the panel
    const W = window.innerWidth, H = window.innerHeight, r = imgRect();
    const right = !document.body.classList.contains('lay-left'), bottom = !document.body.classList.contains('lay-top');
    box.style.left = box.style.right = box.style.top = box.style.bottom = '';
    if (where === 'over') {
      box.style.maxWidth = '240px';
      const bw = box.offsetWidth, cx = r.left + r.width / 2;
      box.style.left = Math.max(8, Math.min(W - bw - 8, cx - bw / 2)) + 'px';
      // the speech bubble hugs her head; the card stacks on the far side of it while she talks
      const b = $('bubble'), talking = !b.hidden && !b.classList.contains('beside');
      const br = talking ? b.getBoundingClientRect() : null;
      if (bottom) box.style.bottom = (H - (talking ? br.top : r.top) + 8) + 'px'; else box.style.top = ((talking ? br.bottom : r.bottom) + 8) + 'px';
      if (talking) {                                 // no room left past the bubble: tuck the card until it closes
        const v = vis(), wr = box.getBoundingClientRect();
        box.classList.toggle('tucked', wr.top < v.top + 4 || wr.bottom > v.bottom - 4);
      }
    } else {
      box.style.maxWidth = Math.max(140, (right ? r.left : W - r.right) - 18) + 'px';
      if (right) box.style.right = (W - r.left + 8) + 'px'; else box.style.left = (r.right + 8) + 'px';
      const atHead = where === 'head';
      // "feet" hugs her bottom edge (top edge in a top corner); "head" lines up with her head
      if (bottom === !atHead) { if (bottom) box.style.bottom = (H - r.bottom + 4) + 'px'; else box.style.top = (r.top + 4) + 'px'; }
      else if (bottom) box.style.top = (r.top + 4) + 'px'; else box.style.bottom = (H - r.bottom + 4) + 'px';
    }
    fitPreview();
  }
  // the card as a settings preview: keep it below the open panel (it shrinks and scrolls if it has to)
  // settings preview: the card sits right next to the panel (on the side away from the character's screen edge),
  // the window grows sideways to make room, and nothing gets pushed. Too tall for the screen: it shrinks to fit.
  const PREVIEW_W = 250;
  function fitPreview() {
    const box = $('widget');
    box.style.maxHeight = ''; box.style.overflow = ''; box.style.transform = ''; box.style.transformOrigin = ''; box.style.maxWidth = '';
    if (!ui.panelOpen || box.hidden || !document.body.classList.contains('card-preview')) return;
    const p = $('panel').getBoundingClientRect(), v = vis(), right = !document.body.classList.contains('lay-left');
    box.style.left = box.style.right = box.style.top = box.style.bottom = '';
    box.style.maxWidth = (PREVIEW_W - 16) + 'px';
    if (right) box.style.right = (window.innerWidth - p.left + 10) + 'px'; else box.style.left = (p.right + 10) + 'px';
    const top = Math.max(v.top + 8, p.top);
    box.style.top = top + 'px';
    // stays within the panel's height, so it never runs into the speech bubble under the panel
    const r = box.getBoundingClientRect(), room = Math.min(v.bottom - 8, p.bottom) - top;
    if (r.height > room && room > 60) {
      box.style.transformOrigin = `${right ? 'right' : 'left'} top`;
      box.style.transform = `scale(${Math.max(0.4, room / r.height).toFixed(3)})`;
    }
  }
  function previewMode(on) {
    document.body.classList.toggle('card-preview', on);
    document.documentElement.style.setProperty('--panel-lift', '0px');
    if (api.setExtraWidth) api.setExtraWidth(on ? PREVIEW_W : 0);
    setTimeout(() => { fitPanel(); renderWidget(); positionBubble(); }, 60);
  }
  // Bluetooth devices the card shows (all connected ones unless you untick some)
  function shownBt() { const hide = data.settings.btHide || []; return ui.bt.filter(d => !hide.includes(d.name)); }
  function fillBtPick() {
    const known = data.settings.btKnown || [];
    $('btPickWrap').hidden = !known.length;
    const box = $('btPick'); box.innerHTML = '';
    known.forEach(name => {
      const lab = document.createElement('label');
      const cb = document.createElement('input'); cb.type = 'checkbox';
      cb.checked = !(data.settings.btHide || []).includes(name);
      cb.addEventListener('change', () => {
        const hide = new Set(data.settings.btHide || []);
        cb.checked ? hide.delete(name) : hide.add(name);
        data.settings.btHide = [...hide]; persist(); renderWidget(); renderStatus();
      });
      const live = ui.bt.find(d => d.name === name);
      lab.append(cb, document.createTextNode(` ${name}${live ? ` (${live.level}%)` : ` (${T('연결 안 됨')})`}`));
      box.appendChild(lab);
    });
  }
  // what the card shows (ticks) and in what order (↑ ↓ moves a row; the card follows this order)
  function fillShowPick() {
    if (!data.settings.show) data.settings.show = ['tasks'];
    const box = $('showPick');
    const labels = {};
    box.querySelectorAll(':scope > label').forEach(l => { labels[l.querySelector('input').value] = l; });
    const draw = () => {
      cardOrder().forEach((k, idx, arr) => {
        const l = labels[k]; if (!l) return;
        let mv = l.querySelector('.mv');
        if (!mv) {
          mv = document.createElement('span'); mv.className = 'mv';
          [['↑', -1, T('위로')], ['↓', 1, T('아래로')]].forEach(([g, d, title]) => {
            const b = document.createElement('button'); b.type = 'button'; b.textContent = g; b.title = title; b.setAttribute('aria-label', title);
            b.addEventListener('click', (e) => {
              e.preventDefault();
              const o = cardOrder(), at = o.indexOf(k), to = at + d;
              if (to < 0 || to >= o.length) return;
              [o[at], o[to]] = [o[to], o[at]];
              data.settings.cardOrder = o; persist(); renderWidget(); draw();
            });
            mv.appendChild(b);
          });
          l.appendChild(mv);
        }
        mv.children[0].disabled = idx === 0; mv.children[1].disabled = idx === arr.length - 1;
        box.appendChild(l);                          // re-append = reorder
        const sub = { tasks: 'ccTasks', block: 'ccBlock', u: 'ccU' }[k];
        if (sub && $(sub)) { box.appendChild($(sub)); $(sub).hidden = !l.querySelector('input').checked; }
      });
    };
    box.querySelectorAll(':scope > label > input').forEach(el => {
      el.checked = data.settings.show.includes(el.value);
      el.addEventListener('change', () => {
        const cur = new Set(data.settings.show || []);
        el.checked ? cur.add(el.value) : cur.delete(el.value);
        data.settings.show = [...cur];
        const sub = { tasks: 'ccTasks', block: 'ccBlock', u: 'ccU' }[el.value];
        if (sub && $(sub)) $(sub).hidden = !el.checked;
        persist(); renderWidget();
        if (el.value === 'music') api.settingsChanged('music');   // the music watcher also feeds the card
      });
    });
    draw();
    // how many tasks the card lists: any number (− / + or type it), or all of them (99)
    const countControl = (key, def, inp, minus, plus, all) => {
      const cur = () => (data.settings[key] == null ? def : data.settings[key]);
      const show = () => { const v = cur(); all.checked = v >= 99; inp.disabled = v >= 99; inp.value = v >= 99 ? '' : v; };
      const put = (v) => { data.settings[key] = Math.max(0, Math.min(99, Math.round(v) || 0)); persist(); renderWidget(); show(); };
      inp.addEventListener('change', () => put(+inp.value));
      minus.addEventListener('click', () => put(Math.min(cur(), 98) - 1));
      plus.addEventListener('click', () => put(cur() >= 99 ? 99 : cur() + 1));
      all.addEventListener('change', () => put(all.checked ? 99 : 3));
      show();
    };
    countControl('cardTasks', 3, $('setCardTasks'), $('cardTasksMinus'), $('cardTasksPlus'), $('cardTasksAll'));
    countControl('cardBlock', 99, $('setCardBlock'), $('cardBlockMinus'), $('cardBlockPlus'), $('cardBlockAll'));
    countControl('cardU', 4, $('setCardU'), $('cardUMinus'), $('cardUPlus'), $('cardUAll'));
    $('cardTasksOpen').checked = data.settings.cardTasksOpen !== false;
    $('cardTasksOpen').addEventListener('change', () => { data.settings.cardTasksOpen = $('cardTasksOpen').checked; persist(); renderWidget(); });
    $('cardBlockOpen').checked = !!data.settings.cardBlockOpen;
    $('cardBlockOpen').addEventListener('change', () => { data.settings.cardBlockOpen = $('cardBlockOpen').checked; persist(); renderWidget(); });
  }

  // ---------- where things sit around the character ----------
  function onLayout(l) {
    const c = document.body.classList;
    c.toggle('lay-left', l.h === 'left'); c.toggle('lay-right', l.h !== 'left');
    c.toggle('lay-top', l.v === 'top'); c.toggle('lay-bottom', l.v !== 'top');
    if (l.vis) ui.vis = l.vis;
    fitPanel();
    positionWidget();
    positionBubble();
  }
  // the visible part of the window (the rest may hang off the screen edge) — set by the main process
  function vis() { return ui.vis || { top: 0, bottom: window.innerHeight, left: 0, right: window.innerWidth }; }
  // the task panel gets only the room that is really on screen between her and the screen edge
  function fitPanel() {
    if (!data) return;
    const v = vis(), H = window.innerHeight;
    const h = sizeOf(data.settings).charPx;
    const room = document.body.classList.contains('lay-top') ? v.bottom - (h + 16) - 8 : (H - h - 16) - v.top - 8;
    document.documentElement.style.setProperty('--panel-max', Math.max(180, Math.min(sizeOf(data.settings).panelH, room)) + 'px');
  }
  // the drawn part of the character image (object-fit can leave empty bands inside the element)
  // Measured from layout, not getBoundingClientRect on the image: that one includes the bobbing/breathing
  // animation, which made the info card and bubble wobble along with her.
  function imgRect() {
    const im = $('buddyImg'), slot = $('buddy').getBoundingClientRect();
    const ew = im.offsetWidth, eh = im.offsetHeight;
    const top0 = document.body.classList.contains('lay-top') ? slot.top : slot.bottom - eh;
    const r = { left: slot.left + (slot.width - ew) / 2, top: top0, width: ew, height: eh };
    r.right = r.left + ew; r.bottom = r.top + eh;
    if (!im.naturalWidth || !r.width) return r;
    const k = Math.min(r.width / im.naturalWidth, r.height / im.naturalHeight);
    const w = im.naturalWidth * k, h = im.naturalHeight * k;
    const top = document.body.classList.contains('lay-top') ? r.top : r.bottom - h;
    const left = r.left + (r.width - w) / 2;
    return { left, top, right: left + w, bottom: top + h, width: w, height: h };
  }
  // stick the speech bubble to the character: above her head (or below, in a top corner), or beside her
  function positionBubble() {
    const b = $('bubble');
    if (!data || b.hidden) return;
    const W = window.innerWidth, H = window.innerHeight, r = imgRect();
    const right = !document.body.classList.contains('lay-left');
    const bottom = !document.body.classList.contains('lay-top');
    const v = vis();
    let beside = ui.panelOpen || data.settings.bubblePos === 'side';
    if (!beside) {                                   // not enough screen above (or below) her head: put it beside her
      const room = bottom ? r.top - v.top : v.bottom - r.bottom;
      if (room < 110) beside = true;
    }
    b.style.left = b.style.right = b.style.top = b.style.bottom = '';
    b.classList.remove('tail-down', 'tail-up', 'tail-left', 'tail-right');
    b.classList.toggle('beside', beside);
    if (beside) {
      const room = right ? r.left - 22 : W - r.right - 22;
      b.style.maxWidth = Math.max(140, Math.min(300, room)) + 'px';
      if (right) b.style.right = (W - r.left + 12) + 'px'; else b.style.left = (r.right + 12) + 'px';
      const bh = b.offsetHeight;
      // keep clear of the task panel (above her in a bottom corner, below her in a top corner)
      const panel = ui.panelOpen ? $('panel').getBoundingClientRect() : null;
      let top = r.top + Math.min(40, r.height * .15);
      const minTop = bottom && panel ? panel.bottom + 8 : v.top + 8;
      const maxTop = (!bottom && panel ? panel.top - 8 : v.bottom - 8) - bh;
      top = Math.max(minTop, Math.min(maxTop, top));
      if (top + bh > v.bottom - 8) top = Math.max(v.top + 8, v.bottom - 8 - bh);   // too tall: overlap the panel edge rather than run off-screen
      if (top < v.top + 8) top = v.top + 8;
      b.style.top = top + 'px';
      b.style.setProperty('--tail', Math.max(14, Math.min(bh - 28, r.top + r.height * .3 - top)) + 'px');
      b.classList.add(right ? 'tail-right' : 'tail-left');
    } else {
      b.style.maxWidth = '300px';
      const bw = b.offsetWidth;
      const cx = r.left + r.width / 2;
      const left = Math.max(8, Math.min(W - bw - 8, cx - bw / 2));
      b.style.left = left + 'px';
      if (bottom) b.style.bottom = (H - r.top + 12) + 'px'; else b.style.top = (r.bottom + 12) + 'px';
      b.style.setProperty('--tail', Math.max(22, Math.min(bw - 22, cx - left)) + 'px');
      b.classList.add(bottom ? 'tail-down' : 'tail-up');
    }
    if (!beside && data.settings.widgetPos === 'over') { $('widget').classList.remove('tucked'); positionWidget(); return; }
    avoidWidget(b, bottom, v);
  }
  // the bubble and the info card must never sit on top of each other: lift the bubble past the card,
  // and if there is no room for that, tuck the card away until the bubble closes
  function avoidWidget(b, bottom, v) {
    const w = $('widget');
    w.classList.remove('tucked');
    if (w.hidden) return;
    const hit = (a, c) => a.left < c.right && c.left < a.right && a.top < c.bottom && c.top < a.bottom;
    let br = b.getBoundingClientRect();
    const wr = w.getBoundingClientRect();
    if (!hit(br, wr)) return;
    const bh = br.height;
    if (b.classList.contains('beside')) {
      const top = bottom ? wr.top - 8 - bh : wr.bottom + 8;
      if (top >= v.top + 8 && top + bh <= v.bottom - 8) {
        b.style.top = top + 'px';
        const r = imgRect();
        b.style.setProperty('--tail', Math.max(14, Math.min(bh - 28, r.top + r.height * .3 - top)) + 'px');
        br = b.getBoundingClientRect();
        if (!hit(br, wr)) return;
      }
    }
    w.classList.add('tucked');
  }

  // ---------- speech bubble ----------
  function say(text, buttons, opts) {
    if (!text) return;
    const o = Object.assign({}, opts || {});
    if (o.kind) lastKind = o.kind;
    const prio = o.prio || (ui.sim || PRIORITY3.has(lastKind) ? 3 : 2);
    const b = $('bubble');
    const asking = !b.hidden && $('bubbleButtons').children.length > 0;
    if (asking && prio < 3) {                       // a question is waiting for you: this can wait its turn
      ui.pending = { text, buttons, opts: Object.assign(o, { kind: lastKind }) };
      lastKind = null;
      return;
    }
    $('bubbleText').textContent = text;
    const mood = o.face || MOOD[lastKind] || 'neutral';
    const keepMs = o.keep || (o.sticky ? 3 * MIN : 9000);
    const r = REACT[lastKind];
    ui.react = r && has(r) ? { name: r, until: Date.now() + Math.min(keepMs, 60000) } : null;
    lastKind = null;
    render();
    const face = $('bubbleFace');
    const f = has('face_' + mood) ? mood : (has('face_neutral') ? 'neutral' : null);
    face.hidden = !f;
    if (f) face.src = A('face_' + f);
    const box = $('bubbleButtons');
    box.innerHTML = '';
    (buttons || []).forEach(btn => {
      const el = document.createElement('button');
      el.type = 'button';
      el.textContent = btn.label;
      if (btn.primary) el.className = 'primary';
      el.addEventListener('click', (e) => { e.stopPropagation(); hideBubble(); btn.run(); });
      box.appendChild(el);
    });
    if (!ui.focusing) $('focusTimer').hidden = true;
    b.hidden = false;
    positionBubble();
    b.style.animation = 'none'; void b.offsetWidth; b.style.animation = '';
    clearTimeout(ui.bubbleTimer);
    const keep = o.keep || (o.sticky ? 3 * MIN : 9000);
    ui.bubbleTimer = setTimeout(hideBubble, keep);
    ui.lastChatter = Date.now();
  }
  function hideBubble() {
    $('bubble').hidden = true; clearTimeout(ui.bubbleTimer);
    $('widget').classList.remove('tucked');
    positionWidget();
    if (ui.react) { ui.react = null; render(); }
    if (ui.pending) {                               // something waited behind a question: say it now
      const p = ui.pending; ui.pending = null;
      setTimeout(() => say(p.text, p.buttons, p.opts), 700);
    }
  }

  // ---------- task panel ----------
  function openPanel() {
    ui.panelOpen = true;
    document.body.classList.add('panel-open');
    $('panel').hidden = false;
    positionBubble();
    renderPanel(); render();
    api.focusPanel();
    if (syncer) syncer.now();                         // opening the list pulls what the phone changed
    setTimeout(() => $('addInput').focus(), 50);
    if ($('bubble').hidden) say(say_('memo'));
  }
  function closePanel() {
    ui.panelOpen = false;
    document.body.classList.remove('panel-open');
    $('panel').hidden = true;
    if (document.body.classList.contains('card-preview')) previewMode(false);
    positionWidget(); positionBubble();
    render();
  }
  function togglePanel() { ui.panelOpen ? closePanel() : openPanel(); }

  // ---------- blocks (블럭식스): the day in six blocks; you move to the next one yourself ----------
  function curBlock() { const d = today(); return d.block || 1; }
  function carry(fromKey, id) {
    if (!L.carryOver(data, fromKey, id, ui.key)) return;
    const d = today(), nt = d.tasks[d.tasks.length - 1]; if (nt) nt.block = curBlock();
  }
  $('blockPrev').addEventListener('click', () => setBlock(curBlock() - 1));
  $('blockNext').addEventListener('click', () => {
    const d = today(), cur = curBlock();
    const left = d.tasks.filter(t => t.block === cur && t.kind === 'task' && t.status === 'open');
    if (!left.length) return setBlock(cur + 1);
    // like the notebook's ">": take what's left along, or leave it where it is
    lastKind = 'migrate';
    say(T('{n}블럭에 남은 거 {c}개, 다음 블럭으로 옮길까?', { n: cur, c: left.length }), [
      { label: T('옮기고 넘어가기'), primary: true, run: () => { left.forEach(t => { t.block = cur + 1; }); setBlock(cur + 1); } },
      { label: T('그냥 넘어가기'), run: () => setBlock(cur + 1) },
      { label: T('취소'), run: () => {} }
    ], { sticky: true, prio: 3 });
  });
  function setBlock(n) { const d = today(); d.block = Math.max(1, Math.min(6, n)); if (typeof ui.blockView === 'number') ui.blockView = d.block; else if (!ui.blockView) { ui.blockView = d.block; ui.blockOnly = false; } persist(); renderPanel(); renderWidget(); }
  const blockGlyph = (t) => t.kind === 'event' ? '○' : ({ open: '·', done: 'X', migrated: '>', scheduled: '<' }[t.status] || '·');
  function renderBlocks() {
    const box = $('blocks'); if (!box) return;
    const d = today(), cur = curBlock();
    // ‹ 현재 블럭 N › — moving on is its own small control, so clicking the boxes only changes what you look at
    $('blockNow').textContent = T('현재 블럭 {n}', { n: cur });
    $('blockPrev').disabled = cur <= 1; $('blockNext').disabled = cur >= 6;
    box.innerHTML = '';
    box.classList.toggle('by-block', ui.blockView === 'byBlock');
    if (!box.dataset.wired) {
      box.dataset.wired = '1';
      box.title = T('블럭 밖을 누르면 블럭 순서대로');
      box.addEventListener('click', () => { ui.blockView = ui.blockView === 'byBlock' ? null : 'byBlock'; renderPanel(); });
    }
    for (let n = 1; n <= 6; n++) {
      const cell = document.createElement('button'); cell.type = 'button';
      cell.className = 'block' + (n === cur ? ' cur' : '') + (n < cur ? ' past' : '') + (ui.blockView === n ? ' focus' : '');
      cell.title = T('{n}블럭 할 일을 위로', { n });
      const num = document.createElement('span'); num.className = 'bn'; num.textContent = n; cell.appendChild(num);
      const gl = document.createElement('span'); gl.className = 'bg';
      L.routinesFor(ui.key, data.settings.routines).filter(r => r.block === n).forEach(r => {
        const s = document.createElement('i'); const dn = !!d.routines[r.id]; s.textContent = dn ? 'X' : '·'; s.className = 'g-routine' + (dn ? ' g-done' : ''); gl.appendChild(s);
      });
      L.ordered(d.tasks, d.customOrder).filter(t => t.block === n && (t.kind === 'task' || t.kind === 'event')).forEach(t => {
        const s = document.createElement('i'); s.textContent = blockGlyph(t); s.className = 'g-' + (t.kind === 'event' ? 'event' : t.status); gl.appendChild(s);
      });
      cell.appendChild(gl);
      cell.addEventListener('click', (e) => { e.stopPropagation(); if (ui.blockView !== n) { ui.blockView = n; ui.blockOnly = false; } else if (!ui.blockOnly) ui.blockOnly = true; else { ui.blockView = null; ui.blockOnly = false; } renderPanel(); });
      box.appendChild(cell);
    }
  }
  // everything in the current block is finished: offer to move on (once per block)
  function checkBlockDone() {
    const d = today(), cur = curBlock();
    const inBlock = d.tasks.filter(t => t.block === cur && t.kind === 'task').map(t => t.status)
      .concat(L.routinesFor(ui.key, data.settings.routines).filter(r => r.block === cur).map(r => (d.routines[r.id] ? 'done' : 'open')));
    if (!inBlock.length || inBlock.includes('open') || !inBlock.includes('done')) return;
    if (d.fired['block' + cur] || cur >= 6) return;
    d.fired['block' + cur] = true; persist();
    setTimeout(() => {
      lastKind = 'praiseAll';
      say(T('{n}블럭 다 끝냈어. 다음 블럭으로 넘어갈까?', { n: cur }), [
        { label: T('{n}블럭으로', { n: cur + 1 }), primary: true, run: () => setBlock(cur + 1) },
        { label: T('조금 더'), run: () => {} }
      ], { sticky: true, prio: 3 });
    }, 2600);
  }

  function renderPanel() {
    if (!data) return;
    const day = today();
    $('dayLabel').textContent = L.label(ui.key);
    const c = CNT(day);
    $('dayCount').textContent = c.total ? T('{a} / {b} 끝 · 남은 거 {n}개', { a: c.done, b: c.total, n: c.open }) : T('아직 적은 게 없어요');

    const list = $('taskList'); list.innerHTML = '';
    // 1) left over from earlier days: tinted, you decide — back to today, or let it go
    const left = L.leftovers(data, ui.key, 14);
    if (left.length) {
      const head = document.createElement('li'); head.className = 'sec sec-left';
      head.append(document.createTextNode(T('지난 날 남은 거 {n}개', { n: left.length })));
      const all = document.createElement('button'); all.type = 'button'; all.className = 'sec-btn'; all.textContent = T('모두 오늘로');
      all.addEventListener('click', () => { left.forEach(x => carry(x.key, x.task.id)); persist(); renderPanel(); say(say_('migrate')); });
      const tog = document.createElement('button'); tog.type = 'button'; tog.className = 'sec-btn'; tog.textContent = ui.leftOpen ? T('접기') : T('펼치기');
      tog.addEventListener('click', () => { ui.leftOpen = !ui.leftOpen; renderPanel(); });
      const btns = document.createElement('span'); btns.className = 'sec-btns'; btns.append(tog, all);
      head.appendChild(btns); list.appendChild(head);
      if (ui.leftOpen) left.forEach(({ key, task }) => {
        const li = document.createElement('li'); li.className = 'task leftover';
        const marks = document.createElement('span'); marks.className = 'marks'; marks.textContent = (task.u ? 'u' : '') + (task.star ? '*' : ''); li.appendChild(marks);
        const g = document.createElement('span'); g.className = 'glyph-s'; g.textContent = L.glyph(task); li.appendChild(g);
        const tx = document.createElement('span'); tx.className = 'text'; tx.textContent = task.text;
        const f = document.createElement('span'); f.className = 'from'; f.textContent = L.label(key); tx.appendChild(f); li.appendChild(tx);
        const acts = document.createElement('span'); acts.className = 'acts show';
        acts.appendChild(actBtn('↩', T('오늘 할 일로'), () => { carry(key, task.id); persist(); renderPanel(); }));
        acts.appendChild(actBtn('✕', T('지우기'), () => { L.dropLeftover(data, key, task.id); persist(); renderPanel(); }));
        li.appendChild(acts); list.appendChild(li);
      });
    }
    // 2) routines + 3) today's tasks — all in your order (routines first), grouped by block, or one block on top
    const v = ui.blockView;
    const items = L.routinesFor(ui.key, data.settings.routines).map(r => ({ r, block: r.block }))
      .concat(L.tree(day.tasks, day.customOrder).map(x => ({ t: x.t, block: x.block, depth: x.depth })));
    const bnum = (x) => x.block || 7;
    let shown = items;
    if (v === 'byBlock') shown = items.map((x, i) => ({ x, i })).sort((a, b) => bnum(a.x) - bnum(b.x) || a.i - b.i).map(y => y.x);
    else if (typeof v === 'number') shown = items.map((x, i) => ({ x, i, k: x.block === v ? 0 : 1 })).sort((a, b) => a.k - b.k || a.i - b.i).map(y => y.x);
    if (typeof v === 'number') {
      const h = document.createElement('li'); h.className = 'sec sec-block';
      h.append(document.createTextNode(T('{n}블럭', { n: v }) + (v === curBlock() ? ' · ' + T('지금 블럭') : '') + ' · ' + (ui.blockOnly ? T('이 블럭만') : T('한 번 더 누르면 이 블럭만'))));
      list.appendChild(h);
    }
    if (!day.tasks.length) {
      const li = document.createElement('li');
      li.className = 'empty';
      li.textContent = T('수첩에 적은 것 중에 컴퓨터로 할 것만 여기 적어줘. 5분짜리는 앞에 u.');
      list.appendChild(li);
    }
    let lastB = null;
    shown.forEach(x => {
      if (v === 'byBlock' && bnum(x) !== lastB) {
        lastB = bnum(x);
        const h = document.createElement('li'); h.className = 'sec sec-block';
        h.textContent = lastB === 7 ? T('블럭 없음') : T('{n}블럭', { n: lastB }) + (lastB === curBlock() ? ' · ' + T('지금 블럭') : '');
        list.appendChild(h);
      }
      const row = x.r ? routineRow(x.r, day) : taskRow(x.t, x.depth);
      if (typeof v === 'number' && x.block !== v) { if (ui.blockOnly) return; row.classList.add('dim'); }
      list.appendChild(row);
    });
    enableReorder(list, day);
    sortable(list, 'li.routine-row', (from, to, below) => {
      const all = routineList();
      const a = all.findIndex(r => r.id === from), m = all.splice(a, 1)[0];
      let b = all.findIndex(r => r.id === to); if (below) b++;
      all.splice(b, 0, m);
      const tr = all.find(r => r.id === to); if (ui.blockView && tr && (tr.block || 0) !== (m.block || 0)) m.block = tr.block;
      persist(); renderPanel();
    }, 'rid');
    renderBlocks();
    checkBlockDone();
    renderWidget();
  }

  // a block chip (1–6 or –) with its little picker; `get`/`set` read and write the block
  function blockChip(li, get, set) {
    const bk = document.createElement('button'); bk.type = 'button';
    bk.className = 'blk' + (get() ? '' : ' none'); bk.textContent = get() || '–';
    bk.title = T('블럭 고르기'); bk.setAttribute('aria-label', T('블럭 고르기'));
    bk.addEventListener('click', (e) => {
      e.stopPropagation();
      const open = li.querySelector('.blk-pick'); if (open) { open.remove(); return; }
      const pick = document.createElement('span'); pick.className = 'blk-pick';
      [1, 2, 3, 4, 5, 6, 0].forEach(n => {
        const b = document.createElement('button'); b.type = 'button'; b.textContent = n || '–';
        if ((get() || 0) === n) b.classList.add('on');
        b.addEventListener('click', (ev) => { ev.stopPropagation(); set(n || undefined); persist(); renderPanel(); });
        pick.appendChild(b);
      });
      li.appendChild(pick);
    });
    return bk;
  }
  // routines live in settings (the same every day), so their block is remembered for every day
  function routineList() {
    if (!data.settings.routines) data.settings.routines = L.DEFAULT_ROUTINES.map(r => ({ ...r, days: r.days.slice() }));
    return data.settings.routines;
  }
  function routineRow(r, day) {
    const done = !!day.routines[r.id];
    const li = document.createElement('li'); li.className = 'task routine-row' + (done ? ' done' : ''); li.dataset.rid = r.id; li.title = T('루틴');
    const marks = document.createElement('span'); marks.className = 'marks'; li.appendChild(marks);
    li.appendChild(blockChip(li, () => r.block, (n) => { const x = routineList().find(y => y.id === r.id); if (x) x.block = n; }));
    const g = document.createElement('button'); g.type = 'button'; g.className = 'glyph' + (done ? ' done' : ''); g.textContent = done ? 'X' : '·';
    g.setAttribute('aria-label', done ? T('완료 취소') : T('완료'));
    g.addEventListener('click', () => {
      day.routines[r.id] = !day.routines[r.id]; persist(); renderPanel();
      if (day.routines[r.id]) { ui.hopUntil = Date.now() + 800; render(); say(say_('praise', { count: CNT(day).done, left: CNT(day).open })); }
    });
    li.appendChild(g);
    const tx = document.createElement('span'); tx.className = 'text'; tx.textContent = r.label; li.appendChild(tx);
    return li;
  }

  // drag to reorder: works the same for tasks, routines and memos
  function sortable(container, selector, onMove, key, handle, allowInto) {
    let dragId = null;
    container.querySelectorAll(selector).forEach(el => {
      const id = el.dataset[key || 'id'];
      if (handle) {
        const h = el.querySelector(handle);
        if (h) { h.addEventListener('mousedown', () => { el.draggable = true; }); h.addEventListener('mouseup', () => { el.draggable = false; }); }
      } else el.draggable = true;
      el.addEventListener('dragstart', (e) => { dragId = id; el.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', id); } catch (_) {} });
      el.addEventListener('dragend', () => { el.classList.remove('dragging'); if (handle) el.draggable = false; container.querySelectorAll('.drop-above, .drop-below, .drop-into').forEach(x => x.classList.remove('drop-above', 'drop-below', 'drop-into')); dragId = null; });
      el.addEventListener('dragover', (e) => {
        if (!dragId || id === dragId) return;
        e.preventDefault();
        const r = el.getBoundingClientRect(), y = (e.clientY - r.top) / r.height;
        const into = !!allowInto && y > 0.3 && y < 0.7, below = !into && y >= 0.5;
        el.classList.toggle('drop-into', into); el.classList.toggle('drop-below', below); el.classList.toggle('drop-above', !into && !below);
      });
      el.addEventListener('dragleave', () => el.classList.remove('drop-above', 'drop-below', 'drop-into'));
      el.addEventListener('drop', (e) => {
        e.preventDefault();
        if (!dragId || id === dragId) return;
        const from = dragId; dragId = null;
        onMove(from, id, el.classList.contains('drop-below'), el.classList.contains('drop-into'));
      });
    });
  }
  // tasks: the order is one list for the day; the block views are that list sorted by block, so moving a task in any
  // view keeps its place there. Dropping it among another block's tasks (block views) moves it into that block.
  // dropping onto the middle of a task puts it under that task (a sub-item); above/below moves it, with its sub-items
  function enableReorder(list, day) {
    sortable(list, 'li.task[data-id]', (from, to, below, into) => {
      const flat = L.tree(day.tasks, day.customOrder).map(x => x.t);
      const moving = flat.find(t => t.id === from), target = flat.find(t => t.id === to);
      if (!moving || !target) return;
      const TM = window.TaskMore, mine = [moving].concat(TM.kids(day, moving.id));
      if (into) {
        const host = target.parent ? flat.find(t => t.id === target.parent) : target;
        if (!TM.makeChild(day, moving, host)) return;
      } else {
        const rest = flat.filter(t => !mine.includes(t));
        let at = rest.indexOf(target);
        if (below) { at += 1; if (!target.parent) while (rest[at] && rest[at].parent === target.id) at++; }
        rest.splice(at, 0, ...mine);
        // landing among another task's sub-items makes it one of them (if it has none of its own)
        if (target.parent && mine.length === 1) { moving.parent = target.parent; moving.block = target.block; }
        else delete moving.parent;
        if (!moving.parent && ui.blockView && (target.block || 0) !== (moving.block || 0)) TM.setBlock(day, moving, target.block);
        day.tasks = rest; day.customOrder = true;
      }
      persist(); renderPanel();
    }, null, null, true);
  }

  function taskRow(t, depth) {
    const li = document.createElement('li');
    li.className = `task ${t.status}${t.kind === 'note' ? ' memo-line' : t.kind !== 'task' ? ' ' + t.kind : ''}${depth ? ' sub' : ''}`;   // (not .note: that's the music note)
    li.dataset.id = t.id;

    const marks = document.createElement('span');
    marks.className = 'marks';
    marks.textContent = (t.u ? 'u' : '') + (t.star ? '*' : '');
    li.appendChild(marks);

    // which block (1–6) this task belongs to; click to choose
    // (sub-items follow their task's block, so they get a small hook instead)
    if (depth) { const hook = document.createElement('span'); hook.className = 'blk-sp'; hook.textContent = '└'; li.appendChild(hook); }
    else li.appendChild(blockChip(li, () => t.block, (n) => { const x = today().tasks.find(y => y.id === t.id); if (x) window.TaskMore.setBlock(today(), x, n); }));

    const g = document.createElement('button');
    g.type = 'button';
    g.className = 'glyph' + (t.status === 'done' ? ' done' : '');
    g.textContent = L.glyph(t);
    const canToggle = (t.kind === 'task' || t.kind === 'event') && (t.status === 'open' || t.status === 'done');
    g.disabled = !canToggle;
    g.setAttribute('aria-label', t.status === 'done' ? T('완료 취소') : T('완료'));
    g.addEventListener('click', () => {
      const st = L.toggleDone(today(), t.id);
      persist(); renderPanel();
      if (st === 'done') { if (t.kind === 'task') praise(); else { ui.hopUntil = Date.now() + 800; render(); } }
    });
    li.appendChild(g);

    const text = document.createElement('span');
    text.className = 'text';
    const when = L.whenText(t, LANG);
    if (when) { const w = document.createElement('span'); w.className = 'when' + (t.time ? ' at' : ''); w.textContent = when; text.appendChild(w); }
    text.appendChild(document.createTextNode(t.text));
    if (t.status === 'scheduled' && t.to) text.appendChild(document.createTextNode(`  → ${L.label(t.to)}`));
    if (t.status === 'migrated') text.appendChild(document.createTextNode('  → ' + T('내일')));
    li.appendChild(text);
    if (t.from) {
      const f = document.createElement('span');
      f.className = 'from';
      f.textContent = T('({d}에서)', { d: L.label(t.from) });
      text.appendChild(f);
    }

    const acts = document.createElement('span');
    acts.className = 'acts';
    if (t.kind === 'task' && t.status === 'open') {
      acts.appendChild(actBtn('>', T('내일로 미루기'), () => { L.migrate(data, ui.key, t.id); persist(); renderPanel(); say(say_('migrate')); }));
      const date = document.createElement('input');
      date.type = 'date';
      date.min = L.addDays(ui.key, 1);
      date.addEventListener('change', () => {
        if (!date.value) return;
        L.schedule(data, ui.key, t.id, date.value); persist(); renderPanel();
        say(say_('schedule', { date: L.label(date.value) }));
      });
      acts.appendChild(date);
      acts.appendChild(actBtn('<', T('날짜 정해서 옮기기'), () => { try { date.showPicker(); } catch (e) { date.click(); } }));
    }
    // ⋯ : task / event / memo line, things under it, how long or when
    const more = actBtn('⋯', T('더 보기'), () => { if (ui.moreFor === t.id) window.TaskMore.close(); ui.moreFor = ui.moreFor === t.id ? null : t.id; renderPanel(); });
    if (ui.moreFor === t.id) more.classList.add('on');
    acts.appendChild(more);
    acts.appendChild(actBtn('✕', T('지우기'), () => {
      window.TaskMore.remove(today(), t);
      persist(); renderPanel();
    }));
    li.appendChild(acts);
    if (ui.moreFor === t.id) {
      li.classList.add('more-open');
      li.appendChild(window.TaskMore.panel(t, { T, lang: LANG, day: today(), changed: () => { persist(); renderPanel(); } }));
    }
    return li;
  }

  function actBtn(label, title, run) {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = label; b.title = title; b.setAttribute('aria-label', title);
    b.addEventListener('click', run);
    return b;
  }

  $('addForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const parsed = L.parseInput($('addInput').value);
    if (!parsed.text) return;
    const nt = L.newTask(parsed, new Date()); nt.block = typeof ui.blockView === 'number' ? ui.blockView : curBlock(); today().tasks.push(nt);
    if (parsed.sub) {                                   // "ㄴ ..." goes under the last task you can see in this view
      const tops = L.tree(today().tasks, today().customOrder).filter(x => x.depth === 0 && x.t !== nt && (typeof ui.blockView !== 'number' || x.block === ui.blockView));
      if (tops.length) window.TaskMore.makeChild(today(), nt, tops[tops.length - 1].t);
    }
    $('addInput').value = '';
    persist(); renderPanel();
  });
  $('closeBtn').addEventListener('click', () => { if (ui.sim) showView('today'); closePanel(); });
  $('copyBtn').addEventListener('click', copyForNotebook);
  // the panel shows one of: today's list, settings, or the situation test
  // settings in small sub-tabs: one section at a time (the character section comes last)
  function buildToc() {
    const wrap = $('settings');
    if (!wrap.dataset.tabbed) {
      wrap.dataset.tabbed = '1';
      const secs = [];
      let cur = null;
      [...wrap.children].forEach(el => {
        if (el.tagName === 'H3') { cur = document.createElement('section'); cur.className = 'set-sec'; cur.dataset.title = el.textContent; secs.push(cur); }
        if (cur) cur.appendChild(el);
      });
      const charSec = secs[0];                       // the character section is first in the page
      const order = secs.filter(x => x !== charSec).concat(charSec ? [charSec] : []);
      const toc = document.createElement('nav'); toc.id = 'settingsToc'; toc.className = 'toc'; toc.setAttribute('role', 'tablist');
      wrap.appendChild(toc);
      order.forEach((sec, k) => {
        wrap.appendChild(sec);
        const b = document.createElement('button'); b.type = 'button'; b.setAttribute('role', 'tab'); b.textContent = sec.querySelector('h3').textContent;
        b.addEventListener('click', () => { ui.setTab = k; showSetTab(); });
        toc.appendChild(b);
      });
    }
    showSetTab();
  }
  function showSetTab() {
    const secs = [...$('settings').querySelectorAll(':scope > .set-sec')], btns = [...$('settingsToc').children];
    const k = Math.min(ui.setTab || 0, secs.length - 1);
    secs.forEach((s, i) => { s.hidden = i !== k; });
    btns.forEach((b, i) => { b.classList.toggle('on', i === k); b.setAttribute('aria-selected', String(i === k)); });
    $('settings').scrollTop = 0;
  }
  function showView(v) {
    $('todayView').hidden = v !== 'today';
    $('notesView').hidden = v !== 'notes';
    if (v === 'notes') renderNotes();
    $('calView').hidden = v !== 'cal';
    if (v === 'cal') { ui.calMonth = ui.calMonth || ui.key.slice(0, 7); ui.calSel = ui.calSel || ui.key; renderCal(); }
    [['todayBtn', 'today'], ['calBtn', 'cal'], ['notesBtn', 'notes'], ['timerBtn', 'timer'], ['settingsBtn', 'settings']].forEach(([id, view]) => {
      $(id).classList.toggle('active', v === view); $(id).setAttribute('aria-selected', String(v === view));
    });
    $('copyBtn').hidden = v !== 'today';
    $('timerView').hidden = v !== 'timer';
    if (v === 'timer') openTimer();
    $('settings').hidden = v !== 'settings';
    $('testView').hidden = v !== 'test';
    if (v !== 'test' && ui.sim) endTest();
    if ((v === 'settings') !== document.body.classList.contains('card-preview')) previewMode(v === 'settings');
    $('widget').dataset.preview = T('미리보기');
    if (v === 'settings') setTimeout(() => { renderWidget(); }, 0);
    if (v === 'settings') buildToc();
    if (v === 'settings') { renderRoutineEditor(); if (api.getLogin) api.getLogin().then(x => { $('setLogin').checked = !!x; }); }
  }
  // ---------- memos: free notes, the first line is the title ----------
  function notes() { return data.notes || (data.notes = []); }
  const noteTitle = (n) => (String(n.text || '').split('\n').find(l => l.trim()) || '').trim();
  let noteSaveTimer = null;
  function renderNotes(focusId) {
    const box = $('noteList'); box.innerHTML = '';
    // pinned first, then your order (new ones on top; drag ⋮⋮ to move)
    const list = notes().filter(n => n.pinned).concat(notes().filter(n => !n.pinned));
    if (!list.length) {
      const p = document.createElement('p'); p.className = 'sub'; p.textContent = T('아직 메모가 없어요. + 새 메모로 시작해요.'); box.appendChild(p);
    }
    list.forEach(n => {
      const card = document.createElement('div'); card.className = 'memo-card' + (n.pinned ? ' pinned' : ''); card.dataset.id = n.id;
      const body = document.createElement('div'); body.className = 'body';
      body.contentEditable = 'plaintext-only'; body.spellcheck = false;
      body.dataset.ph = T('첫 줄은 제목');
      body.textContent = n.text || '';
      body.addEventListener('input', () => {
        n.text = body.innerText.replace(/\n$/, ''); n.updated = Date.now();
        meta.firstChild.lastChild.textContent = stamp(n.updated);
        clearTimeout(noteSaveTimer); noteSaveTimer = setTimeout(() => { persist(); renderWidget(); }, 400);
      });
      const meta = document.createElement('div'); meta.className = 'meta';
      const when = document.createElement('span');
      const grip = document.createElement('span'); grip.className = 'grip'; grip.textContent = '⋮⋮'; grip.title = T('끌어서 순서 바꾸기');
      when.append(grip, document.createTextNode(stamp(n.updated))); meta.appendChild(when);
      const btns = document.createElement('span');
      const pin = document.createElement('button'); pin.type = 'button'; pin.className = 'pin' + (n.pinned ? ' on' : '');
      pin.textContent = n.pinned ? T('고정됨') : T('위에 고정');
      pin.addEventListener('click', () => { n.pinned = !n.pinned; persist(); renderNotes(); renderWidget(); });
      btns.appendChild(pin);
      const ex = document.createElement('button'); ex.type = 'button'; ex.textContent = T('TXT'); ex.title = T('이 메모를 TXT로 내보내기');
      ex.addEventListener('click', () => exportNotes([n], noteTitle(n) || T('메모')));
      const del = document.createElement('button'); del.type = 'button'; del.textContent = T('지우기');
      del.addEventListener('click', () => {
        if (n.text && n.text.trim() && !del.dataset.sure) { del.dataset.sure = '1'; del.textContent = T('정말 지울까?'); setTimeout(() => { delete del.dataset.sure; del.textContent = T('지우기'); }, 2500); return; }
        data.notes = notes().filter(x => x !== n); persist(); renderNotes(); renderWidget();
      });
      btns.append(ex, del); meta.appendChild(btns);
      card.append(body, meta); box.appendChild(card);
      if (focusId === n.id) setTimeout(() => body.focus(), 0);
    });
    sortable(box, '.memo-card', (from, to, below) => {
      const all = notes(), m = all.find(x => x.id === from), t = all.find(x => x.id === to);
      all.splice(all.indexOf(m), 1);
      all.splice(all.indexOf(t) + (below ? 1 : 0), 0, m);
      m.pinned = !!t.pinned;                 // dropped among pinned ones = pinned too
      persist(); renderNotes(); renderWidget();
    }, 'id', '.grip');
  }
  function stamp(t) {
    if (!t) return '';
    const d = new Date(t), p = (x) => String(x).padStart(2, '0');
    return `${d.getMonth() + 1}/${d.getDate()} ${p(d.getHours())}:${p(d.getMinutes())}`;
  }
  async function exportNotes(list, name) {
    const text = list.map(n => n.text || '').join('\n\n---\n\n');
    if (!api.saveText) return;
    const r = await api.saveText(name, text);
    if (r && r.ok) say(T('저장했어. {f}', { f: r.path.split(/[\\/]/).pop() }));
  }
  $('noteNew').addEventListener('click', () => {
    const n = { id: 'n' + Date.now().toString(36), text: '', updated: Date.now() };
    notes().unshift(n); persist(); renderNotes(n.id);
  });
  $('noteExportAll').addEventListener('click', () => {
    const list = notes().slice().sort((a, b) => (b.updated || 0) - (a.updated || 0)).filter(n => (n.text || '').trim());
    if (list.length) exportNotes(list, T('책상 친구 메모') + ' ' + L.dateKey(new Date()));
  });

  // ---------- calendar: the month at a glance; pick a day to see it or put things on it ----------
  function renderCal() {
    const [y, m] = ui.calMonth.split('-').map(Number);
    $('calTitle').textContent = `${y}. ${m}`;
    const grid = $('calGrid'); grid.innerHTML = '';
    L.WEEK.forEach((w, i) => { const h = document.createElement('span'); h.className = 'wd' + (i === 0 ? ' sun' : i === 6 ? ' sat' : ''); h.textContent = w; grid.appendChild(h); });
    const first = new Date(y, m - 1, 1).getDay(), days = new Date(y, m, 0).getDate();
    for (let i = 0; i < first; i++) grid.appendChild(document.createElement('span'));
    for (let d = 1; d <= days; d++) {
      const key = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const day = data.days[key], ts = day ? day.tasks.filter(t => t.kind === 'task') : [];
      const done = ts.filter(t => t.status === 'done').length, open = ts.filter(t => t.status === 'open').length;
      const ev = day ? day.tasks.filter(t => t.kind === 'event').length : 0;
      const c = document.createElement('button'); c.type = 'button';
      c.className = 'cd' + (key === ui.key ? ' today' : '') + (key === ui.calSel ? ' sel' : '') + (open && key < ui.key ? ' left' : '');
      const n = document.createElement('span'); n.className = 'n'; n.textContent = d; c.appendChild(n);
      const dots = document.createElement('span'); dots.className = 'dots';
      dots.textContent = ts.length ? `${done}/${ts.length}` : '';
      c.appendChild(dots);
      if (ev) {
        const e1 = day.tasks.filter(t => t.kind === 'event').sort((a, b) => (a.time || '99').localeCompare(b.time || '99'))[0];
        const evs = document.createElement('span'); evs.className = 'ev1';
        evs.textContent = '○' + (e1.text || '').slice(0, 4) + (ev > 1 ? '+' + (ev - 1) : '');
        evs.title = day.tasks.filter(t => t.kind === 'event').map(t => (t.time ? t.time + ' ' : '') + t.text).join('\n');
        c.appendChild(evs);
      }
      c.addEventListener('click', () => { ui.calSel = key; renderCal(); });
      grid.appendChild(c);
    }
    // the chosen day
    const box = $('calDay'); box.innerHTML = '';
    const key = ui.calSel, day = data.days[key];
    const head = document.createElement('div'); head.className = 'cal-dh';
    head.textContent = L.label(key) + (key === ui.key ? ' · ' + T('오늘') : '');
    if (key === ui.key) {
      const go = document.createElement('button'); go.type = 'button'; go.className = 'pill'; go.textContent = T('할 일 열기');
      go.addEventListener('click', () => showView('today')); head.appendChild(go);
    }
    box.appendChild(head);
    const ul = document.createElement('ul'); ul.className = 'cal-list';
    // events (일정) first, by time; then the tasks in their order
    const all = day ? L.ordered(day.tasks, day.customOrder) : [];
    const items = all.filter(t => t.kind === 'event').sort((a, b) => (a.time || '99').localeCompare(b.time || '99')).concat(all.filter(t => t.kind !== 'event'));
    if (!items.length) { const li = document.createElement('li'); li.className = 'dim'; li.textContent = T('적은 게 없어요'); ul.appendChild(li); }
    items.forEach(t => {
      const li = document.createElement('li'); li.className = 's-' + t.status;
      li.textContent = `${L.glyph(t)}  ${t.time ? t.time + '  ' : ''}${t.u ? 'u ' : ''}${t.star ? '* ' : ''}${t.text}`;
      if (t.kind === 'event') li.classList.add('ev');
      if ((key > ui.key && t.status === 'open') || t.kind === 'event') {
        const x = document.createElement('button'); x.type = 'button'; x.textContent = '✕'; x.title = T('지우기');
        x.addEventListener('click', () => { day.tasks = day.tasks.filter(y => y !== t); persist(); renderCal(); });
        li.appendChild(x);
      }
      ul.appendChild(li);
    });
    box.appendChild(ul);
    // add to this day: an event (일정, with an optional time) on any day; a task on today or a later day
    {
      const f = document.createElement('form'); f.className = 'add-form cal-add';
      const kind = document.createElement('select'); kind.setAttribute('aria-label', T('종류'));
      [['event', T('일정')], ['task', T('할 일')]].forEach(([v, l]) => { const o = document.createElement('option'); o.value = v; o.textContent = l; kind.appendChild(o); });
      if (key < ui.key) kind.disabled = true;
      kind.value = ui.calKind && key >= ui.key ? ui.calKind : 'event';
      const tm = document.createElement('input'); tm.type = 'time'; tm.setAttribute('aria-label', T('시각'));
      const inp = document.createElement('input'); inp.type = 'text'; inp.placeholder = T('이 날에 추가');
      const b = document.createElement('button'); b.type = 'submit'; b.textContent = T('추가');
      const sync = () => { tm.hidden = kind.value !== 'event'; };
      kind.addEventListener('change', () => { ui.calKind = kind.value; sync(); }); sync();
      f.append(kind, tm, inp, b);
      f.addEventListener('submit', (e) => {
        e.preventDefault();
        const p = L.parseInput(inp.value); if (!p.text) return;
        if (kind.value === 'event') p.kind = 'event';
        const nt = L.newTask(p, new Date());
        if (p.kind === 'event' && tm.value) nt.time = tm.value;
        L.ensureDay(data, key).tasks.push(nt); persist(); renderCal(); if (key === ui.key) renderPanel();
        setTimeout(() => { const i2 = $('calDay').querySelector('input[type=text]'); if (i2) i2.focus(); }, 0);
      });
      box.appendChild(f);
    }
  }
  const monthShift = (d) => { const [y, m] = ui.calMonth.split('-').map(Number); const t = new Date(y, m - 1 + d, 1); ui.calMonth = `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}`; renderCal(); };
  $('calPrev').addEventListener('click', () => monthShift(-1));
  $('calNext').addEventListener('click', () => monthShift(1));
  $('calBtn').addEventListener('click', () => showView($('calView').hidden ? 'cal' : 'today'));

  // for checking the "left over from earlier days" list without waiting a day
  $('sampleLeft').addEventListener('click', () => {
    const yk = L.addDays(ui.key, -1), d = L.ensureDay(data, yk);
    [T('(예시) 어제 못 한 자료 정리'), 'u ' + T('(예시) 메일 하나 답장')].forEach(txt => d.tasks.push(L.newTask(L.parseInput(txt), new Date())));
    persist(); ui.leftOpen = true; showView('today'); renderPanel();
  });

  $('todayBtn').addEventListener('click', () => showView('today'));
  $('notesBtn').addEventListener('click', () => showView($('notesView').hidden ? 'notes' : 'today'));
  $('settingsBtn').addEventListener('click', () => showView($('settings').hidden ? 'settings' : 'today'));
  $('timerBtn').addEventListener('click', () => showView($('timerView').hidden ? 'timer' : 'today'));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && ui.panelOpen) closePanel(); });

  // ---------- characters ----------
  function displayName() { return (data.settings.names || {})[CH.id] || charName(CH); }
  function initCharacter() {
    const st = data.settings;
    st.names = st.names || {};
    // older versions kept one custom name for Shiori in settings.name
    if (!st.character && st.name && st.name !== CHARS.shiori.name && !st.names.shiori) st.names.shiori = st.name;
    CH = CHARS[st.character] || CHARS.shiori;
    st.character = CH.id;
    applyTheme();
    st.name = displayName();
  }
  // every tab's main colour follows the character
  function applyTheme() {
    const t = CH.theme; if (!t) return;
    const r = document.documentElement.style;
    r.setProperty('--mint', t.mint); r.setProperty('--mint-deep', t.deep); r.setProperty('--mint-hover', t.hover);
    r.setProperty('--soft', t.soft); r.setProperty('--line', t.line);
  }
  function switchCharacter(id) {
    if (!CHARS[id] || id === CH.id) return;
    CH = CHARS[id];
    applyTheme();
    data.settings.character = id;
    data.settings.name = displayName();
    persist(); api.settingsChanged('basic');
    $('setName').value = (data.settings.names || {})[id] || '';
    $('setName').placeholder = charName(CH);
    ui.img = null;
    render(); renderProfile(); renderCharPick();
    if (!$('testView').hidden) buildTestView();
    say(say_('switchIn'));
  }
  function renderCharPick() {
    const box = $('charPick'); box.innerHTML = '';
    Object.values(CHARS).forEach(c => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'char' + (c.id === CH.id ? ' on' : '');
      b.setAttribute('aria-pressed', String(c.id === CH.id));
      const im = document.createElement('img');
      im.src = `assets/${c.id}/face_neutral.png`; im.alt = '';
      b.append(im, document.createTextNode(charName(c)));
      b.addEventListener('click', () => switchCharacter(c.id));
      box.appendChild(b);
    });
  }
  function renderProfile() {
    const name = displayName();
    $('profileName').textContent = name;
    const pf = profileOf(CH);
    $('profileHanja').textContent = name === charName(CH) ? pf.hanja : charName(CH);
    $('profileQuote').textContent = `“${pf.quote}”`;
    const dl = $('profileFacts');
    dl.innerHTML = '';
    pf.facts.forEach(([k, v]) => {
      const dt = document.createElement('dt'); dt.textContent = k;
      const dd = document.createElement('dd'); dd.textContent = v;
      dl.append(dt, dd);
    });
    const img = $('profileImg');
    img.hidden = !has('profile');
    if (has('profile')) { img.src = A('profile'); img.alt = T('{name} 전신', { name }); }
    $('buddy').title = T('{name} · 누르면 할 일 · 끌어서 이동', { name });
  }
  function openProfile() {
    if (!ui.panelOpen) openPanel();
    showView('settings');
    $('settings').scrollTop = 0;
  }

  // ---------- situation test ----------
  // every situation the character can be in, so the drawings and lines can be checked without waiting for them
  const TV = { task: '포트폴리오 2p 배치 다시 잡기', count: 3, left: 2, title: 'lo-fi beats', name: 'Galaxy Buds2', level: 15, date: '10/27' };
  const SCENES = [
    ['아침', '출근 전 (첫 할 일 전)', { time: '08:30', idle: 20, tied: false }, 'firstOfDay'],
    ['아침', '첫 할 일 끝냄', { time: '08:40', idle: 1, tie: true, tied: false }, 'tie'],
    ['아침', '타이핑', { time: '09:30', idle: 1, tied: true }, 'typing'],
    ['아침', '쉬는 중', { time: '09:30', idle: 20, tied: true }, 'morning'],
    ['낮', '타이핑', { time: '14:00', idle: 1 }, 'typing'],
    ['낮', '잠깐 멈춤 (흠?)', { time: '14:00', idle: 90 }, 'nudge'],
    ['낮', '오래 멈춤 (엎드림)', { time: '14:00', idle: 300 }, 'idle'],
    ['낮', '자리 비움 40분', { time: '14:00', idle: 2400 }, null],
    ['낮', '돌아옴', { time: '14:00', idle: 1 }, 'back'],
    ['낮', '할 일 창 열기', { time: '14:00', idle: 1, panel: true }, 'memo'],
    ['낮', '할 일 체크', { time: '14:00', idle: 1, cheer: true }, 'praise'],
    ['낮', '오늘 거 전부 끝', { time: '14:00', idle: 1, cheer: true }, 'praiseAll'],
    ['낮', '5분 집중 시작', { time: '14:00', idle: 1 }, 'focusStart'],
    ['낮', '내일로 미룸', { time: '14:00', idle: 1, panel: true }, 'migrate'],
    ['식사', '점심', { time: '12:35', idle: 1 }, 'lunch'],
    ['식사', '간식', { time: '15:35', idle: 20 }, 'snack'],
    ['식사', '저녁', { time: '18:35', idle: 1 }, 'dinner'],
    ['모드', '공부 모드', { time: '16:00', idle: 20, study: true }, 'study'],
    ['음악', '음악 + 타이핑', { time: '14:00', idle: 1, music: true }, 'music'],
    ['음악', '음악 + 메모', { time: '14:00', idle: 1, music: true, panel: true }, 'musicTitle'],
    ['음악', '음악 + 흠?', { time: '14:00', idle: 90, music: true }, 'music'],
    ['음악', '음악 + 할 일 체크', { time: '14:00', idle: 1, music: true, cheer: true }, 'praise'],
    ['저녁·밤', '저녁', { time: '19:00', idle: 20 }, 'evening'],
    ['저녁·밤', '밤 · 아직 작업 중', { time: '23:30', idle: 60 }, 'evening'],
    ['저녁·밤', '밤 · 자리 비움 (잠)', { time: '23:30', idle: 1200 }, 'night'],
    ['저녁·밤', '마무리', { time: '22:35', idle: 1 }, 'wrapUp'],
    ['저녁·밤', '0개로 마무리', { time: '22:35', idle: 1 }, 'wrapUpZero'],
    ['컴퓨터', '렌더 대기', { time: '14:00', idle: 120, rendering: true }, 'renderWait'],
    ['컴퓨터', '렌더 대기 + 음악', { time: '14:00', idle: 120, rendering: true, music: true }, 'renderStart'],
    ['컴퓨터', '렌더 완료', { time: '14:00', idle: 1, done: true }, 'renderDone'],
    ['컴퓨터', '렌더 완료 + 음악', { time: '14:00', idle: 1, done: true, music: true }, 'renderDone'],
    ['컴퓨터', 'CPU 과부하', { time: '14:00', idle: 1, strain: 'cpu' }, 'strainCpu'],
    ['컴퓨터', 'RAM 과부하 + 음악', { time: '14:00', idle: 1, strain: 'ram', music: true }, 'strainRam'],
    ['알림', '노트북 배터리 부족', { time: '14:00', idle: 1 }, 'batteryLow'],
    ['알림', '배터리 거의 없음', { time: '14:00', idle: 1 }, 'batteryVeryLow'],
    ['알림', '충전 완료', { time: '14:00', idle: 1 }, 'batteryFull'],
    ['알림', '블루투스 배터리', { time: '14:00', idle: 1 }, 'btLow'],
    ['알림', '콕 찌르기', { time: '14:00', idle: 1 }, 'poke']
  ];
  function playScene(i) {
    const [, label, sim, kind] = SCENES[i];
    ui.sim = Object.assign({ panel: false }, sim);       // the test list lives in the open panel; don't let that force the memo pose
    ui.testIndex = i;
    ui.testLabel = label;
    ui.react = null;
    ui.img = null;
    document.querySelectorAll('#testScenes button').forEach((b, j) => b.classList.toggle('on', j === i));
    render();
    if (kind) say(say_(kind, TV), [], { keep: 60000 });
    else hideBubble();
  }
  function buildTestView() {
    const box = $('testScenes'); box.innerHTML = '';
    let group = '';
    SCENES.forEach(([g, label], i) => {
      if (g !== group) { group = g; const h = document.createElement('div'); h.className = 'tgroup'; h.textContent = g; box.appendChild(h); }
      const b = document.createElement('button');
      b.type = 'button'; b.textContent = label;
      b.addEventListener('click', () => { stopAuto(); playScene(i); });
      box.appendChild(b);
    });
    const gal = $('testGallery'); gal.innerHTML = '';
    (window.ASSETS[CH.id] || []).forEach(n => {
      const b = document.createElement('button');
      b.type = 'button'; b.title = n;
      const im = document.createElement('img'); im.src = A(n); im.alt = n; im.loading = 'lazy';
      const cap = document.createElement('span'); cap.textContent = n;
      b.append(im, cap);
      b.addEventListener('click', () => { stopAuto(); ui.sim = { asset: n }; ui.testLabel = ''; ui.img = null; hideBubble(); render(); });
      gal.appendChild(b);
    });
    const sel = $('testLineKind'); sel.innerHTML = '';
    Object.keys(bankOf(CH)).forEach(k => { const o = document.createElement('option'); o.value = o.textContent = k; sel.appendChild(o); });
    const chars = $('testChars'); chars.innerHTML = '';
    Object.values(CHARS).forEach(c => {
      const b = document.createElement('button');
      b.type = 'button'; b.textContent = charName(c); b.className = c.id === CH.id ? 'on' : '';
      b.addEventListener('click', () => switchCharacter(c.id));
      chars.appendChild(b);
    });
  }
  function startTest() {
    if (!ui.panelOpen) openPanel();
    showView('test');
    buildTestView();
    playScene(ui.testIndex || 0);
  }
  function stopAuto() { clearInterval(ui.autoTimer); ui.autoTimer = null; $('testAuto').textContent = '▶ ' + T('자동으로 넘기기'); }
  function endTest() {
    stopAuto();
    ui.sim = null; ui.img = null;
    $('testGallery').innerHTML = '';                 // let go of every drawing the test loaded
    if (api.clearCache) setTimeout(() => api.clearCache(), 500);
    hideBubble(); render();
  }
  $('testAuto').addEventListener('click', () => {
    if (ui.autoTimer) return stopAuto();
    $('testAuto').textContent = '■ ' + T('멈추기');
    playScene(((ui.testIndex || 0) + 1) % SCENES.length);
    ui.autoTimer = setInterval(() => playScene((ui.testIndex + 1) % SCENES.length), 3500);
  });
  $('testLineBtn').addEventListener('click', () => say(say_($('testLineKind').value, TV), [], { keep: 60000 }));
  $('testExit').addEventListener('click', () => showView('today'));
  $('openTest').addEventListener('click', startTest);

  // ---------- settings ----------
  // sizes and transparency (sliders). Older versions stored small/medium/large; those carry over.
  function sizeOf(st) {
    const OLD_CHAR = { s: 170, m: 220, l: 260 }, OLD_TEXT = { s: 13, m: 15, l: 17 }, OLD_UI = { s: 92, m: 100, l: 108 };
    return {
      charPx: st.charPx || OLD_CHAR[st.charSize] || 220,
      textPx: st.textPx || OLD_TEXT[st.textSize] || 15,
      uiPct: st.uiPct || OLD_UI[st.textSize] || 100,
      opacity: st.opacity || 100,
      panelW: st.panelW || 380,
      panelH: st.panelH || 470
    };
  }
  function applySizes() {
    const z = sizeOf(data.settings), r = document.documentElement.style;
    setTimeout(fitPanel, 0);
    r.setProperty('--buddy-h', z.charPx + 'px');
    r.setProperty('--bubble-fs', z.textPx + 'px');
    r.setProperty('--ui-zoom', z.uiPct / 100);
    r.setProperty('--char-op', z.opacity / 100);
    r.setProperty('--panel-w', Math.min(408, z.panelW) + 'px');
    setTimeout(() => { positionWidget(); positionBubble(); }, 30);
  }
  const SLIDERS = { setCharPx: ['charPx', 'charPxVal', v => v + 'px'], setTextPx: ['textPx', 'textPxVal', v => v + 'px'],
                    setUiPct: ['uiPct', 'uiPctVal', v => v + '%'], setOpacity: ['opacity', 'opVal', v => v + '%'],
                    setPanelW: ['panelW', 'panelWVal', v => v + 'px'], setPanelH: ['panelH', 'panelHVal', v => v + 'px'] };
  function fillSliders() {
    const z = sizeOf(data.settings);
    Object.entries(SLIDERS).forEach(([id, [key, label, fmt]]) => {
      const el = $(id);
      const show = () => { $(label).textContent = fmt(el.value); };
      el.value = z[key]; show();
      el.addEventListener('input', () => { data.settings[key] = Number(el.value); show(); applySizes(); });
      el.addEventListener('change', () => { persist(); if (key === 'charPx') api.settingsChanged('size'); });
    });
  }

  // what she calls you: "야, …" / "저기, …" / "수환아, …"
  function callMe() {
    const c = data.settings.callMe;
    if (!c) return '';
    const CALL = { 야: { en: 'Hey', ja: 'ねえ' }, 저기: { en: 'Psst', ja: 'ちょっと' }, 이봐: { en: 'Yo', ja: 'おい' } };
    if (c !== 'custom') return LANG === 'ko' ? c : ((CALL[c] || {})[LANG] || c);
    const n = (data.settings.callMeName || '').trim();
    if (!n) return '';
    const last = n.charCodeAt(n.length - 1);
    if (LANG === 'ko' && last >= 0xAC00 && last <= 0xD7A3) return n + ((last - 0xAC00) % 28 ? '아' : '야');   // 받침 있으면 아, 없으면 야
    return n;
  }
  const CALL_KINDS = new Set(['firstOfDay', 'back', 'nudge', 'nudgeEmpty', 'lunch', 'dinner', 'snack', 'wrapUp', 'wrapUpZero',
    'praiseAll', 'poke', 'batteryVeryLow', 'night', 'focusDone']);
  function withCall(kind, text) {
    const c = callMe();
    if (!c || !text || !CALL_KINDS.has(kind)) return text;
    const comma = LANG === 'ja' ? '、' : ', ';
    return text.startsWith('…') ? `${c}… ${text.slice(1).trimStart()}` : `${c}${comma}${text}`;
  }
  function fillCallMe() {
    const sel = $('setCallMe'), name = $('setCallMeName');
    const sync = () => { $('callMeNameRow').hidden = sel.value !== 'custom'; };
    sel.value = data.settings.callMe || ''; name.value = data.settings.callMeName || ''; sync();
    sel.addEventListener('change', () => { data.settings.callMe = sel.value; sync(); persist(); if (sel.value === 'custom') name.focus(); });
    name.addEventListener('change', () => { data.settings.callMeName = name.value.trim(); persist(); });
  }
  const SETTING_FIELDS = { setLang: 'lang', setWidgetPos: 'widgetPos', setBubblePos: 'bubblePos', setName: 'name', setChatter: 'chatter', setVariety: 'variety', setLunch: 'lunch', setSnack: 'snack', setDinner: 'dinner', setWrap: 'wrapUp', setWorkStart: 'workStart', setWorkEnd: 'workEnd', setDayStart: 'dayStart', setCity: 'city' };
  const TOGGLES = { setOnTop: ['alwaysOnTop', 'window'], setWeather: ['weather', 'weather'], setBt: ['btBattery', 'bt'], setMusic: ['autoMusic', 'music'], setSys: ['sysInfo', 'sys'] };
  function fillSettings() {
    Object.entries(SETTING_FIELDS).forEach(([id, k]) => {
      const el = $(id);
      const DEF = { charSize: 'm', textSize: 'm', bubblePos: 'auto', widgetPos: 'feet', lang: 'ko', variety: 'normal', dinner: '18:30', dayStart: '04:00' };
      el.value = k === 'name' ? (data.settings.names[CH.id] || '') : (data.settings[k] || DEF[k] || '');
      if (k === 'name') el.placeholder = charName(CH);
      el.addEventListener('change', () => {
        if (k === 'name') {
          data.settings.names = data.settings.names || {};
          data.settings.names[CH.id] = el.value.trim();
          data.settings.name = displayName();
        } else data.settings[k] = el.value;
        if (k === 'lang') applyLang();
        persist(); api.settingsChanged(k === 'city' ? 'weather' : k === 'charSize' ? 'size' : 'basic');
        if (k === 'bubblePos' || k === 'charSize' || k === 'textSize' || k === 'widgetPos') setTimeout(() => { positionWidget(); positionBubble(); }, 50); render(); if (k === 'name') renderProfile();
      });
    });
  }
  function fillToggles() {
    Object.entries(TOGGLES).forEach(([id, [k, what]]) => {
      const el = $(id);
      el.checked = data.settings[k] !== false;
      el.addEventListener('change', () => {
        data.settings[k] = el.checked; persist(); api.settingsChanged(what);
        if (k === 'weather' && !el.checked) { ui.weather = null; renderStatus(); }
        if (k === 'btBattery' && !el.checked) { ui.bt = []; renderStatus(); }
      });
    });
    $('setLogin').addEventListener('change', () => { if (api.setLogin) api.setLogin($('setLogin').checked); });
  }

  // ---------- routines (editable) ----------
  function myRoutines() {
    if (!data.settings.routines) data.settings.routines = L.DEFAULT_ROUTINES.map(r => ({ ...r, days: r.days.slice() }));
    return data.settings.routines;
  }
  function renderRoutineEditor() {
    const list = $('routineEditor'); list.innerHTML = '';
    myRoutines().forEach(r => {
      const li = document.createElement('li');
      const name = document.createElement('input');
      name.className = 'rname'; name.value = r.label; name.setAttribute('aria-label', T('루틴 이름'));
      name.addEventListener('change', () => { if (name.value.trim()) { r.label = name.value.trim(); persist(); renderPanel(); } else name.value = r.label; });
      li.appendChild(name);
      const days = document.createElement('span'); days.className = 'days';
      [1, 2, 3, 4, 5, 6, 0].forEach(d => {
        const b = document.createElement('button');
        b.type = 'button'; b.textContent = L.WEEK[d];
        b.setAttribute('aria-pressed', String(r.days.includes(d)));
        b.setAttribute('aria-label', `${r.label} ${L.WEEK[d]}`);
        b.addEventListener('click', () => {
          r.days = r.days.includes(d) ? r.days.filter(x => x !== d) : r.days.concat(d).sort();
          persist(); renderRoutineEditor(); renderPanel();
        });
        days.appendChild(b);
      });
      li.appendChild(days);
      const del = document.createElement('button');
      del.type = 'button'; del.className = 'del'; del.textContent = '✕'; del.setAttribute('aria-label', `${r.label} ${T('지우기')}`);
      del.addEventListener('click', () => { data.settings.routines = myRoutines().filter(x => x !== r); persist(); renderRoutineEditor(); renderPanel(); });
      li.appendChild(del);
      list.appendChild(li);
    });
  }
  $('routineAdd').addEventListener('submit', (e) => {
    e.preventDefault();
    const v = $('routineInput').value.trim();
    if (!v) return;
    myRoutines().push(L.newRoutine(v));
    $('routineInput').value = '';
    persist(); renderRoutineEditor(); renderPanel();
  });

  // ---------- weather ----------
  function weatherSentence() {
    const w = ui.weather;
    if (!w || w.error) return '';
    const sky = T(L.weatherText(w.todayCode != null ? w.todayCode : w.code));
    let s = T('오늘 {city} {sky}, {min}~{max}도.', { city: T(w.city), sky, min: w.min, max: w.max });
    if (L.umbrella(w)) s += ' ' + T('우산 챙겨.');
    else if (w.max >= 28) s += ' ' + T('덥겠다. 물 많이 마셔.');
    else if (w.min <= 3) s += ' ' + T('춥대. 따뜻하게 입어.');
    return s;
  }
  function onWeather(w) {
    ui.weather = w && !w.error ? w : null;
    renderStatus();
    const day = today();
    const now = new Date();
    if (ui.weather && day.fired.first && !day.fired.weather && now.getHours() >= 6 && now.getHours() < 21) {
      day.fired.weather = true; persist();
      if ($('bubble').hidden) say(weatherSentence());
    }
  }

  // ---------- battery ----------
  function watchBattery() {
    if (!navigator.getBattery) return;
    navigator.getBattery().then(b => {
      const update = () => { ui.battery = { level: Math.round(b.level * 100), charging: b.charging }; renderStatus(); checkBattery(); };
      ['levelchange', 'chargingchange'].forEach(ev => b.addEventListener(ev, update));
      update();
    }).catch(() => {});
  }
  function warnOnce(id, minutes, text) {
    const t = Date.now();
    if (ui.warned[id] && t - ui.warned[id] < minutes * MIN) return;
    ui.warned[id] = t;
    say(text);
  }
  function checkBattery() {
    const b = ui.battery;
    if (!b) return;
    if (!b.charging && b.level <= 10) warnOnce('pc10', 30, say_('batteryVeryLow', { level: b.level }));
    else if (!b.charging && b.level <= 20) warnOnce('pc20', 60, say_('batteryLow', { level: b.level }));
    if (b.charging && b.level >= 100) warnOnce('pcFull', 180, say_('batteryFull'));
    if (b.charging) { delete ui.warned.pc10; delete ui.warned.pc20; }
  }
  function onBluetooth(list) {
    ui.bt = Array.isArray(list) ? list : [];
    const known = new Set(data.settings.btKnown || []);
    const before = known.size;
    ui.bt.forEach(d => known.add(d.name));
    if (known.size !== before) { data.settings.btKnown = [...known]; persist(); }
    fillBtPick();
    renderStatus();
    shownBt().filter(d => d.level <= 20).forEach(d => warnOnce('bt:' + d.name, 120, say_('btLow', { name: d.name, level: d.level })));
  }
  // ---------- system load ----------
  function onSys(sx) {
    if (!sx) { ui.sys = null; ui.samples = []; ui.rendering = false; ui.strain = null; renderStatus(); render(); return; }
    ui.sys = sx;
    const t = sx.t || Date.now();
    ui.samples.push({ t, cpu: sx.cpu, ram: sx.ram, gpu: sx.gpu, dgpu: sx.dgpu });
    ui.samples = ui.samples.filter(x => t - x.t <= 3 * MIN);
    const st = L.sysState(ui.samples, t, ui.idle, ui.rendering);
    if (st.render && !ui.rendering) {
      ui.rendering = true;
      warnOnce('render', 10, say_('renderStart'));
    } else if (ui.rendering && st.done) {
      ui.rendering = false;
      ui.doneUntil = Date.now() + 15000;
      ui.hopUntil = Date.now() + 800;
      say(say_('renderDone'));
    }
    if (st.strain && st.strain !== ui.strain) warnOnce('strain:' + st.strain, 30, say_(st.strain === 'cpu' ? 'strainCpu' : 'strainRam'));
    ui.strain = st.strain;
    // the card only needs rebuilding if it shows load numbers (or the render/strain state changed)
    const sh = data.settings.show || [], key = `${ui.rendering}|${ui.strain}`;
    if (sh.includes('hw') || sh.includes('self') || key !== ui.sysKey || ui.panelOpen) { ui.sysKey = key; renderStatus(); }
    render();
  }

  // the panel's chips: only what the info card isn't already showing; hardware stays on the card (room for the tasks)
  function renderStatus() {
    renderWidget();
    const box = $('status'); box.innerHTML = '';
    const show = data.settings.show || [];
    const chip = (text, low, title) => { const c = document.createElement('span'); c.className = 'chip' + (low ? ' low' : ''); c.textContent = text; if (title) c.title = title; box.appendChild(c); };
    const w = ui.weather;
    if (w && !show.includes('weather')) chip(`${T(L.weatherText(w.code))} ${w.temp}° · ${w.min}~${w.max}°${L.umbrella(w) ? ' · ' + T('우산') : ''}`, false, T('{city} 날씨', { city: T(w.city) }));
    if (!show.includes('battery')) {
      const b = ui.battery;
      if (b && !b.charging && b.level <= 20) chip(`${T('노트북')} ${b.level}%`, true);
      shownBt().filter(d => d.level <= 20).forEach(d => chip(`${d.name} ${d.level}%`, true, T('블루투스')));
    }
    box.hidden = !box.children.length;
  }


  // ---------- tray commands ----------
  // ---------- updates ----------
  function onUpdate(u) {
    const SAY = { kind: 'update' };
    if (u.state === 'available') {
      const note = u.notes && (u.notes[LANG] || u.notes.ko);
      say(T('새 버전 v{v}이 나왔어. 지금 업데이트할까?', { v: u.version }) + (note ? '\n' + note : ''), [
        { label: T('업데이트'), primary: true, run: () => api.applyUpdate() },
        { label: T('나중에'), run: () => {} }
      ], Object.assign({ sticky: true }, SAY));
    } else if (u.state === 'latest') say(T('지금이 최신 버전이야. (v{v})', { v: u.version }), [], SAY);
    else if (u.state === 'downloading') say(T('새 버전 내려받는 중… 잠깐만.'), [], Object.assign({ keep: 60000 }, SAY));
    else if (u.state === 'restarting') say(T('다 받았어. 다시 켜질게!'), [], Object.assign({ keep: 60000 }, SAY));
    else if (u.state === 'unset') say(T('아직 업데이트 주소가 정해지지 않았어.'), [], SAY);
    else if (u.missing) say(T('업데이트 사이트에 아직 버전 파일이 없어. (Netlify 배포를 확인해 줘)'), [], SAY);
    else say(T('업데이트를 확인하지 못했어. 인터넷 연결을 봐 줘.') + (u.message ? `\n(${u.message})` : ''), [], SAY);
  }
  function fillUpdate() {
    if (api.getVersion) api.getVersion().then(v => { $('verLabel').textContent = T('지금 버전 v{v}', { v }); });
    $('checkUpdate').addEventListener('click', () => { if (api.checkUpdate) api.checkUpdate(); else onUpdate({ state: 'unset' }); });
    if (api.onUpdate) api.onUpdate(onUpdate);
  }

  // ---------- shortcut to call her up ----------
  function hotkeyLabel(acc) { return acc ? acc.replace('Control', 'Ctrl').split('+').join(' + ') : T('꺼짐'); }
  function fillHotkey() {
    const box = $('setHotkey'); if (!box) return;
    const cur = () => (data.settings.hotkey === undefined ? 'Control+Alt+D' : data.settings.hotkey);
    box.value = hotkeyLabel(cur());
    const note = (s, bad) => { $('hotkeyNote').textContent = s; $('hotkeyNote').classList.toggle('warn', !!bad); };
    async function set(acc) {
      if (!api.setHotkey) { data.settings.hotkey = acc; persist(); box.value = hotkeyLabel(acc); return; }
      const ok = await api.setHotkey(acc);
      if (!ok && acc) { note(T('{k}는 다른 프로그램이 쓰고 있어요. 다른 조합으로 해 주세요.', { k: hotkeyLabel(acc) }), true); box.value = hotkeyLabel(cur()); return; }
      data.settings.hotkey = acc; persist(); box.value = hotkeyLabel(acc);
      note(acc ? T('{k} 누르면 언제든 불러올 수 있어요.', { k: hotkeyLabel(acc) }) : T('단축키를 껐어요.'));
    }
    box.addEventListener('focus', () => { box.value = ''; box.placeholder = T('원하는 조합을 눌러요 (예: Ctrl + Alt + D)'); });
    box.addEventListener('blur', () => { box.value = hotkeyLabel(cur()); });
    box.addEventListener('keydown', (e) => {
      e.preventDefault();
      if (e.key === 'Escape') { box.blur(); return; }
      if (['Control', 'Alt', 'Shift', 'Meta'].includes(e.key)) return;
      const mods = [e.ctrlKey && 'Control', e.altKey && 'Alt', e.shiftKey && 'Shift', e.metaKey && 'Super'].filter(Boolean);
      if (!mods.length || (mods.length === 1 && mods[0] === 'Shift')) { note(T('Ctrl이나 Alt를 같이 눌러 주세요.'), true); return; }
      let k = e.code.startsWith('Key') ? e.code.slice(3) : e.code.startsWith('Digit') ? e.code.slice(5) : /^F\d+$/.test(e.key) ? e.key : e.code === 'Space' ? 'Space' : null;
      if (!k) { note(T('글자, 숫자, F키, 스페이스 중 하나와 같이 눌러 주세요.'), true); return; }
      set(mods.concat(k).join('+')); box.blur();
    });
    $('hotkeyOff').addEventListener('click', () => set(''));
  }

  // ---------- phone sync ----------
  let syncer = null;
  const MOBILE_URL = 'https://streetlamp1216.github.io/desk-buddy-updates/app/';
  function syncServer() { return (data.settings.syncServer || window.Sync.DEFAULT_SERVER || '').trim(); }
  function fillSync() {
    if (!window.Sync) return;
    syncer = window.Sync.create({
      server: syncServer,
      getData: () => data,
      changed: afterRemote,
      loadState: () => data.sync || null,
      saveState: (st) => { data.sync = st; persistLocal(); },
      onStatus: renderSync
    });
    $('syncServer').value = data.settings.syncServer || '';
    $('syncServer').placeholder = window.Sync.DEFAULT_SERVER || 'https://….workers.dev';
    $('syncServer').addEventListener('change', () => { data.settings.syncServer = $('syncServer').value.trim(); persistLocal(); renderSync(); syncer.now(); });
    $('syncStart').addEventListener('click', () => {
      if (!syncServer()) { renderSync(T('서버 주소가 아직 없어요')); $('syncServer').closest('details').open = true; return; }
      syncer.start();
    });
    $('syncJoin').addEventListener('submit', (e) => {
      e.preventDefault();
      if (!syncServer()) { renderSync(T('서버 주소가 아직 없어요')); $('syncServer').closest('details').open = true; return; }
      if (!syncer.join($('syncJoinInput').value)) { renderSync(T('코드가 16자리가 아니에요')); return; }
      $('syncJoinInput').value = '';
    });
    $('syncNow').addEventListener('click', () => { renderSync(T('동기화 중…')); syncer.now(); });
    $('syncCopy').addEventListener('click', () => api.copyText((data.sync || {}).code || ''));
    $('syncStop').addEventListener('click', () => { if (confirm(T('연동을 끊을까요? 이 기기의 데이터는 그대로 남아요.'))) syncer.stop(); });
    renderSync();
    syncer.now();
    setInterval(() => syncer.now(), 30000);
  }
  function renderSync(note) {
    const st = data.sync || {}, on = !!st.code;
    $('syncOff').hidden = on; $('syncOn').hidden = !on;
    if (on) {
      $('syncCode').textContent = st.code;
      if ($('syncQr').dataset.code !== st.code && window.qrcode) {
        const q = window.qrcode(0, 'M'); q.addData(MOBILE_URL + '#join=' + st.code.replace(/-/g, '')); q.make();
        $('syncQr').innerHTML = q.createSvgTag({ cellSize: 3, margin: 2, scalable: true });
        $('syncQr').dataset.code = st.code;
      }
    }
    const pad = (n) => String(n).padStart(2, '0');
    const last = st.last ? new Date(st.last) : null;
    const msg = typeof note === 'string' ? note
      : st.error ? T('동기화 실패: {e}', { e: st.error })
      : last ? T('마지막 동기화 {t}', { t: `${last.getMonth() + 1}/${last.getDate()} ${pad(last.getHours())}:${pad(last.getMinutes())}` }) : '';
    $('syncStatus').textContent = msg;
    $('syncStatusOff').textContent = !on && typeof note === 'string' ? note : '';
  }
  // changes came in from the phone: redraw whatever shows them (but don't yank a memo out from under the cursor)
  function afterRemote() {
    persistLocal();
    ui.key = DK(new Date()); L.ensureDay(data, ui.key);
    const lang = ['ko', 'en', 'ja'].includes(data.settings.lang) ? data.settings.lang : 'ko';
    if (lang !== LANG) applyLang();
    if (data.settings.character && data.settings.character !== CH.id && CHARS[data.settings.character]) { const id = data.settings.character; data.settings.character = CH.id; switchCharacter(id); }
    renderPanel(); renderWidget();
    const editing = document.activeElement && document.activeElement.closest && document.activeElement.closest('#notesView, #calView, #routineEditor, #alarmList');
    if (!editing) {
      if (!$('notesView').hidden) renderNotes();
      if (!$('calView').hidden) renderCal();
      if (!$('settings').hidden) renderRoutineEditor();
      if (!$('timerView').hidden) renderAlarms();
    }
  }

  function onCommand(cmd) {
    if (cmd === 'toggle-panel') togglePanel();
    else if (cmd === 'open-panel') openPanel();
    else if (cmd === 'hotkey' || cmd === 'hotkey-close') {
      if (cmd === 'hotkey-close' && ui.panelOpen) { closePanel(); return; }
      if (!ui.panelOpen) openPanel();
      if (!ui.sim) showView('today');
      setTimeout(() => $('addInput').focus(), 60);
    }
    else if (cmd === 'sync-now') { if (syncer && (data.sync || {}).code) syncer.now().then(() => { const st = data.sync || {}; say(st.error ? T('동기화 실패: {e}', { e: st.error }) : T('폰이랑 맞췄어.')); }); else say(T('아직 폰 연동이 꺼져 있어. 설정 › 폰 연동에서 켤 수 있어.')); }
    else if (cmd === 'nudge') nudge();
    else if (cmd === 'profile') openProfile();
    else if (cmd === 'test') startTest();
    else if (cmd === 'study-on' || cmd === 'study-off') { ui.study = cmd === 'study-on'; persist(); render(); if (ui.study) say(say_('study')); }
    else if (cmd === 'music-on' || cmd === 'music-off') { ui.musicManual = cmd === 'music-on'; persist(); updateMusic(); }
    else if (cmd.startsWith('set:')) {                     // a settings switch flipped from the tray menu
      const [, key, val] = cmd.split(':');
      setSetting(key, val === 'true');
    }
  }
  const SWITCH_WHAT = { still: 'basic', autoMusic: 'music', alwaysOnTop: 'window' };
  function applyLang() {
    LANG = ['ko', 'en', 'ja'].includes(data.settings.lang) ? data.settings.lang : 'ko';
    document.documentElement.lang = LANG;
    window.I18N.translateDom(document.body, LANG);
    L.setWeek(window.I18N.week(LANG));
    data.settings.name = displayName();
    const nm = $('setName'); if (nm) nm.placeholder = charName(CH);
    renderPanel(); renderProfile(); renderCharPick(); renderStatus(); renderWidget();
    if (!$('testView').hidden) buildTestView();
    showView($('settings').hidden ? ($('testView').hidden ? 'today' : 'test') : 'settings');
  }
  function setSetting(key, on) {
    data.settings[key] = on;
    persist(); api.settingsChanged(SWITCH_WHAT[key] || 'basic');
    const box = document.querySelector(`[data-setting="${key}"]`); if (box) box.checked = on;
    if (key === 'still') applyStill();
  }
  // "hold still": no bobbing, breathing, blinking or hand-swapping; she still changes pose with the situation
  function applyStill() {
    document.body.classList.toggle('still', !!data.settings.still);
    ui.img = null; ui.anim = null; render();
  }

  // ---------- alarms: a plain digital-watch beep ----------
  let audio = null, beeping = null;
  function beepPattern(times) {
    try {
      audio = audio || new (window.AudioContext || window.webkitAudioContext)();
      if (audio.state === 'suspended') audio.resume();
      const t0 = audio.currentTime + 0.02;
      for (let k = 0; k < 4; k++) {                       // 뚜뚜뚜뚜
        const o = audio.createOscillator(), g = audio.createGain();
        o.type = 'square'; o.frequency.value = 2730;
        const s = t0 + k * 0.15;
        g.gain.setValueAtTime(0, s); g.gain.linearRampToValueAtTime(0.06, s + 0.005);
        g.gain.setValueAtTime(0.06, s + 0.075); g.gain.linearRampToValueAtTime(0, s + 0.085);
        o.connect(g).connect(audio.destination); o.start(s); o.stop(s + 0.09);
      }
    } catch (e) { /* no sound device: the bubble still shows */ }
  }
  // ring until stopped (or for a minute), one 뚜뚜뚜뚜 a second
  function ring(seconds) {
    stopRing();
    let n = 0; beepPattern();
    beeping = setInterval(() => { if (++n >= (seconds || 60)) stopRing(); else beepPattern(); }, 1000);
  }
  function stopRing() { clearInterval(beeping); beeping = null; }
  function alarms() { return data.settings.alarms || (data.settings.alarms = []); }
  function checkAlarms(now) {
    const hm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const stamp = L.dateKey(now) + ' ' + hm;
    alarms().forEach(a => {
      if (!a.on || a.time !== hm || a.last === stamp) return;
      a.last = stamp;
      if (!a.repeat) a.on = false;
      persist(); renderAlarms();
      ring(60);
      lastKind = 'focusDone';
      say('⏰ ' + (a.label || T('알람')) + ` · ${hm}`, [
        { label: T('끄기'), primary: true, run: stopRing },
        { label: T('5분 뒤'), run: () => { stopRing(); const t = new Date(Date.now() + 5 * MIN); alarms().push({ id: 'a' + Date.now().toString(36), time: `${String(t.getHours()).padStart(2, '0')}:${String(t.getMinutes()).padStart(2, '0')}`, label: a.label, on: true, repeat: false, snooze: true }); persist(); renderAlarms(); } }
      ], { sticky: true, prio: 3 });
    });
    // snoozes that already rang are cleaned up
    const before = alarms().length;
    data.settings.alarms = alarms().filter(a => !(a.snooze && !a.on));
    if (data.settings.alarms.length !== before) { persist(); renderAlarms(); }
  }
  function renderAlarms() {
    const box = $('alarmList'); if (!box) return;
    box.innerHTML = '';
    if (!alarms().length) { const p = document.createElement('p'); p.className = 'sub'; p.textContent = T('알람이 없어요.'); box.appendChild(p); }
    alarms().slice().sort((a, b) => a.time.localeCompare(b.time)).forEach(a => {
      const row = document.createElement('div'); row.className = 'alarm' + (a.on ? '' : ' off');
      const tm = document.createElement('input'); tm.type = 'time'; tm.value = a.time; tm.setAttribute('aria-label', T('시각'));
      tm.addEventListener('change', () => { if (tm.value) { a.time = tm.value; a.on = true; a.last = ''; persist(); renderAlarms(); } });
      const lb = document.createElement('input'); lb.type = 'text'; lb.value = a.label || ''; lb.placeholder = T('이름 (선택)'); lb.maxLength = 30;
      lb.addEventListener('change', () => { a.label = lb.value.trim(); persist(); });
      const rp = document.createElement('label'); rp.className = 'rep';
      const rc = document.createElement('input'); rc.type = 'checkbox'; rc.checked = !!a.repeat;
      rc.addEventListener('change', () => { a.repeat = rc.checked; persist(); });
      rp.append(rc, document.createTextNode(T('매일')));
      const sw = document.createElement('button'); sw.type = 'button'; sw.className = 'sw' + (a.on ? ' on' : ''); sw.setAttribute('aria-pressed', String(!!a.on)); sw.title = a.on ? T('켜짐') : T('꺼짐');
      sw.addEventListener('click', () => { a.on = !a.on; a.last = ''; persist(); renderAlarms(); });
      const del = document.createElement('button'); del.type = 'button'; del.className = 'del'; del.textContent = '✕'; del.title = T('지우기');
      del.addEventListener('click', () => { data.settings.alarms = alarms().filter(x => x !== a); persist(); renderAlarms(); });
      row.append(tm, lb, rp, sw, del); box.appendChild(row);
    });
  }
  $('alarmAdd').addEventListener('click', () => {
    const t = new Date(Date.now() + 60 * MIN);
    alarms().push({ id: 'a' + Date.now().toString(36), time: `${String(t.getHours()).padStart(2, '0')}:00`, label: '', on: true, repeat: false });
    persist(); renderAlarms();
  });

  // ---------- timer view: a pomodoro-style dial (one turn = 60 minutes) or a typed number ----------
  const TIMER = { min: 25 };
  function openTimer() {
    const sel = $('timerTask'); const keep = sel.value;
    sel.innerHTML = '';
    const none = document.createElement('option'); none.value = ''; none.textContent = T('(없음)'); sel.appendChild(none);
    L.ordered(today().tasks, today().customOrder).filter(L.isOpen).forEach(t => {
      const o = document.createElement('option'); o.value = t.id; o.textContent = (t.u ? 'u ' : '') + t.text; sel.appendChild(o);
    });
    sel.value = keep;
    if (data.settings.timerRecent && data.settings.timerRecent.length && !ui.focusing) TIMER.min = data.settings.timerRecent[0];
    drawTimer(); renderAlarms();
  }
  function setTimerMin(m) { TIMER.min = Math.max(1, Math.min(600, Math.round(m) || 1)); drawTimer(); }
  function drawTimer() {
    if ($('timerView').hidden) return;
    const running = ui.focusing && ui.focusing.timer;
    let minutesShown, label;
    if (running) {
      const left = Math.max(0, ui.focusing.until - Date.now());
      minutesShown = left / 60000;
      label = `${Math.floor(left / 60000)}:${String(Math.floor(left / 1000) % 60).padStart(2, '0')}`;
    } else { minutesShown = TIMER.min; label = `${TIMER.min}:00`; }
    const frac = Math.min(1, minutesShown / 60);
    const a = frac * 2 * Math.PI, R = 80;
    const x = 100 + R * Math.sin(a), y = 100 - R * Math.cos(a);
    $('dialWedge').setAttribute('d', frac >= 0.9999 ? `M100,20 A80,80 0 1,1 99.99,20 Z` : frac <= 0 ? '' : `M100,100 L100,20 A80,80 0 ${frac > .5 ? 1 : 0},1 ${x.toFixed(2)},${y.toFixed(2)} Z`);
    $('dialHand').setAttribute('x2', (100 + 84 * Math.sin(a)).toFixed(2)); $('dialHand').setAttribute('y2', (100 - 84 * Math.cos(a)).toFixed(2));
    $('dialLabel').textContent = label + (!running && TIMER.min > 60 ? ` (${T('{n}바퀴+', { n: Math.floor(TIMER.min / 60) })})` : '');
    $('dial').setAttribute('aria-valuenow', String(TIMER.min));
    if (document.activeElement !== $('timerMin')) $('timerMin').value = TIMER.min;
    $('timerMin').disabled = !!running; $('timerTask').disabled = !!running;
    $('timerStart').hidden = !!running; $('timerStop').hidden = !running;
    $('dial').classList.toggle('running', !!running);
    const rb = $('timerRecent'); rb.innerHTML = '';
    (data.settings.timerRecent || []).forEach(m => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'chip'; b.textContent = T('{n}분', { n: m });
      b.disabled = !!running;
      b.addEventListener('click', () => setTimerMin(m));
      rb.appendChild(b);
    });
  }
  (function dialSetup() {
    const ticks = $('dialTicks');
    for (let i = 0; i < 60; i++) {
      const a = i / 60 * 2 * Math.PI, r1 = i % 5 ? 84 : 78;
      const l = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      l.setAttribute('x1', (100 + r1 * Math.sin(a)).toFixed(2)); l.setAttribute('y1', (100 - r1 * Math.cos(a)).toFixed(2));
      l.setAttribute('x2', (100 + 88 * Math.sin(a)).toFixed(2)); l.setAttribute('y2', (100 - 88 * Math.cos(a)).toFixed(2));
      l.setAttribute('class', i % 5 ? 'tick' : 'tick big'); ticks.appendChild(l);
    }
    const dial = $('dial');
    const fromPoint = (e) => {
      const r = dial.getBoundingClientRect();
      const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
      let a = Math.atan2(dx, -dy); if (a < 0) a += 2 * Math.PI;
      return Math.max(1, Math.round(a / (2 * Math.PI) * 60) || 60);
    };
    dial.addEventListener('pointerdown', (e) => {
      if (ui.focusing && ui.focusing.timer) return;
      dial.setPointerCapture(e.pointerId); ui.resizing = true;
      setTimerMin(fromPoint(e));
      const mv = (ev) => setTimerMin(fromPoint(ev));
      const up = () => { ui.resizing = false; dial.removeEventListener('pointermove', mv); dial.removeEventListener('pointerup', up); dial.removeEventListener('pointercancel', up); };
      dial.addEventListener('pointermove', mv); dial.addEventListener('pointerup', up); dial.addEventListener('pointercancel', up);
    });
    dial.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowUp' || e.key === 'ArrowRight') { setTimerMin(TIMER.min + 1); e.preventDefault(); }
      if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') { setTimerMin(TIMER.min - 1); e.preventDefault(); }
    });
    $('timerMin').addEventListener('input', () => { const v = +$('timerMin').value; if (v >= 1) { TIMER.min = Math.min(600, Math.round(v)); drawTimer(); } });
    $('timerStart').addEventListener('click', () => startTimer(TIMER.min, $('timerTask').value));
    $('timerStop').addEventListener('click', stopTimer);
  })();

  // ---------- panel: drag its free edges to resize it, like a window ----------
  document.querySelectorAll('#panel .rz').forEach(h => {
    h.addEventListener('pointerdown', (e) => {
      e.preventDefault(); e.stopPropagation();
      h.setPointerCapture(e.pointerId);
      const z = sizeOf(data.settings), mode = h.dataset.rz;
      const right = !document.body.classList.contains('lay-left'), bottom = !document.body.classList.contains('lay-top');
      const x0 = e.screenX, y0 = e.screenY, w0 = Math.min(408, z.panelW), h0 = $('panel').getBoundingClientRect().height;
      ui.resizing = true; document.body.classList.add('resizing');
      const move = (ev) => {
        const dx = ev.screenX - x0, dy = ev.screenY - y0;
        if (mode.includes('x')) {
          data.settings.panelW = Math.round(Math.max(260, Math.min(408, w0 + (right ? -dx : dx))));
          document.documentElement.style.setProperty('--panel-w', data.settings.panelW + 'px');
        }
        if (mode.includes('y')) {
          data.settings.panelH = Math.round(Math.max(200, Math.min(900, h0 + (bottom ? -dy : dy))));
          fitPanel();
        }
        Object.entries(SLIDERS).forEach(([id, [key, out, fmt]]) => {
          if (key !== 'panelW' && key !== 'panelH') return;
          const el = $(id); if (el) { el.value = data.settings[key]; if ($(out)) $(out).textContent = fmt(data.settings[key]); }
        });
        positionWidget(); positionBubble();
      };
      const up = () => {
        h.removeEventListener('pointermove', move); h.removeEventListener('pointerup', up); h.removeEventListener('pointercancel', up);
        ui.resizing = false; document.body.classList.remove('resizing');
        persist();
      };
      h.addEventListener('pointermove', move); h.addEventListener('pointerup', up); h.addEventListener('pointercancel', up);
    });
  });

  // ---------- mouse: clicks pass through everything except the character, bubble and panel ----------
  let overHit = null;
  document.addEventListener('mousemove', (e) => {
    if (drag || ui.resizing) return;
    const el = document.elementFromPoint(e.clientX, e.clientY);
    let hit = !!(el && el.closest('.hit'));
    // click-through: the character lets clicks fall to whatever is behind her, unless Ctrl is held
    if (hit && data && data.settings.clickThrough && !e.ctrlKey && el.closest('#buddy')) hit = false;
    // the music buttons on the info card only grab the mouse while Ctrl is held (otherwise they'd block what's behind)
    if (hit && !e.ctrlKey && el.closest('#widget .media')) hit = false;
    const solid = hit && data && data.settings.hoverSolid !== false;
    document.body.classList.toggle('hovering', !!solid);
    if (hit !== overHit) { overHit = hit; api.setIgnoreMouse(!hit); }
  });
  document.addEventListener('mouseleave', () => { if (!drag) { overHit = false; api.setIgnoreMouse(true); document.body.classList.remove('hovering'); } });

  // drag the character to move the whole window; a click without moving opens the panel
  let drag = null;
  // the main process moves the window from the real cursor position; here we only say start / move / end
  let dragFrame = 0;
  $('buddy').addEventListener('mousedown', (e) => {
    if (e.button !== 0) return;
    drag = { x0: e.screenX, y0: e.screenY, moved: 0 };
    if (api.dragStart) api.dragStart();
  });
  window.addEventListener('mousemove', (e) => {
    if (!drag) return;
    if (e.buttons === 0) return endDrag(false);      // the button was let go somewhere we didn't hear about: stop following the mouse
    drag.moved = Math.max(drag.moved, Math.abs(e.screenX - drag.x0) + Math.abs(e.screenY - drag.y0));
    if (drag.moved < 5) return;
    if (!document.body.classList.contains('dragging')) { document.body.classList.add('dragging'); render(); }   // picked up: hold still
    if (!dragFrame) dragFrame = requestAnimationFrame(() => { dragFrame = 0; if (drag && api.dragMove) api.dragMove(); });
  });
  $('buddy').addEventListener('contextmenu', (e) => { e.preventDefault(); endDrag(false); if (api.showMenu) api.showMenu(); });
  window.addEventListener('blur', () => endDrag(false));
  window.addEventListener('mouseup', () => endDrag(true));
  function endDrag(asClick) {
    if (!drag) return;
    const wasClick = asClick && drag.moved < 5;
    if (!wasClick) ui.holdUntil = Date.now() + 1500;   // settle for a moment after being put down
    if (api.dragEnd) api.dragEnd();
    document.body.classList.remove('dragging');
    drag = null;
    if (wasClick) {
      if (!$('bubble').hidden && $('bubbleButtons').children.length) return;   // a question is waiting; keep it
      togglePanel();
    }
  }

  // ---------- browser preview (no Electron) ----------
  function fakeApi() {
    let store = null;
    try { store = JSON.parse(localStorage.getItem('desk-buddy') || 'null'); } catch (e) {}
    const base = { settings: { name: '시오리', chatter: 'normal', autoMusic: false, lunch: '12:30', snack: '15:30', dinner: '18:30', wrapUp: '22:30', workStart: '09:00', workEnd: '22:00' }, days: {} };
    let idleFn = null;
    let fakeIdle = 0;
    window.addEventListener('keydown', () => { fakeIdle = 0; });
    window.addEventListener('mousemove', () => { fakeIdle = 0; });
    setInterval(() => { fakeIdle += 1; if (idleFn) idleFn(fakeIdle); }, 1000);
    return {
      load: () => Promise.resolve(store || base),
      save: (p) => { store = { ...(store || base), ...p }; try { localStorage.setItem('desk-buddy', JSON.stringify(store)); } catch (e) {} },
      setIgnoreMouse() {}, dragStart() {}, dragMove() {}, dragEnd() {}, focusPanel() {}, settingsChanged() {},
      copyText: (t) => { try { navigator.clipboard.writeText(t); } catch (e) {} },
      onIdle: (fn) => { idleFn = fn; }, onAway() {}, onMusic() {}, onCommand() {},
      onWeather: (fn) => setTimeout(() => fn({ city: '서울', temp: 18, code: 1, todayCode: 61, max: 21, min: 13, rainChance: 70 }), 300),
      onBluetooth: (fn) => setTimeout(() => fn([{ name: 'Galaxy Buds2', level: 15 }, { name: 'MX Master 3', level: 80 }]), 300),
      getLogin: () => Promise.resolve(false), setLogin() {},
      onSys: (fn) => setInterval(() => fn({ cpu: 20 + Math.round(Math.random() * 10), ram: 61, gpu: 4, t: Date.now() }), 3000)
    };
  }

  // exposed for previews/tests only
  window.__buddy = { say, nudge, openPanel, closePanel, wrapUp, ui, get data() { return data; }, render, onSys, startTest, playScene, switchCharacter, praise, SCENES, onLayout, positionBubble, setStill: (on) => setSetting('still', on) };
})();
