﻿# 책상 친구 설치 — 처음 한 번만 실행하면 돼요.
# Electron(프로그램 바탕)을 공식 배포처(GitHub)에서 내려받아 확인한 뒤, 이 폴더 안에 조립합니다.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$ver  = '44.6.0'
$sha  = '04d6071f8deca081044e1398f96f65e4c1550ffdb3f882504cd78528d821d422'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $root 'runtime'
$exe  = Join-Path $dest 'DeskBuddy.exe'
$zip  = Join-Path $env:TEMP "electron-v$ver-win32-x64.zip"

try {
  Get-Process DeskBuddy -ErrorAction SilentlyContinue | Stop-Process -Force
  Write-Host ''
  Write-Host '책상 친구를 준비하고 있어요. (처음 한 번, 약 150MB 내려받기 · 1~3분)'

  $ok = (Test-Path $zip) -and ((Get-FileHash $zip -Algorithm SHA256).Hash.ToLower() -eq $sha)
  if (-not $ok) {
    Invoke-WebRequest -Uri "https://github.com/electron/electron/releases/download/v$ver/electron-v$ver-win32-x64.zip" -OutFile $zip -UseBasicParsing
    if ((Get-FileHash $zip -Algorithm SHA256).Hash.ToLower() -ne $sha) {
      Remove-Item $zip -Force
      throw '내려받은 파일이 원본과 달라요. 인터넷 연결을 확인하고 다시 실행해 주세요.'
    }
  }

  Write-Host '압축 푸는 중...'
  if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
  Expand-Archive -Path $zip -DestinationPath $dest -Force
  Remove-Item (Join-Path $dest 'resources\default_app.asar') -ErrorAction SilentlyContinue
  Copy-Item (Join-Path $root 'app') (Join-Path $dest 'resources\app') -Recurse -Force
  Rename-Item (Join-Path $dest 'electron.exe') 'DeskBuddy.exe'

  Write-Host '바로가기 만드는 중...'
  $ws = New-Object -ComObject WScript.Shell
  foreach ($dir in @($root, [Environment]::GetFolderPath('Desktop'))) {
    $lnk = $ws.CreateShortcut((Join-Path $dir '책상 친구.lnk'))
    $lnk.TargetPath = $exe
    $lnk.WorkingDirectory = $dest
    $lnk.IconLocation = (Join-Path $root 'icon.ico')
    $lnk.Save()
  }

  Write-Host '완료! 책상 친구를 불러올게요.'
  Start-Process $exe
}
catch {
  Write-Host ''
  Write-Host ('설치하다 문제가 생겼어요: ' + $_.Exception.Message) -ForegroundColor Red
  Write-Host '이 창을 캡처해서 보내주시면 같이 볼게요.'
  Read-Host '엔터를 누르면 닫혀요'
}
