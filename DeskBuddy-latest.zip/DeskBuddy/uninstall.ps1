﻿# 책상 친구 지우기 — 프로그램, 바로가기, 자동 실행을 지워요. (트레이 메뉴 [책상 친구 지우기…]에서도 할 수 있어요)
param([switch]$FromApp, [switch]$RemoveData)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $root 'runtime'
$exe  = Join-Path $dest 'DeskBuddy.exe'
$data = Join-Path $env:APPDATA 'desk-buddy'
try {
  if (-not $FromApp) {
    Write-Host ''
    Write-Host '책상 친구를 이 컴퓨터에서 지울게요. (프로그램 · 바로가기 · 자동 실행)'
    $a = Read-Host '할 일 기록까지 지울까요? 지우려면 y, 남기려면 그냥 엔터'
    if ($a -match '^[yYㅛ]') { $RemoveData = $true }
  }
  Get-Process DeskBuddy -ErrorAction SilentlyContinue | Stop-Process -Force
  Start-Sleep -Milliseconds 1200

  # 자동 실행 등록 지우기 (DeskBuddy.exe 를 가리키는 항목만)
  foreach ($key in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run',
                     'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run')) {
    if (Test-Path $key) {
      $props = Get-ItemProperty $key
      foreach ($p in $props.PSObject.Properties) {
        if ($p.Name -like 'PS*') { continue }
        $v = [string]$p.Value
        if ($v -like '*DeskBuddy.exe*' -or $p.Name -like '*desk-buddy*' -or $p.Name -like '*책상 친구*') {
          Remove-ItemProperty -Path $key -Name $p.Name -ErrorAction SilentlyContinue
        }
      }
    }
  }

  # 바로가기
  foreach ($dir in @($root, [Environment]::GetFolderPath('Desktop'))) {
    $lnk = Join-Path $dir '책상 친구.lnk'
    if (Test-Path $lnk) { Remove-Item $lnk -Force }
  }

  # 프로그램
  if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }

  if ($RemoveData -and (Test-Path $data)) { Remove-Item $data -Recurse -Force; $msg = '할 일 기록까지 지웠어요.' }
  else { $msg = '할 일 기록은 남겨 뒀어요: ' + $data }

  Write-Host ''
  Write-Host ('다 지웠어요. ' + $msg)
  Write-Host '이제 이 DeskBuddy 폴더만 지우면 끝이에요. (폴더를 열어 둘게요)'
  Start-Process explorer.exe (Split-Path -Parent $root)
  if (-not $FromApp) { Read-Host '엔터를 누르면 닫혀요' }
  else { Start-Sleep -Seconds 6 }
}
catch {
  Write-Host ('지우다가 문제가 생겼어요: ' + $_.Exception.Message) -ForegroundColor Red
  Read-Host '엔터를 누르면 닫혀요'
}
